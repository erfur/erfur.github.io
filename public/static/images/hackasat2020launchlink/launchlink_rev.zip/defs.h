struct queue_packet {
    uint8_t  type;
    uint8_t  timestamp_lo;   // to defeat padding
    uint16_t timestamp_hi;
    uint8_t  timestamp_hhi;
    char     data_block[29];
};

struct queue_node {
    uint32_t next;
    uint32_t prev;
    uint32_t curr_queue;
    struct queue_packet *packet;
    uint32_t packet_size;
    void *destructor_fcn;
};

struct queue_struct {
    uint32_t queue_size;
    struct queue_node *head;
    struct queue_node *tail;
    char *queue_name;
    uint32_t unk1;
};

enum mac_pdu_type {
    MAC_RESET = 0x13,
    MAC_BLOCK_SIZE_UPDATE = 0x79,
    MAC_DATA_BLOCK = 0xe3
};

struct mac_pdu_struct {
    enum mac_pdu_type pdu_type;
    uint16_t crc16;
    char pdu_payload[29];
};

struct mac_struct {
    uint32_t max_pdu_size;                      // 0x0
    uint32_t min_pdu_size;                      // 0x4
    uint32_t default_pdu_size;                  // 0x8
    uint32_t MAC_PDU_DATA_BLOCK_TYPE;           // 0xc
    uint32_t MAC_PDU_SET_DATA_BLOCK_SIZE_TYPE;  // 0x10
    uint32_t MAC_PDU_RESET_TYPE;                // 0x14, might be something completely different
    uint32_t unk1;                              // 0x18
    uint32_t unk2;                              // 0x1c
    uint32_t init_time;                         // 0x20
    uint32_t unk3;                              // 0x24
    uint32_t curr_time;                         // 0x28
    uint32_t send_time;                         // 0x2c
    uint32_t uart_io;                           // 0x30
    struct queue_struct *macrll_queue;          // 0x34
    struct queue_struct *rllmac_queue;          // 0x38
    struct queue_struct *global_queue;          // 0x3c
    char     pdu_buffer[0x180];                 // 0x40
    uint16_t curr_pdu_buffer_size;              // 0x1c0
    uint8_t curr_pdu_size;                      // 0x1c2
    uint8_t padding;                            // 0x1c3
    uint32_t received_packet_count;             // 0x1c4, max 20
    uint32_t uninitialized_flag;                // 0x1c8
};

struct dedicated_queue_node {
    uint32_t next;              // 0x00
    uint32_t prev;              // 0x04
    uint32_t queue_ptr;         // 0x08, DISPUTED
    uint32_t rll_struct_ptr;    // 0x0c
    uint32_t fragment_pool[16]; // 0x10
    uint16_t sequence_window;   // 0x50
    uint8_t  end_fragment_no;   // 0x52
    uint8_t  end_flag;          // 0x53, first bit of sequence number
};

struct dedicated_queue_struct {
    uint32_t size;
    uint32_t head;
    uint32_t tail;
};

struct rll_struct {
    void *pdu_pool;                     // 0x00
    uint32_t last_item;                 // 0x04
    uint32_t pool_item_count;           // 0x08
    uint32_t dedicated_pool_item_count; // 0x0c, DISPUTED
    struct dedicated_queue_struct dedicated_queue;
    uint32_t unk7;                      // 0x1c
    uint32_t current_time;              // 0x20
    uint32_t unk8;                      // 0x24
    uint32_t last_packet_time;          // 0x28
    uint32_t time_passed;               // 0x2c
    uint8_t pdu_size;                   // 0x30
    uint8_t encryption_enabled;         // 0x31
    uint8_t unk11;                      // 0x32
    uint8_t unk12;                      // 0x33
    uint8_t some_key[16];               // 0x34
    uint32_t unk17;                     // 0x44
    uint8_t decryption_key[8];          // 0x48
    uint8_t encryption_key[8];          // 0x4c
    uint32_t sequence_number;           // 0x58
    uint32_t unk23;                     // 0x5c
    uint32_t received_packet_count;     // 0x60, max 0xf0
    struct queue_struct *macrll_queue;  // 0x64
    struct queue_struct *rllrrl_queue;  // 0x68
    struct queue_struct *rllmac_queue;  // 0x6c
    struct queue_struct *rrlrll_queue;  // 0x70
    struct queue_struct *global_queue;  // 0x74
};

struct rrl_struct {
    struct queue_struct *rllrrl_queue;
    struct queue_struct *rrlrll_queue;
    struct queue_struct *global_queue;
    uint32_t ap_list;
    uint32_t unk2;
    uint32_t unk3;
    char encryption_key_maybe[0x10];
    uint32_t unk4;
};
