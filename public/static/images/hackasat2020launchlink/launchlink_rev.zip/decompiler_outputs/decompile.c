
// WARNING: This function may have set the stack pointer
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00000 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08de0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc00000(void)
{
    undefined *puVar1;
    int32_t iVar2;
    undefined uVar3;
    int32_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    int32_t iVar9;
    
    iVar2 = 0;
    uVar3 = 0;
    iVar4 = 0;
    setCopReg(0, *(undefined4 *)0x2010, 0, 0);
    setCopReg(0, *(undefined4 *)0x2020, 0, 0);
    setCopReg(0, *(undefined4 *)0x2038, 0, 0);
    iVar6 = 0x40;
    iVar7 = 0;
    iVar9 = 0x700;
    do {
        iVar6 = iVar6 + -1;
        setCopReg(0, *(undefined4 *)0x2000, iVar6 * 0x100, 0);
        setCopReg(0, *(undefined4 *)0x2008, iVar9, 0);
        setCopReg(0, *(undefined4 *)0x2028, iVar7, 0);
        TLB_write_indexed_entry
                  (*(undefined4 *)0x2000, *(undefined4 *)0x2028, *(undefined4 *)0x2008, *(undefined4 *)0x200c, 
                   *(undefined4 *)0x2014);
        iVar7 = iVar7 + 0x1000;
        iVar9 = iVar9 + 0x1000;
    } while (iVar6 != 0);
    setCopReg(0, *(undefined4 *)0x2028, 0, 0);
    puVar5 = (undefined4 *)0xbfc08ef8;
    puVar8 = (undefined4 *)0xa0180000;
    do {
        *puVar8 = *puVar5;
        puVar5 = puVar5 + 1;
        puVar8 = puVar8 + 1;
    } while (puVar5 != (undefined4 *)0xbfc09c8c);
    iVar6 = -0x403ffaf0;
    fcn.bfc08de0(0, 0);
    trap(0);
    *(int32_t *)0xa00fffec = 0;
    *(undefined4 *)0xa00ffff0 = 0;
    *(undefined4 *)0xa00ffff8 = 0;
    *(undefined4 *)0xa00ffff4 = 0;
    *(int32_t *)0xa00fffe8 = 0;
    *(int32_t *)0xa00fffe4 = 0;
    *(int32_t *)0xa00ffffc = iVar6;
    puVar1 = (undefined *)fcn.bfc03e88(0);
    *puVar1 = uVar3;
    fcn.bfc07918((int32_t)(puVar1 + 1), *(int32_t *)0xa00fffe0, *(int32_t *)0xa00fffe4, *(int32_t *)0xa00fffe8, 
                 *(int32_t *)0xa00fffd0);
    iVar6 = fcn.bfc03e50(*(int32_t *)0xa00fffec);
    fcn.bfc01930(iVar6, puVar1, iVar4 + 1, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(iVar2 + 0x68));
    if (iVar2 == 0) {
        fcn.bfc01984(iVar6);
        *(undefined4 *)0xa0100010 = 0;
        *(undefined4 *)0xa010001c = 0x18;
        *(int32_t *)0xa0100018 = iVar6;
        fcn.bfc06d40(iVar6, 0x18, *(int32_t *)0xa00ffffc, 0, *(int32_t *)0xa0100000, *(int32_t *)0xa0100004, 
                     *(int32_t *)0xa0100008, *(int32_t *)0xa010000c);
        return;
    }
    return;
}

// WARNING: This function may have set the stack pointer
// WARNING: [r2ghidra] Matching calling convention n32 of function loc.bfc00400 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08de0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void loc.bfc00400(void)
{
    undefined *puVar1;
    int32_t iVar2;
    undefined uVar3;
    int32_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined4 *puVar8;
    int32_t iVar9;
    
    iVar2 = 0;
    uVar3 = 0;
    iVar4 = 0;
    setCopReg(0, *(undefined4 *)0x2010, 0, 0);
    setCopReg(0, *(undefined4 *)0x2020, 0, 0);
    setCopReg(0, *(undefined4 *)0x2038, 0, 0);
    iVar6 = 0x40;
    iVar7 = 0;
    iVar9 = 0x700;
    do {
        iVar6 = iVar6 + -1;
        setCopReg(0, *(undefined4 *)0x2000, iVar6 * 0x100, 0);
        setCopReg(0, *(undefined4 *)0x2008, iVar9, 0);
        setCopReg(0, *(undefined4 *)0x2028, iVar7, 0);
        TLB_write_indexed_entry
                  (*(undefined4 *)0x2000, *(undefined4 *)0x2028, *(undefined4 *)0x2008, *(undefined4 *)0x200c, 
                   *(undefined4 *)0x2014);
        iVar7 = iVar7 + 0x1000;
        iVar9 = iVar9 + 0x1000;
    } while (iVar6 != 0);
    setCopReg(0, *(undefined4 *)0x2028, 0, 0);
    puVar5 = (undefined4 *)0xbfc08ef8;
    puVar8 = (undefined4 *)0xa0180000;
    do {
        *puVar8 = *puVar5;
        puVar5 = puVar5 + 1;
        puVar8 = puVar8 + 1;
    } while (puVar5 != (undefined4 *)0xbfc09c8c);
    iVar6 = -0x403ffaf0;
    fcn.bfc08de0(0, 0);
    trap(0);
    *(int32_t *)0xa00fffec = 0;
    *(undefined4 *)0xa00ffff0 = 0;
    *(undefined4 *)0xa00ffff8 = 0;
    *(undefined4 *)0xa00ffff4 = 0;
    *(int32_t *)0xa00fffe8 = 0;
    *(int32_t *)0xa00fffe4 = 0;
    *(int32_t *)0xa00ffffc = iVar6;
    puVar1 = (undefined *)fcn.bfc03e88(0);
    *puVar1 = uVar3;
    fcn.bfc07918((int32_t)(puVar1 + 1), *(int32_t *)0xa00fffe0, *(int32_t *)0xa00fffe4, *(int32_t *)0xa00fffe8, 
                 *(int32_t *)0xa00fffd0);
    iVar6 = fcn.bfc03e50(*(int32_t *)0xa00fffec);
    fcn.bfc01930(iVar6, puVar1, iVar4 + 1, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(iVar2 + 0x68));
    if (iVar2 == 0) {
        fcn.bfc01984(iVar6);
        *(undefined4 *)0xa0100010 = 0;
        *(undefined4 *)0xa010001c = 0x18;
        *(int32_t *)0xa0100018 = iVar6;
        fcn.bfc06d40(iVar6, 0x18, *(int32_t *)0xa00ffffc, 0, *(int32_t *)0xa0100000, *(int32_t *)0xa0100004, 
                     *(int32_t *)0xa0100008, *(int32_t *)0xa010000c);
        return;
    }
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08de0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08ba8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dd4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type signed int for variable arg1 to Decompiler type: Unknown type identifier
// signed
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01840 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc019cc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08080 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc008b0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_14h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01c70 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08148 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0096c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc085ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc015e0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b9c failed, args may be inaccurate.

void fcn.bfc08de0(int32_t arg2, int32_t arg1)
{
    undefined *puVar1;
    int32_t in_a2;
    undefined4 arg3;
    int32_t in_a3;
    undefined4 arg4;
    undefined **ppuVar2;
    int32_t in_stack_ffffece8;
    int32_t in_stack_ffffecec;
    int32_t in_stack_ffffecf0;
    int32_t in_stack_ffffecf4;
    int32_t in_stack_ffffecf8;
    int32_t in_stack_ffffecfc;
    int32_t in_stack_ffffed00;
    int32_t in_stack_ffffed04;
    int32_t in_stack_ffffed08;
    int32_t in_stack_ffffed0c;
    int32_t in_stack_ffffed10;
    int32_t in_stack_ffffed14;
    undefined *puStack4840;
    undefined *puStack4836;
    undefined *puStack4832;
    undefined auStack712 [12];
    undefined auStack700 [456];
    undefined auStack244 [12];
    undefined auStack232 [112];
    undefined auStack120 [32];
    undefined auStack88 [16];
    undefined auStack72 [16];
    undefined auStack56 [16];
    undefined auStack40 [16];
    undefined auStack24 [8];
    
    puVar1 = &stack0xffffed00;
    fcn.bfc08ba8((int32_t)&stack0xffffed00);
    *(undefined **)0xa0180db0 = &stack0xffffed00;
    fcn.bfc08dd4(puVar1, arg2, in_a3, in_a2, in_stack_ffffed00, in_stack_ffffed04, in_stack_ffffece8, in_stack_ffffecec
                 , in_stack_ffffecf0);
    fcn.bfc01840(0);
    fcn.bfc019cc((int32_t)auStack24, in_stack_ffffed00, in_stack_ffffed04, in_stack_ffffecf0);
    fcn.bfc019cc((int32_t)auStack40, in_stack_ffffed04, in_stack_ffffed08, in_stack_ffffecf4);
    puStack4836 = auStack56;
    fcn.bfc019cc((int32_t)puStack4836, in_stack_ffffed08, in_stack_ffffed0c, in_stack_ffffecf8);
    fcn.bfc019cc((int32_t)auStack72, in_stack_ffffed0c, in_stack_ffffed10, in_stack_ffffecfc);
    puStack4832 = auStack88;
    fcn.bfc019cc((int32_t)puStack4832, in_stack_ffffed10, in_stack_ffffed14, in_stack_ffffed00);
    puStack4840 = *(undefined **)0xa0180db0;
    fcn.bfc08080((int32_t)auStack712);
    fcn.bfc008b0((int32_t)auStack244);
    puVar1 = &stack0xfffffff0;
    fcn.bfc01c70((int32_t)auStack120);
    fcn.bfc08148((int32_t)auStack700);
    arg3 = 0;
    arg4 = 0;
    fcn.bfc0096c((int32_t)auStack232);
    ppuVar2 = &puStack4836;
    do {
        fcn.bfc085ec(puVar1, (undefined *)((int32_t)ppuVar2 + 0x1030), arg3, arg4, *(undefined *)ppuVar2);
        fcn.bfc015e0(puVar1, (undefined *)((int32_t)ppuVar2 + 0x1204), *(undefined *)((int32_t)ppuVar2 + 4));
        fcn.bfc02b9c(puVar1, (undefined *)((int32_t)ppuVar2 + 0x1280), *(undefined *)((int32_t)ppuVar2 + 8));
        ppuVar2 = (undefined **)((int32_t)ppuVar2 + 0xc);
    } while( true );
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08960 failed, args may be inaccurate.

void fcn.bfc08960(int32_t arg1, int32_t arg3, int32_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    
    iVar1 = *(int32_t *)0xa0180db0;
    uVar3 = **(undefined4 **)0xa0180084;
    if (*(int32_t *)(*(int32_t *)0xa0180db0 + 0x1000) + 4U < 0x801) {
        iVar2 = *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1004);
        *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 0x18);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 0x10);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 8);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)uVar3;
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        *(int32_t *)(iVar1 + 0x1000) = *(int32_t *)(iVar1 + 0x1000) + 4;
    }
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08a98 failed, args may be inaccurate.

void fcn.bfc08a98(int32_t arg2, int32_t arg1, int32_t arg3)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    
    iVar5 = *(int32_t *)0xa0180db0;
    if (*(uint32_t *)(*(int32_t *)0xa0180db0 + 0x100c) < 4) {
        **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 8;
        return;
    }
    iVar6 = *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1014) = uVar7;
    uVar1 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar2 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar3 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar4 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    **(uint32_t **)0xa018008c =
         (uint32_t)uVar3 << 8 | (uint32_t)uVar4 | (uint32_t)uVar2 << 0x10 | (uint32_t)uVar1 << 0x18;
    *(int32_t *)(iVar5 + 0x100c) = *(int32_t *)(iVar5 + 0x100c) + -4;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dc4 failed, args may be inaccurate.

void fcn.bfc08dc4(void)
{
    *(undefined4 *)0xa101000c = 3;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type int for variable argc to Decompiler type: Unknown type identifier int

void fcn.bfc03e88(int32_t argc)
{
    undefined4 in_a0;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    int32_t in_stack_0000001c;
    int32_t in_stack_fffffff4;
    
    main(in_a0, in_stack_0000001c, in_stack_fffffff4, unaff_s8, unaff_retaddr, in_a0, in_stack_00000004, 
         in_stack_00000008, in_stack_0000000c, in_stack_00000010);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type int for variable argc to Decompiler type: Unknown type identifier int
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06740 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function memset failed, args may be inaccurate.

uint32_t *
main(uint32_t argc, int32_t arg_10h, int32_t arg_0h, int32_t arg_14h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h,
    int32_t arg_24h, int32_t arg_28h, int32_t arg_2ch)
{
    int32_t *piVar1;
    uint32_t uStackX0;
    int32_t aiStack60 [5];
    uint32_t *puStack40;
    uint32_t *puStack36;
    uint32_t **ppuStack32;
    uint32_t *puStack28;
    uint32_t uStack24;
    uint32_t *puStack20;
    uint32_t *puStack16;
    uint32_t **ppuStack12;
    
    piVar1 = aiStack60 + 1;
    if (argc < 8) {
        uStackX0 = 8;
    } else {
        uStackX0 = argc;
        if ((argc & 3) != 0) {
            uStackX0 = ((argc >> 2) + 1) * 4;
        }
    }
    puStack40 = *(uint32_t **)0xa0180d90;
    while( true ) {
        if (puStack40 == (uint32_t *)0x0) {
            puStack40 = (uint32_t *)fcn.bfc06740(piVar1[5], piVar1[-1], *piVar1, piVar1[1], piVar1[2]);
            piVar1 = piVar1 + 1;
        }
        puStack36 = puStack40;
        ppuStack32 = (uint32_t **)((int32_t)puStack40 + ((*puStack40 & 0xfffffffc) - 4));
        if (uStackX0 <= *puStack40) break;
        puStack40 = *ppuStack32;
    }
    puStack28 = puStack40 + 1;
    uStack24 = *puStack40 - uStackX0;
    *puStack40 = uStackX0;
    *puStack40 = *puStack40 | 1;
    if (uStack24 < 0xc) {
        if (puStack40 == *(uint32_t **)0xa0180d90) {
            *(uint32_t **)0xa0180d90 = *ppuStack32;
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(undefined4 *)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = 0;
            }
        } else {
            if (ppuStack32[1] != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)ppuStack32[1] + ((*ppuStack32[1] & 0xfffffffc) - 4)) = *ppuStack32;
            }
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = ppuStack32[1];
            }
        }
    } else {
        puStack20 = (uint32_t *)((int32_t)puStack40 + uStackX0 + 4);
        puStack16 = puStack20;
        *puStack20 = uStack24 - 4;
        ppuStack12 = ppuStack32;
        if (ppuStack32 != (uint32_t **)((int32_t)puStack20 + ((*puStack20 & 0xfffffffc) - 4))) {
            printf(piVar1[0x407], piVar1[0x408], piVar1[0x409], piVar1[0x40a], piVar1[4], piVar1[3]);
            return (uint32_t *)0x0;
        }
        if (puStack40 == *(uint32_t **)0xa0180d90) {
            *(uint32_t **)0xa0180d90 = puStack20;
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = puStack20;
            }
        } else {
            if (ppuStack32[1] != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)ppuStack32[1] + ((*ppuStack32[1] & 0xfffffffc) - 4)) = puStack20;
            }
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = puStack20;
            }
        }
        *puStack40 = *puStack40 | 2;
    }
    memset(piVar1[3], piVar1[4], piVar1[5], piVar1[-1], *piVar1);
    return puStack40 + 1;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.

int32_t fcn.bfc07918(int32_t arg1, int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_0h)
{
    int32_t in_a1;
    uint32_t in_a2;
    uint32_t uStack16;
    
    uStack16 = 0;
    while (uStack16 < in_a2) {
        *(undefined *)(arg1 + uStack16) = *(undefined *)(in_a1 + uStack16);
        uStack16 = uStack16 + 1;
    }
    return arg1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type int for variable argc to Decompiler type: Unknown type identifier int

void fcn.bfc03e50(int32_t argc)
{
    undefined4 in_a0;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    int32_t in_stack_0000001c;
    int32_t in_stack_fffffff4;
    
    main(in_a0, in_stack_0000001c, in_stack_fffffff4, unaff_s8, unaff_retaddr, in_a0, in_stack_00000004, 
         in_stack_00000008, in_stack_0000000c, in_stack_00000010);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d30 failed, args may be inaccurate.

void fcn.bfc01930(int32_t param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    fcn.bfc07d30(param_1);
    *(undefined4 *)(param_1 + 0xc) = param_2;
    *(undefined4 *)(param_1 + 0x10) = param_3;
    *(undefined4 *)(param_1 + 0x14) = param_4;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d30 failed, args may be inaccurate.

void fcn.bfc07d30(int32_t arg1)
{
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

int32_t fcn.bfc01a48(int32_t arg1)
{
    int32_t iVar1;
    int32_t in_a1;
    
    if (in_a1 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(arg1 + 0x10) < 0x20) && (iVar1 = fcn.bfc07e9c(in_a1, arg1), iVar1 != 0)) {
        *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
    } else {
        iVar1 = 0;
    }
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

undefined4 fcn.bfc07e9c(int32_t arg2, int32_t arg1)
{
    undefined4 uVar1;
    int32_t iVar2;
    int32_t *piVar3;
    
    uVar1 = 0;
    if ((arg2 != 0) && (*(int32_t *)(arg2 + 8) == 0)) {
        if (*(int32_t *)(arg1 + 4) == 0) {
            *(undefined4 *)(arg2 + 4) = 0;
            *(undefined4 *)arg2 = 0;
            *(int32_t *)(arg1 + 8) = arg2;
            *(int32_t *)(arg1 + 4) = arg2;
        } else {
            piVar3 = *(int32_t **)(arg1 + 8);
            *(undefined4 *)arg2 = 0;
            *(int32_t **)(arg2 + 4) = piVar3;
            *piVar3 = arg2;
            *(int32_t *)(arg1 + 8) = arg2;
        }
        iVar2 = *(int32_t *)arg1;
        *(int32_t *)(arg2 + 8) = arg1;
        *(int32_t *)arg1 = iVar2 + 1;
        uVar1 = 1;
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.

undefined4 fcn.bfc01984(int32_t arg1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if ((*(int32_t *)(arg1 + 0xc) != 0) && (*(code **)(arg1 + 0x14) != (code *)0x0)) {
        (**(code **)(arg1 + 0x14))();
    }
    if (*(int32_t **)(arg1 + 8) != (int32_t *)0x0) {
        uVar1 = 0;
        if ((arg1 != 0) && (piVar3 = *(int32_t **)(arg1 + 8), piVar3 == *(int32_t **)(arg1 + 8))) {
            iVar4 = *(int32_t *)arg1;
            if (iVar4 != 0) {
                *(undefined4 *)(iVar4 + 4) = *(undefined4 *)(arg1 + 4);
            }
            piVar2 = *(int32_t **)(arg1 + 4);
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (arg1 == piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (arg1 == piVar3[1]) {
                piVar3[1] = *(int32_t *)arg1;
            }
            iVar4 = *piVar3;
            *(undefined4 *)(arg1 + 8) = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01918 failed, args may be inaccurate.

undefined2 fcn.bfc01918(int32_t arg1)
{
    return *(undefined2 *)arg1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.

int32_t fcn.bfc07cd8(int32_t arg_8h)
{
    int32_t in_a0;
    
    if (in_a0 < 0) {
        in_a0 = -in_a0;
    }
    return in_a0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE

undefined4 printf2(int32_t arg_10h, int32_t arg3, int32_t arg2)
{
    undefined4 uVar1;
    undefined4 in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    
    uVar1 = 0;
    if ((arg_10h & *(uint32_t *)0xa0180050) != 0) {
        uVar1 = fcn.bfc05988(in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84, in_stack_fffffbec, 
                             in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                             in_stack_fffffc18, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc00, 
                             in_stack_fffffc1c, in_stack_fffffc2c, in_stack_fffffc0c, in_stack_fffffc20, 
                             in_stack_fffffc08, in_stack_fffffc24, in_stack_fffffc04, in_stack_fffffc28);
        printf(in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, in_stack_00000c0c, in_stack_fffffbf4, 
               in_stack_fffffbf0);
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function isdigit failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function atoi failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

int32_t fcn.bfc05988(int32_t arg_a0h, int32_t arg_a4h, int32_t arg_a8h, int32_t arg_10h, int32_t arg_14h,
                    int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h, int32_t arg_3ch, int32_t arg_34h, int32_t arg_38h
                    , int32_t arg_24h, int32_t arg_40h, int32_t arg_0h, int32_t arg_30h, int32_t arg_44h,
                    int32_t arg_2ch, int32_t arg_48h, int32_t arg_28h, int32_t arg_4ch)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t in_a0;
    char *in_a1;
    char **in_a2;
    undefined *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    char *pcStackX4;
    char **ppcStackX8;
    undefined auStack160 [16];
    int32_t aiStack144 [4];
    uint32_t uStack128;
    int32_t iStack124;
    char *pcStack120;
    char *pcStack116;
    char *pcStack112;
    char *pcStack108;
    uint32_t uStack104;
    undefined4 uStack100;
    char *pcStack96;
    char *pcStack92;
    char *pcStack88;
    undefined uStack84;
    char acStack80 [68];
    
    piVar10 = (int32_t *)auStack160;
    aiStack144[0] = 0;
    pcStackX4 = in_a1;
    ppcStackX8 = in_a2;
    if (in_a1 == (char *)0x0) {
        aiStack144[0] = -1;
    } else {
        while (*pcStackX4 != '\0') {
            if (*pcStackX4 == '%') {
                pcVar2 = pcStackX4 + 1;
                aiStack144[1] = 0;
                aiStack144[2] = 0;
                aiStack144[3] = 0;
                uStack128 = 0;
                uStack100 = 0;
                if (*pcVar2 == '%') {
                    *(undefined *)(in_a0 + aiStack144[0]) = 0x25;
                    pcStackX4 = pcStackX4 + 2;
                    aiStack144[0] = aiStack144[0] + 1;
                } else {
                    pcVar1 = pcVar2;
                    if (*pcVar2 == '-') {
                        uStack128 = 1;
                        pcVar1 = pcStackX4 + 2;
                    }
                    pcStackX4 = pcVar1;
                    uStack128 = (uint32_t)(*pcVar2 == '-');
                    iVar3 = isdigit(*(int32_t *)((int32_t)piVar10 + 4));
                    puVar6 = (undefined *)((int32_t)piVar10 + 4);
                    if (iVar3 != 0) {
                        if (*pcStackX4 == '0') {
                            aiStack144[3] = 1;
                            pcStackX4 = pcStackX4 + 1;
                        }
                        iVar3 = isdigit(*(int32_t *)((int32_t)piVar10 + 8));
                        puVar6 = (undefined *)((int32_t)piVar10 + 8);
                        if (iVar3 != 0) {
                            aiStack144[1] =
                                 atoi(*(int32_t *)((int32_t)piVar10 + 0x2c), *(int32_t *)((int32_t)piVar10 + 0x14), 
                                      *(int32_t *)((int32_t)piVar10 + 0x18), *(int32_t *)((int32_t)piVar10 + 0x20), 
                                      *(int32_t *)((int32_t)piVar10 + 0x1c));
                            puVar7 = (undefined *)((int32_t)piVar10 + 0xc);
                            while( true ) {
                                iVar3 = isdigit(*(int32_t *)(puVar7 + 4));
                                puVar6 = puVar7 + 4;
                                puVar7 = puVar7 + 4;
                                if (iVar3 == 0) break;
                                pcStackX4 = pcStackX4 + 1;
                            }
                        }
                    }
                    piVar10 = (int32_t *)puVar6;
                    if (*pcStackX4 == '.') {
                        aiStack144[2] =
                             atoi(*(int32_t *)(puVar6 + 0x24), *(int32_t *)(puVar6 + 0xc), *(int32_t *)(puVar6 + 0x10), 
                                  *(int32_t *)(puVar6 + 0x18), *(int32_t *)(puVar6 + 0x14));
                        puVar8 = puVar6 + 4;
                        do {
                            pcStackX4 = pcStackX4 + 1;
                            iVar3 = isdigit(*(int32_t *)(puVar8 + 4));
                            piVar10 = (int32_t *)(puVar8 + 4);
                            puVar8 = puVar8 + 4;
                        } while (iVar3 != 0);
                    }
                    if (*pcStackX4 == 'c') {
                        pcVar2 = *ppcStackX8;
                        uStack84 = (char)pcVar2;
                        if (uStack128 == 0) {
                            iStack124 = 0;
                            while (iStack124 < aiStack144[1] + -1) {
                                if (aiStack144[3] == 0) {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                } else {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                }
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        *(char *)(in_a0 + aiStack144[0]) = (char)pcVar2;
                        aiStack144[0] = aiStack144[0] + 1;
                        if (uStack128 != 0) {
                            iStack124 = 0;
                            while (iStack124 < aiStack144[1] + -1) {
                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        pcStackX4 = pcStackX4 + 1;
                        ppcStackX8 = ppcStackX8 + 1;
                    } else {
                        if (*pcStackX4 == 'u') {
                            pcStack88 = *ppcStackX8;
                            fcn.bfc049ec(piVar10[0xb], piVar10[0xc], piVar10[1], piVar10[-1], *piVar10);
                            iVar3 = aiStack144[1];
                            iVar4 = strlen(piVar10[4], *piVar10);
                            piVar10 = piVar10 + 2;
                            if (uStack128 == 0) {
                                iStack124 = 0;
                                while (iStack124 < iVar3 - iVar4) {
                                    if (aiStack144[3] == 0) {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                    } else {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                    }
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStack120 = acStack80;
                            while (*pcStack120 != '\0') {
                                *(char *)(in_a0 + aiStack144[0]) = *pcStack120;
                                aiStack144[0] = aiStack144[0] + 1;
                                pcStack120 = pcStack120 + 1;
                            }
                            if (uStack128 != 0) {
                                iStack124 = 0;
                                while (iStack124 < iVar3 - iVar4) {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStackX4 = pcStackX4 + 1;
                            ppcStackX8 = ppcStackX8 + 1;
                        } else {
                            if (*pcStackX4 == 'd') {
                                pcStack92 = *ppcStackX8;
                                fcn.bfc04b30(piVar10[0xb], piVar10[0xc], piVar10[1], piVar10[-1], *piVar10);
                                iVar3 = aiStack144[1];
                                iVar4 = strlen(piVar10[4], *piVar10);
                                piVar10 = piVar10 + 2;
                                if (uStack128 == 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iVar3 - iVar4) {
                                        if (aiStack144[3] == 0) {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                        } else {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                        }
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStack116 = acStack80;
                                while (*pcStack116 != '\0') {
                                    *(char *)(in_a0 + aiStack144[0]) = *pcStack116;
                                    aiStack144[0] = aiStack144[0] + 1;
                                    pcStack116 = pcStack116 + 1;
                                }
                                if (uStack128 != 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iVar3 - iVar4) {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStackX4 = pcStackX4 + 1;
                                ppcStackX8 = ppcStackX8 + 1;
                            } else {
                                if (*pcStackX4 == 'x') {
                                    pcStack96 = *ppcStackX8;
                                    fcn.bfc04cb0(piVar10[0xb], piVar10[0xc], piVar10[1], piVar10[-1], *piVar10);
                                    iVar3 = aiStack144[1];
                                    iVar4 = strlen(piVar10[4], *piVar10);
                                    piVar10 = piVar10 + 2;
                                    if (uStack128 == 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iVar3 - iVar4) {
                                            if (aiStack144[3] == 0) {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                            } else {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                            }
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStack112 = acStack80;
                                    while (*pcStack112 != '\0') {
                                        *(char *)(in_a0 + aiStack144[0]) = *pcStack112;
                                        aiStack144[0] = aiStack144[0] + 1;
                                        pcStack112 = pcStack112 + 1;
                                    }
                                    if (uStack128 != 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iVar3 - iVar4) {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStackX4 = pcStackX4 + 1;
                                    ppcStackX8 = ppcStackX8 + 1;
                                } else {
                                    if (*pcStackX4 == 's') {
                                        pcStack108 = *ppcStackX8;
                                        piVar9 = piVar10;
                                        if (aiStack144[2] < 1) {
code_r0xbfc063a0:
                                            uStack104 = strlen(*(int32_t *)((int32_t)piVar9 + 0xc), 
                                                               *(int32_t *)((int32_t)piVar9 + -4));
                                            piVar10 = (int32_t *)((int32_t)piVar9 + 4);
                                        } else {
                                            uVar5 = strlen(piVar10[3], piVar10[-1]);
                                            piVar9 = piVar10 + 1;
                                            piVar10 = piVar10 + 1;
                                            if (uVar5 <= (uint32_t)aiStack144[2]) goto code_r0xbfc063a0;
                                            uStack104 = aiStack144[2];
                                        }
                                        aiStack144[1] = aiStack144[1] - uStack104;
                                        if (uStack128 == 0) {
                                            iStack124 = 0;
                                            while (iStack124 < aiStack144[1]) {
                                                if (aiStack144[3] == 0) {
                                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                                } else {
                                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                                }
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        while ((*pcStack108 != '\0' && (0 < (int32_t)uStack104))) {
                                            *(char *)(in_a0 + aiStack144[0]) = *pcStack108;
                                            aiStack144[0] = aiStack144[0] + 1;
                                            pcStack108 = pcStack108 + 1;
                                            uStack104 = uStack104 - 1;
                                        }
                                        if (uStack128 != 0) {
                                            iStack124 = 0;
                                            while (iStack124 < aiStack144[1]) {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        pcStackX4 = pcStackX4 + 1;
                                        ppcStackX8 = ppcStackX8 + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                *(char *)(in_a0 + aiStack144[0]) = *pcStackX4;
                pcStackX4 = pcStackX4 + 1;
                aiStack144[0] = aiStack144[0] + 1;
            }
        }
        *(undefined *)(in_a0 + aiStack144[0]) = 0;
    }
    return aiStack144[0];
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fprintf failed, args may be inaccurate.

undefined4
printf(undefined4 arg_8h, int32_t arg_1024h, int32_t arg_1028h, int32_t arg_102ch, int32_t arg_14h, int32_t arg_10h)
{
    undefined4 uVar1;
    undefined4 in_a0;
    undefined auStackX4 [8];
    int32_t in_stack_ffffefec;
    int32_t in_stack_ffffeff0;
    int32_t in_stack_ffffeff8;
    int32_t in_stack_ffffeffc;
    int32_t in_stack_fffff000;
    int32_t in_stack_fffff004;
    int32_t in_stack_fffff008;
    int32_t in_stack_fffff00c;
    int32_t in_stack_fffff010;
    int32_t in_stack_fffff014;
    int32_t in_stack_fffff018;
    int32_t in_stack_fffff01c;
    int32_t in_stack_fffff020;
    int32_t in_stack_fffff024;
    int32_t in_stack_fffff028;
    int32_t in_stack_fffff02c;
    int32_t in_stack_fffff07c;
    int32_t in_stack_fffff080;
    
    uVar1 = fprintf(in_a0, in_stack_fffff07c, in_stack_fffff080, in_stack_ffffefec, in_stack_ffffeff0, 
                    (int32_t)auStackX4, in_stack_ffffeff8, in_stack_ffffeffc, in_stack_fffff018, in_stack_fffff010, 
                    in_stack_fffff014, in_stack_fffff000, in_stack_fffff01c, in_stack_fffff02c, in_stack_fffff00c, 
                    in_stack_fffff020, in_stack_fffff008, in_stack_fffff024, in_stack_fffff004, in_stack_fffff028);
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fprintf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function putc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function isdigit failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function atoi failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

int32_t fprintf(char *arg_8h, int32_t arg_a0h, int32_t arg_a4h, int32_t arg_10h, int32_t arg_14h, int32_t arg_18h,
               int32_t arg_1ch, int32_t arg_20h, int32_t arg_3ch, int32_t arg_34h, int32_t arg_38h, int32_t arg_24h,
               int32_t arg_40h, int32_t arg_0h, int32_t arg_30h, int32_t arg_44h, int32_t arg_2ch, int32_t arg_48h,
               int32_t arg_28h, int32_t arg_4ch)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    char **in_a1;
    undefined *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    int32_t *piVar13;
    int32_t *piVar14;
    char *pcStackX0;
    char **ppcStackX4;
    undefined auStack160 [16];
    int32_t aiStack144 [4];
    uint32_t uStack128;
    int32_t iStack124;
    char *pcStack120;
    char *pcStack116;
    char *pcStack112;
    char *pcStack108;
    uint32_t uStack104;
    int32_t iStack100;
    char *pcStack96;
    char *pcStack92;
    char *pcStack88;
    undefined uStack84;
    char acStack80 [68];
    
    piVar14 = (int32_t *)auStack160;
    aiStack144[0] = 0;
    pcStackX0 = arg_8h;
    ppcStackX4 = in_a1;
    if (arg_8h == (char *)0x0) {
        aiStack144[0] = -1;
    } else {
        while (*pcStackX0 != '\0') {
            if (*pcStackX0 == '%') {
                pcVar2 = pcStackX0 + 1;
                aiStack144[1] = 0;
                aiStack144[2] = 0;
                aiStack144[3] = 0;
                uStack128 = 0;
                iStack100 = 0;
                if (*pcVar2 == '%') {
                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                    pcStackX0 = pcStackX0 + 2;
                    aiStack144[0] = aiStack144[0] + 1;
                } else {
                    pcVar1 = pcVar2;
                    if (*pcVar2 == '-') {
                        uStack128 = 1;
                        pcVar1 = pcStackX0 + 2;
                    }
                    pcStackX0 = pcVar1;
                    uStack128 = (uint32_t)(*pcVar2 == '-');
                    iVar3 = isdigit(*(int32_t *)((int32_t)piVar14 + 4));
                    puVar6 = (undefined *)((int32_t)piVar14 + 4);
                    if (iVar3 != 0) {
                        if (*pcStackX0 == '0') {
                            aiStack144[3] = 1;
                            pcStackX0 = pcStackX0 + 1;
                        }
                        iVar3 = isdigit(*(int32_t *)((int32_t)piVar14 + 8));
                        puVar6 = (undefined *)((int32_t)piVar14 + 8);
                        if (iVar3 != 0) {
                            aiStack144[1] =
                                 atoi(*(int32_t *)((int32_t)piVar14 + 0x2c), *(int32_t *)((int32_t)piVar14 + 0x14), 
                                      *(int32_t *)((int32_t)piVar14 + 0x18), *(int32_t *)((int32_t)piVar14 + 0x20), 
                                      *(int32_t *)((int32_t)piVar14 + 0x1c));
                            puVar7 = (undefined *)((int32_t)piVar14 + 0xc);
                            while( true ) {
                                iVar3 = isdigit(*(int32_t *)(puVar7 + 4));
                                puVar6 = puVar7 + 4;
                                puVar7 = puVar7 + 4;
                                if (iVar3 == 0) break;
                                pcStackX0 = pcStackX0 + 1;
                            }
                        }
                    }
                    piVar14 = (int32_t *)puVar6;
                    if (*pcStackX0 == '.') {
                        aiStack144[2] =
                             atoi(*(int32_t *)(puVar6 + 0x24), *(int32_t *)(puVar6 + 0xc), *(int32_t *)(puVar6 + 0x10), 
                                  *(int32_t *)(puVar6 + 0x18), *(int32_t *)(puVar6 + 0x14));
                        puVar8 = puVar6 + 4;
                        do {
                            pcStackX0 = pcStackX0 + 1;
                            iVar3 = isdigit(*(int32_t *)(puVar8 + 4));
                            piVar14 = (int32_t *)(puVar8 + 4);
                            puVar8 = puVar8 + 4;
                        } while (iVar3 != 0);
                    }
                    if (*pcStackX0 == 'c') {
                        uStack84 = (char)*ppcStackX4;
                        iStack100 = aiStack144[1] + -1;
                        if (uStack128 == 0) {
                            iStack124 = 0;
                            while (iStack124 < iStack100) {
                                if (aiStack144[3] == 0) {
                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                } else {
                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                }
                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        putc(*(int32_t *)((int32_t)piVar14 + 4));
                        puVar9 = (undefined *)((int32_t)piVar14 + 4);
                        aiStack144[0] = aiStack144[0] + 1;
                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                        if (uStack128 != 0) {
                            iStack124 = 0;
                            while (piVar14 = (int32_t *)puVar9, iStack124 < iStack100) {
                                putc(*(int32_t *)(puVar9 + 4));
                                puVar9 = puVar9 + 4;
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        pcStackX0 = pcStackX0 + 1;
                        ppcStackX4 = ppcStackX4 + 1;
                    } else {
                        if (*pcStackX0 == 'u') {
                            pcStack88 = *ppcStackX4;
                            fcn.bfc049ec(piVar14[0xb], piVar14[0xc], piVar14[1], piVar14[-1], *piVar14);
                            iVar3 = aiStack144[1];
                            iVar4 = strlen(piVar14[4], *piVar14);
                            piVar10 = piVar14 + 2;
                            iStack100 = iVar3 - iVar4;
                            piVar14 = piVar14 + 2;
                            if (uStack128 == 0) {
                                iStack124 = 0;
                                while (piVar14 = piVar10, iStack124 < iStack100) {
                                    if (aiStack144[3] == 0) {
                                        putc(*(int32_t *)((int32_t)piVar10 + 4));
                                    } else {
                                        putc(*(int32_t *)((int32_t)piVar10 + 4));
                                    }
                                    piVar10 = (int32_t *)((int32_t)piVar10 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStack120 = acStack80;
                            while (*pcStack120 != '\0') {
                                putc(*(int32_t *)((int32_t)piVar14 + 4));
                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                aiStack144[0] = aiStack144[0] + 1;
                                pcStack120 = pcStack120 + 1;
                            }
                            if (uStack128 != 0) {
                                iStack124 = 0;
                                while (iStack124 < iStack100) {
                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStackX0 = pcStackX0 + 1;
                            ppcStackX4 = ppcStackX4 + 1;
                        } else {
                            if (*pcStackX0 == 'd') {
                                pcStack92 = *ppcStackX4;
                                fcn.bfc04b30(piVar14[0xb], piVar14[0xc], piVar14[1], piVar14[-1], *piVar14);
                                iVar3 = aiStack144[1];
                                iVar4 = strlen(piVar14[4], *piVar14);
                                piVar11 = piVar14 + 2;
                                iStack100 = iVar3 - iVar4;
                                piVar14 = piVar14 + 2;
                                if (uStack128 == 0) {
                                    iStack124 = 0;
                                    while (piVar14 = piVar11, iStack124 < iStack100) {
                                        if (aiStack144[3] == 0) {
                                            putc(*(int32_t *)((int32_t)piVar11 + 4));
                                        } else {
                                            putc(*(int32_t *)((int32_t)piVar11 + 4));
                                        }
                                        piVar11 = (int32_t *)((int32_t)piVar11 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStack116 = acStack80;
                                while (*pcStack116 != '\0') {
                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    pcStack116 = pcStack116 + 1;
                                }
                                if (uStack128 != 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iStack100) {
                                        putc(*(int32_t *)((int32_t)piVar14 + 4));
                                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStackX0 = pcStackX0 + 1;
                                ppcStackX4 = ppcStackX4 + 1;
                            } else {
                                if (*pcStackX0 == 'x') {
                                    pcStack96 = *ppcStackX4;
                                    fcn.bfc04cb0(piVar14[0xb], piVar14[0xc], piVar14[1], piVar14[-1], *piVar14);
                                    iVar3 = aiStack144[1];
                                    iVar4 = strlen(piVar14[4], *piVar14);
                                    piVar12 = piVar14 + 2;
                                    iStack100 = iVar3 - iVar4;
                                    piVar14 = piVar14 + 2;
                                    if (uStack128 == 0) {
                                        iStack124 = 0;
                                        while (piVar14 = piVar12, iStack124 < iStack100) {
                                            if (aiStack144[3] == 0) {
                                                putc(*(int32_t *)((int32_t)piVar12 + 4));
                                            } else {
                                                putc(*(int32_t *)((int32_t)piVar12 + 4));
                                            }
                                            piVar12 = (int32_t *)((int32_t)piVar12 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStack112 = acStack80;
                                    while (*pcStack112 != '\0') {
                                        putc(*(int32_t *)((int32_t)piVar14 + 4));
                                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        pcStack112 = pcStack112 + 1;
                                    }
                                    if (uStack128 != 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iStack100) {
                                            putc(*(int32_t *)((int32_t)piVar14 + 4));
                                            piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStackX0 = pcStackX0 + 1;
                                    ppcStackX4 = ppcStackX4 + 1;
                                } else {
                                    if (*pcStackX0 == 's') {
                                        pcStack108 = *ppcStackX4;
                                        piVar13 = piVar14;
                                        if (aiStack144[2] < 1) {
code_r0xbfc05778:
                                            uStack104 = strlen(*(int32_t *)((int32_t)piVar13 + 0xc), 
                                                               *(int32_t *)((int32_t)piVar13 + -4));
                                            piVar14 = (int32_t *)((int32_t)piVar13 + 4);
                                        } else {
                                            uVar5 = strlen(piVar14[3], piVar14[-1]);
                                            piVar13 = piVar14 + 1;
                                            piVar14 = piVar14 + 1;
                                            if (uVar5 <= (uint32_t)aiStack144[2]) goto code_r0xbfc05778;
                                            uStack104 = aiStack144[2];
                                        }
                                        iStack100 = aiStack144[1] - uStack104;
                                        if (uStack128 == 0) {
                                            iStack124 = 0;
                                            while (iStack124 < iStack100) {
                                                if (aiStack144[3] == 0) {
                                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                                } else {
                                                    putc(*(int32_t *)((int32_t)piVar14 + 4));
                                                }
                                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        while ((*pcStack108 != '\0' && (0 < (int32_t)uStack104))) {
                                            putc(*(int32_t *)((int32_t)piVar14 + 4));
                                            piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            pcStack108 = pcStack108 + 1;
                                            uStack104 = uStack104 - 1;
                                        }
                                        if (uStack128 != 0) {
                                            iStack124 = 0;
                                            while (iStack124 < iStack100) {
                                                putc(*(int32_t *)((int32_t)piVar14 + 4));
                                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        pcStackX0 = pcStackX0 + 1;
                                        ppcStackX4 = ppcStackX4 + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                putc(*(int32_t *)((int32_t)piVar14 + 4));
                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                pcStackX0 = pcStackX0 + 1;
                aiStack144[0] = aiStack144[0] + 1;
            }
        }
    }
    return aiStack144[0];
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

int32_t fcn.bfc07d50(int32_t arg2)
{
    int32_t in_a0;
    
    if (arg2 != 0) {
        if (*(int32_t *)(arg2 + 8) != in_a0) {
            return 0;
        }
        arg2 = *(int32_t *)arg2;
    }
    return arg2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc042dc failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc040f4 failed, args may be inaccurate.

int32_t fcn.bfc042dc(int32_t arg1)
{
    int32_t iVar1;
    int32_t in_a1;
    int32_t in_a2;
    int32_t in_a3;
    
    if (in_a3 != 0) {
        iVar1 = fcn.bfc040f4(*(int32_t *)(arg1 + 0xc));
        if (iVar1 != 0) {
            *(int32_t *)(arg1 + (in_a2 + 4) * 4) = iVar1;
            if (in_a1 != 0) {
                *(undefined *)(arg1 + 0x53) = 1;
                *(char *)(arg1 + 0x52) = (char)in_a2;
                return in_a1;
            }
            return 1;
        }
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04364 failed, args may be inaccurate.

char fcn.bfc04364(int32_t arg1, int32_t arg2, int32_t arg3)
{
    char cVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    
    cVar1 = *(char *)(arg1 + 0x53);
    uVar2 = 0;
    if (cVar1 != '\0') {
        uVar3 = 0;
        do {
            if (*(int32_t *)(arg1 + (uVar2 + 4) * 4) != 0) {
                uVar3 = uVar3 + 1 & 0xff;
            }
            uVar2 = uVar2 + 1 & 0xff;
        } while (uVar2 <= *(uint8_t *)(arg1 + 0x52));
        cVar1 = *(uint8_t *)(arg1 + 0x52) + 1 == uVar3;
    }
    return cVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04414 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc043c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.

undefined4 fcn.bfc04414(int32_t arg1)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t in_a1;
    uint32_t in_a2;
    undefined2 *in_a3;
    int32_t *piVar3;
    int32_t iVar4;
    undefined *puVar5;
    int32_t iStack40;
    undefined auStack36 [12];
    
    uVar1 = fcn.bfc043c0(arg1, in_a1);
    puVar5 = auStack36;
    uVar2 = 0;
    if (uVar1 <= in_a2) {
        piVar3 = (int32_t *)(arg1 + 0x10);
        iVar4 = 0;
        do {
            if (*piVar3 != 0) {
                fcn.bfc07918(in_a1 + iVar4, *(int32_t *)(puVar5 + 0xc), *(int32_t *)(puVar5 + 0x10), 
                             *(int32_t *)(puVar5 + 0x14), *(int32_t *)(puVar5 + -4));
                puVar5 = puVar5 + 4;
                iVar4 = iVar4 + (uint32_t)*(uint8_t *)(*piVar3 + 4);
            }
            piVar3 = piVar3 + 1;
            uVar2 = 1;
        } while (piVar3 != (int32_t *)(arg1 + 0x50));
        *in_a3 = (int16_t)iVar4;
    }
    return uVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc03efc(int32_t arg_18h, int32_t arg_1ch)
{
    int32_t in_a0;
    int32_t in_a1;
    int32_t unaff_s8;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    int32_t in_stack_fffffff4;
    
    fcn.bfc06d40(in_a0, in_a1, in_stack_ffffffe4, unaff_s8, in_stack_ffffffe8, in_stack_ffffffec, in_stack_fffffff0, 
                 in_stack_fffffff4);
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc06d40(int32_t arg1, int32_t arg_20h, int32_t arg_0h, int32_t arg_14h, int32_t arg_4h, int32_t arg_8h,
                 int32_t arg_ch, int32_t arg_10h)
{
    uint32_t *puVar1;
    uint32_t *puVar2;
    uint32_t *puVar3;
    int32_t iVar4;
    uint32_t **ppuVar5;
    
    puVar2 = (uint32_t *)(arg1 + -4);
    puVar1 = *(uint32_t **)0xa0180d90;
    if ((*puVar2 & 1) != 0) {
        puVar1 = puVar2;
        if (((*puVar2 & 2) == 0) || (puVar3 = (uint32_t *)(arg1 + (*puVar2 & 0xfffffffc)), (*puVar3 & 1) != 0)) {
            *puVar2 = *puVar2 & 0xfffffffe;
            ppuVar5 = (uint32_t **)((int32_t)puVar2 + ((*puVar2 & 0xfffffffc) - 4));
            *ppuVar5 = *(uint32_t **)0xa0180d90;
            ppuVar5[1] = (uint32_t *)0x0;
            if (*(uint32_t **)0xa0180d90 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*(uint32_t **)0xa0180d90 + (**(uint32_t **)0xa0180d90 & 0xfffffffc)) = puVar2;
            }
        } else {
            iVar4 = (*puVar2 & 0xfffffffc) + (*puVar3 & 0xfffffffc);
            *puVar2 = iVar4 + 4;
            if ((*puVar3 & 2) != 0) {
                *puVar2 = *puVar2 | 2;
            }
            if (puVar3 == *(uint32_t **)0xa0180d90) {
                ppuVar5 = (uint32_t **)((int32_t)puVar2 + iVar4);
                if (*ppuVar5 != (uint32_t *)0x0) {
                    *(uint32_t **)0xa0180d90 = puVar2;
                    *(uint32_t **)((int32_t)*ppuVar5 + (**ppuVar5 & 0xfffffffc)) = puVar2;
                    puVar1 = *(uint32_t **)0xa0180d90;
                }
            } else {
                ppuVar5 = (uint32_t **)((int32_t)puVar2 + iVar4);
                if (ppuVar5[1] != (uint32_t *)0x0) {
                    *(uint32_t **)((int32_t)ppuVar5[1] + ((*ppuVar5[1] & 0xfffffffc) - 4)) = puVar2;
                }
                puVar1 = *(uint32_t **)0xa0180d90;
                if (*ppuVar5 != (uint32_t *)0x0) {
                    *(uint32_t **)((int32_t)*ppuVar5 + (**ppuVar5 & 0xfffffffc)) = puVar2;
                    puVar1 = *(uint32_t **)0xa0180d90;
                }
            }
        }
    }
    *(uint32_t **)0xa0180d90 = puVar1;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04278 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc041a0 failed, args may be inaccurate.

undefined4 fcn.bfc04278(int32_t arg1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int32_t *piVar4;
    undefined *puVar5;
    undefined auStack32 [16];
    
    puVar5 = auStack32;
    piVar4 = (int32_t *)(arg1 + 0x10);
    do {
        if (*piVar4 != 0) {
            fcn.bfc041a0(*(undefined4 *)(arg1 + 0xc), *piVar4, *puVar5);
            puVar5 = puVar5 + 4;
        }
        *piVar4 = 0;
        piVar4 = piVar4 + 1;
    } while (piVar4 != (int32_t *)(arg1 + 0x50));
    if (*(int32_t **)(arg1 + 8) != (int32_t *)0x0) {
        uVar1 = 0;
        if ((arg1 != 0) && (piVar4 = *(int32_t **)(arg1 + 8), piVar4 == *(int32_t **)(arg1 + 8))) {
            iVar3 = *(int32_t *)arg1;
            if (iVar3 != 0) {
                *(undefined4 *)(iVar3 + 4) = *(undefined4 *)(arg1 + 4);
            }
            piVar2 = *(int32_t **)(arg1 + 4);
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar3;
            }
            if (arg1 == piVar4[2]) {
                piVar4[2] = (int32_t)piVar2;
            }
            if (arg1 == piVar4[1]) {
                piVar4[1] = *(int32_t *)arg1;
            }
            iVar3 = *piVar4;
            *(undefined4 *)(arg1 + 8) = 0;
            *piVar4 = iVar3 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04214 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d30 failed, args may be inaccurate.

void fcn.bfc04214(int32_t param_1, undefined2 param_2, undefined4 param_3)
{
    undefined4 *puVar1;
    
    fcn.bfc07d30(param_1);
    *(undefined4 *)(param_1 + 0xc) = param_3;
    *(undefined2 *)(param_1 + 0x50) = param_2;
    *(undefined *)(param_1 + 0x52) = 0;
    *(undefined *)(param_1 + 0x53) = 0;
    puVar1 = (undefined4 *)(param_1 + 0x10);
    do {
        *puVar1 = 0;
        puVar1 = puVar1 + 1;
    } while (puVar1 != (undefined4 *)(param_1 + 0x50));
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03fd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.

void fcn.bfc03fd8(undefined4 *param_1)
{
    undefined4 uVar1;
    int32_t unaff_retaddr;
    
    uVar1 = fcn.bfc03e88(unaff_retaddr);
    *param_1 = uVar1;
    param_1[1] = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d40 failed, args may be inaccurate.

void fcn.bfc07d40(int32_t arg1)
{
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02cd0 failed, args may be inaccurate.

void fcn.bfc02cd0(int32_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = *(undefined4 *)0xa1010004;
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)arg1 = uVar1;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02ce4 failed, args may be inaccurate.

void fcn.bfc02ce4(void)
{
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08024 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

void fcn.bfc08024(undefined4 *param_1, undefined4 param_2)
{
    int32_t *arg1;
    int32_t iVar1;
    undefined *puVar2;
    undefined auStack32 [20];
    
    puVar2 = auStack32;
    arg1 = (int32_t *)param_1[1];
    while (arg1 != (int32_t *)0x0) {
        iVar1 = *arg1;
        fcn.bfc07f9c(arg1, param_2, *puVar2);
        param_2 = 0xc;
        fcn.bfc03efc(*(int32_t *)(puVar2 + 0x18), *(int32_t *)(puVar2 + 0x1c));
        puVar2 = puVar2 + 8;
        arg1 = (int32_t *)iVar1;
    }
    param_1[1] = 0;
    param_1[2] = 0;
    *param_1 = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

void fcn.bfc009a4(int32_t arg2, int32_t arg4, int32_t arg3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    
    uVar3 = *(uint32_t *)arg2;
    uVar2 = *(uint32_t *)(arg2 + 4);
    uVar1 = 0x3e778b90;
    do {
        uVar4 = uVar1 + *(int32_t *)(arg3 + (uVar1 & 3) * 4);
        uVar1 = uVar1 + 0x83e778b9;
        uVar3 = uVar3 + (uVar4 ^ (uVar2 << 4 ^ uVar2 >> 5) + uVar2);
        uVar2 = uVar2 + (uVar1 + *(int32_t *)(arg3 + (uVar1 >> 9 & 0xc)) ^ (uVar3 * 0x10 ^ uVar3 >> 5) + uVar3);
    } while (uVar1 != 0x7cef1720);
    *(uint32_t *)arg2 = uVar3;
    *(uint32_t *)(arg2 + 4) = uVar2;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00ac0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

uint32_t fcn.bfc00ac0(int32_t arg1, int32_t arg2, int32_t arg3)
{
    undefined4 in_a3;
    uint8_t *puVar1;
    uint32_t uVar2;
    uint8_t *puVar3;
    uint32_t uVar4;
    undefined *puVar5;
    undefined auStack32 [20];
    
    uVar4 = (uint32_t)*(uint8_t *)(arg1 + 0x31);
    if (uVar4 != 0) {
        puVar5 = auStack32;
        puVar3 = (uint8_t *)(arg2 + arg3);
        puVar1 = (uint8_t *)arg2;
        while (puVar3 != puVar1) {
            uVar2 = (uint32_t)(puVar1 + -arg2) & 7;
            if (uVar2 == 0) {
                fcn.bfc009a4(arg1 + 0x48, in_a3, arg1 + 0x34, *puVar5);
                puVar5 = puVar5 + 4;
            }
            *puVar1 = *(uint8_t *)(arg1 + 0x48 + uVar2) ^ *puVar1;
            puVar1 = puVar1 + 1;
        }
        return uVar4;
    }
    return 0;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function memset failed, args may be inaccurate.

int32_t memset(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_0h, int32_t arg_4h)
{
    int32_t in_a0;
    undefined in_a1;
    uint32_t in_a2;
    uint32_t uStack16;
    
    uStack16 = 0;
    while (uStack16 < in_a2) {
        *(undefined *)(in_a0 + uStack16) = in_a1;
        uStack16 = uStack16 + 1;
    }
    return in_a0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.

void fcn.bfc01864(int32_t arg2, int32_t arg1)
{
    *(char *)arg1 = (char)arg2;
    *(char *)(arg1 + 1) = (char)((uint32_t)arg2 >> 8);
    *(char *)(arg1 + 2) = (char)((uint32_t)arg2 >> 0x10);
    *(char *)(arg1 + 3) = (char)((uint32_t)arg2 >> 0x18);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01908 failed, args may be inaccurate.

void fcn.bfc01908(int32_t arg1, int32_t arg2)
{
    *(char *)arg1 = (char)arg2;
    *(char *)(arg1 + 1) = (char)((uint32_t)arg2 >> 8);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00a30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

uint32_t fcn.bfc00a30(int32_t arg1, int32_t arg2, int32_t arg3)
{
    undefined4 in_a3;
    uint8_t *puVar1;
    uint32_t uVar2;
    uint8_t *puVar3;
    uint32_t uVar4;
    undefined *puVar5;
    undefined auStack32 [20];
    
    uVar4 = (uint32_t)*(uint8_t *)(arg1 + 0x31);
    if (uVar4 != 0) {
        puVar5 = auStack32;
        puVar3 = (uint8_t *)(arg2 + arg3);
        puVar1 = (uint8_t *)arg2;
        while (puVar3 != puVar1) {
            uVar2 = (uint32_t)(puVar1 + -arg2) & 7;
            if (uVar2 == 0) {
                fcn.bfc009a4(arg1 + 0x50, in_a3, arg1 + 0x34, *puVar5);
                puVar5 = puVar5 + 4;
            }
            *puVar1 = *(uint8_t *)(arg1 + 0x50 + uVar2) ^ *puVar1;
            puVar1 = puVar1 + 1;
        }
        return uVar4;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d04 failed, args may be inaccurate.

int32_t fcn.bfc02d04(int32_t arg1)
{
    return *(int32_t *)0xa1010004 - *(int32_t *)arg1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fc4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

void fcn.bfc07fc4(int32_t arg1, int32_t arg3, int32_t arg2)
{
    int32_t *arg1_00;
    int32_t iVar1;
    undefined *puVar2;
    undefined auStack32 [20];
    
    puVar2 = auStack32;
    arg1_00 = (int32_t *)*(int32_t *)(arg1 + 4);
    while (arg1_00 != (int32_t *)0x0) {
        iVar1 = *arg1_00;
        fcn.bfc07f9c(arg1_00, arg2, *puVar2);
        arg2 = 0xc;
        fcn.bfc03efc(*(int32_t *)(puVar2 + 0x18), *(int32_t *)(puVar2 + 0x1c));
        puVar2 = puVar2 + 8;
        arg1_00 = (int32_t *)iVar1;
    }
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)arg1 = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc018f4 failed, args may be inaccurate.

uint32_t fcn.bfc018f4(int32_t arg1)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t in_v0;
    
    uVar1 = arg1 + 3U & 3;
    uVar2 = arg1 & 3;
    return (*(int32_t *)((arg1 + 3U) - uVar1) << (3 - uVar1) * 8 | in_v0 & 0xffffffffU >> (uVar1 + 1) * 8) &
           -1 << (4 - uVar2) * 8 | *(uint32_t *)(arg1 - uVar2) >> uVar2 * 8;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc013e8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d04 failed, args may be inaccurate.

void fcn.bfc013e8(int32_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = fcn.bfc02d04(arg1 + 0x20);
    *(undefined4 *)(arg1 + 0x2c) = uVar1;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01af4 failed, args may be inaccurate.

bool fcn.bfc01af4(int32_t arg1)
{
    return *(int32_t *)(arg1 + 0x10) != 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01aac failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0802c failed, args may be inaccurate.

undefined4 fcn.bfc01aac(int32_t arg1)
{
    undefined4 uVar1;
    
    if (*(int32_t *)(arg1 + 0x10) != 0) {
        uVar1 = fcn.bfc0802c(arg1);
        *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -1;
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0802c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f08 failed, args may be inaccurate.

undefined4 fcn.bfc0802c(int32_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = *(undefined4 *)(arg1 + 4);
    fcn.bfc07f08(arg1, uVar1);
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.

undefined4 fcn.bfc07f9c(int32_t arg1, int32_t arg2)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if (*(int32_t **)(arg1 + 8) != (int32_t *)0x0) {
        uVar1 = 0;
        if ((arg1 != 0) && (piVar3 = *(int32_t **)(arg1 + 8), piVar3 == *(int32_t **)(arg1 + 8))) {
            iVar4 = *(int32_t *)arg1;
            if (iVar4 != 0) {
                *(undefined4 *)(iVar4 + 4) = *(undefined4 *)(arg1 + 4);
            }
            piVar2 = *(int32_t **)(arg1 + 4);
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (arg1 == piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (arg1 == piVar3[1]) {
                piVar3[1] = *(int32_t *)arg1;
            }
            iVar4 = *piVar3;
            *(undefined4 *)(arg1 + 8) = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01454 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc018f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fc4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00ac0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc042dc failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04364 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04414 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04278 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04214 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

uint32_t fcn.bfc01454(int32_t arg3, int32_t arg2, int32_t arg1, int32_t arg4)
{
    bool bVar1;
    char cVar2;
    uint8_t uVar3;
    undefined *puVar4;
    undefined4 arg1_00;
    uint32_t uVar5;
    int32_t *piVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    undefined uVar10;
    int32_t iVar11;
    int32_t iVar12;
    int32_t unaff_s1;
    int32_t unaff_s2;
    uint32_t uVar13;
    int32_t unaff_s3;
    uint32_t uVar14;
    int32_t unaff_s4;
    int32_t unaff_s5;
    int32_t *piVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    int32_t *piVar22;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t iStackX4;
    undefined auStackX8 [8];
    int32_t in_stack_fffffac8;
    int32_t in_stack_fffffacc;
    undefined auStack1328 [20];
    undefined auStack1308 [4];
    undefined auStack1304 [1268];
    undefined auStack36 [4];
    undefined auStack32 [16];
    
    if ((uint32_t)arg3 < 5 != 0) {
        return (uint32_t)((uint32_t)arg3 < 5);
    }
    cVar2 = *(char *)arg2;
    if (cVar2 == '1') {
        if (arg3 == 5) {
            return 5;
        }
        uVar5 = fcn.bfc018f4(arg2 + 1);
        if (*(uint32_t *)(arg1 + 0x28) < uVar5) {
            *(uint32_t *)(arg1 + 0x28) = uVar5;
        }
        uVar3 = *(uint8_t *)(arg2 + 5);
        uVar5 = (uint32_t)uVar3;
        *(uint8_t *)(arg1 + 0x30) = uVar3;
        *(undefined4 *)(arg1 + 0x58) = 0;
        fcn.bfc07fc4(arg1 + 0x10, arg3, uVar5);
        if ((uVar3 & 3) != 0) {
            uVar5 = (uVar5 & 0xfc) + 4 & 0xff;
        }
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        uVar7 = 0;
        while (iVar11 = *(int32_t *)(arg1 + 8), uVar7 <= 0x10000 - (uVar5 + 0x10)) {
            iVar9 = *(int32_t *)arg1;
            iVar12 = *(int32_t *)(arg1 + 4);
            piVar6 = (int32_t *)(iVar9 + uVar7);
            if (iVar12 == 0) {
                piVar6[3] = 0;
                piVar6[2] = 0;
            } else {
                piVar6[2] = iVar12;
                piVar6[3] = 0;
                *(int32_t **)(iVar12 + 0xc) = piVar6;
            }
            *(int32_t *)(arg1 + 8) = iVar11 + 1;
            iVar11 = uVar7 + 0x10;
            *(int32_t **)(arg1 + 4) = piVar6;
            uVar7 = uVar7 + uVar5 + 0x10;
            *piVar6 = iVar9 + iVar11;
        }
        uVar5 = printf2(4, 0x10000, -0x5fe7f5d4);
        *(undefined4 *)(arg1 + 0xc) = 0;
        return uVar5;
    }
    if (cVar2 == 'J') {
        uVar5 = fcn.bfc018f4(arg2 + 1);
        if (uVar5 <= *(uint32_t *)(arg1 + 0x28)) {
            return uVar5;
        }
        *(uint32_t *)(arg1 + 0x28) = uVar5;
        return uVar5;
    }
    uVar5 = (uint32_t)((uint32_t)arg3 < 8);
    if (cVar2 != '7') {
        return uVar5;
    }
    if (uVar5 != 0) {
        return uVar5;
    }
    uVar5 = fcn.bfc018f4(arg2 + 1);
    if (*(uint32_t *)(arg1 + 0x28) < uVar5) {
        *(uint32_t *)(arg1 + 0x28) = uVar5;
    }
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 5);
    uVar5 = arg3 - 6;
    if (uVar7 == 0x73) {
        puVar20 = auStack36;
        uVar7 = (uint32_t)*(uint8_t *)(arg1 + 0x30);
        uVar8 = uVar7 - 1;
        if (uVar8 == uVar5) {
            uVar14 = uVar7;
            if (*(char *)(arg1 + 0x31) != '\0') {
                uVar14 = uVar8;
                iVar11 = fcn.bfc00ac0(arg1, arg2 + 6, uVar8);
                puVar20 = auStack32;
                uVar5 = uVar8;
                if (iVar11 != 0) {
                    uVar5 = fcn.bfc01918(arg2 + 6);
                    uVar13 = (int32_t)uVar5 >> 4 & 0x7ff;
                    uVar14 = uVar5 & 0xf;
                    uVar8 = fcn.bfc07cd8(in_stack_fffffac8);
                    puVar16 = &stack0xfffffac8;
                    if (0x10 < uVar8) {
                        uVar8 = fcn.bfc07cd8(in_stack_fffffacc);
                        puVar16 = &stack0xfffffacc;
                        if (0x10 < uVar8) {
                            uVar5 = printf2(4, *(int32_t *)(arg1 + 0x58), -0x5fe7ff70);
                            return uVar5;
                        }
                    }
                    uVar8 = *(uint32_t *)(arg1 + 0x14);
                    do {
                        if (uVar8 == 0) {
                            uVar8 = fcn.bfc03e50(*(int32_t *)(puVar16 + 0x14));
                            fcn.bfc04214(uVar8, uVar13, arg1);
                            *(uint32_t *)(puVar16 + 0x18) = uVar7 - 3 & 0xffff;
                            fcn.bfc042dc(uVar8, puVar16[8]);
                            uVar5 = uVar8;
                            fcn.bfc07e9c(uVar8, arg1 + 0x10, puVar16[0xc]);
                            puVar19 = puVar16 + 0x10;
code_r0xbfc00724:
                            iVar11 = fcn.bfc04364(uVar8, uVar5, uVar14, *puVar19);
                            puVar17 = puVar19 + 4;
                            if (iVar11 != 0) {
                                iVar11 = fcn.bfc04414(uVar8, puVar19[4]);
                                puVar17 = puVar19 + 8;
                                if (iVar11 != 0) {
                                    puVar4 = (undefined *)fcn.bfc03e88(*(int32_t *)(puVar19 + 0x1c));
                                    *puVar4 = 0x73;
                                    fcn.bfc07918((int32_t)(puVar4 + 1), *(int32_t *)(puVar19 + 0x18), 
                                                 *(int32_t *)(puVar19 + 0x1c), *(int32_t *)(puVar19 + 0x20), 
                                                 *(int32_t *)(puVar19 + 8));
                                    arg1_00 = fcn.bfc03e50(*(int32_t *)(puVar19 + 0x24));
                                    fcn.bfc01930(arg1_00, puVar4, *(uint16_t *)(puVar19 + 0x52c) + 1, 0xbfc0184c);
                                    iVar11 = fcn.bfc01a48(*(undefined4 *)(arg1 + 0x68), puVar19[0x18]);
                                    puVar17 = puVar19 + 0x1c;
                                    if (iVar11 == 0) {
                                        fcn.bfc01984(arg1_00, puVar19[0x1c]);
                                        fcn.bfc03efc(*(int32_t *)(puVar19 + 0x34), *(int32_t *)(puVar19 + 0x38));
                                        puVar17 = puVar19 + 0x24;
                                    }
                                }
                            }
                            uVar5 = (uint32_t)(*(uint32_t *)(arg1 + 0x58) < 0x7f0);
                            if ((*(uint32_t *)(arg1 + 0x58) < uVar13) ||
                               ((bVar1 = uVar5 == 0, uVar5 = (uint32_t)(uVar13 < 0x11), bVar1 && (uVar5 != 0)))) {
                                *(uint32_t *)(arg1 + 0x58) = uVar13;
                                iVar11 = *(int32_t *)(arg1 + 0x14);
                                puVar4 = puVar17;
                                while (puVar18 = puVar4, iVar9 = iVar11, iVar9 != 0) {
                                    iVar11 = fcn.bfc07d50(iVar9, *puVar18);
                                    uVar5 = fcn.bfc07cd8(*(int32_t *)(puVar18 + 8));
                                    uVar5 = (uint32_t)(uVar5 < 0x11);
                                    puVar4 = puVar18 + 8;
                                    if (uVar5 == 0) {
                                        uVar5 = fcn.bfc07cd8(*(int32_t *)(puVar18 + 0xc));
                                        uVar5 = (uint32_t)(uVar5 < 0x11);
                                        puVar4 = puVar18 + 0xc;
                                        if (uVar5 == 0) {
                                            fcn.bfc04278(iVar9, puVar18[0xc]);
                                            uVar5 = fcn.bfc03efc(*(int32_t *)(puVar18 + 0x24), 
                                                                 *(int32_t *)(puVar18 + 0x28));
                                            puVar4 = puVar18 + 0x14;
                                        }
                                    }
                                }
                            }
                            return uVar5;
                        }
                        if (*(uint16_t *)(uVar8 + 0x50) == uVar13) {
                            *(uint32_t *)(puVar16 + 0x10) = uVar7 - 3 & 0xffff;
                            uVar5 = uVar5 >> 0xf & 1;
                            fcn.bfc042dc(uVar8, *puVar16);
                            puVar19 = puVar16 + 4;
                            goto code_r0xbfc00724;
                        }
                        uVar8 = fcn.bfc07d50(uVar8, *puVar16);
                        puVar16 = puVar16 + 4;
                    } while( true );
                }
            }
            uVar7 = uVar14;
            in_stack_00000000 = *(int32_t *)(puVar20 + 0x24);
            unaff_s1 = *(int32_t *)(puVar20 + 0x14);
            uVar8 = 4;
            piVar22 = (int32_t *)(puVar20 + 0x28);
        } else {
            uVar8 = 2;
            piVar22 = &iStackX4;
        }
    } else {
        if (uVar7 == 0xc3) {
            puVar21 = auStack36;
            uVar7 = (uint32_t)*(uint8_t *)(arg1 + 0x30);
            uVar8 = uVar7 - 1;
            if (uVar8 == uVar5) {
                if (*(char *)(arg1 + 0x31) != '\0') {
                    uVar7 = uVar8;
                    iVar11 = unaff_retaddr;
                    unaff_retaddr = unaff_s3;
                    iVar9 = fcn.bfc00ac0(arg1, arg2 + 6, uVar8);
                    unaff_s3 = in_stack_00000000;
                    puVar21 = auStack32;
                    uVar5 = uVar8;
                    if (iVar9 != 0) {
                        uVar10 = 0xc3;
                        piVar15 = (int32_t *)auStackX8;
                        in_stack_00000000 = iStackX4;
                        unaff_s1 = unaff_s2;
                        unaff_s2 = iVar11;
                        goto code_r0xbfc00520;
                    }
                }
                in_stack_00000000 = *(int32_t *)(puVar21 + 0x24);
                unaff_s1 = *(int32_t *)(puVar21 + 0x14);
                uVar8 = 4;
                piVar22 = (int32_t *)(puVar21 + 0x28);
            } else {
                uVar8 = 2;
                piVar22 = &iStackX4;
            }
        } else {
            uVar10 = 0x17;
            if (uVar7 != 0x17) {
                return uVar7;
            }
            piVar15 = &iStackX4;
            piVar22 = &iStackX4;
            uVar7 = (uint32_t)*(uint8_t *)(arg1 + 0x30);
            if (uVar7 - 1 == uVar5) {
code_r0xbfc00520:
                piVar15[-5] = unaff_retaddr;
                piVar15[-4] = unaff_s3;
                piVar15[-1] = in_stack_00000000;
                piVar15[-2] = unaff_s5;
                piVar15[-3] = unaff_s4;
                piVar15[-6] = unaff_s2;
                piVar15[-7] = unaff_s1;
                puVar4 = (undefined *)fcn.bfc03e88(piVar15[-7]);
                *puVar4 = uVar10;
                fcn.bfc07918((int32_t)(puVar4 + 1), piVar15[-8], piVar15[-7], piVar15[-6], piVar15[-0xc]);
                iVar11 = fcn.bfc03e50(piVar15[-5]);
                fcn.bfc01930(iVar11, puVar4, uVar5 + 1, 0xbfc0184c);
                uVar5 = fcn.bfc01a48(*(undefined4 *)(arg1 + 0x68), *(undefined *)(piVar15 + -8));
                if (uVar5 == 0) {
                    fcn.bfc01984(iVar11, *(undefined *)(piVar15 + -7));
                    piVar15[5] = piVar15[5];
                    piVar15[4] = unaff_s8;
                    piVar15[6] = iVar11;
                    piVar15[7] = 0x18;
                    uVar5 = fcn.bfc06d40(piVar15[6], piVar15[7], piVar15[-1], piVar15[4], *piVar15, piVar15[1], 
                                         piVar15[2], piVar15[3]);
                    return uVar5;
                }
                return uVar5;
            }
            uVar8 = 2;
        }
    }
    *(uint32_t *)((int32_t)piVar22 + 8) = uVar7;
    *(int32_t *)((int32_t)piVar22 + -8) = unaff_s1;
    *(int32_t *)((int32_t)piVar22 + -4) = in_stack_00000000;
    *(uint32_t *)((int32_t)piVar22 + 0xc) = uVar5;
    *(undefined **)((int32_t)piVar22 + -0x10) = (undefined *)((int32_t)piVar22 + 8);
    uVar5 = 0;
    if ((uVar8 & *(uint32_t *)0xa0180050) != 0) {
        uVar5 = fcn.bfc05988(*(int32_t *)((int32_t)piVar22 + -900), *(int32_t *)((int32_t)piVar22 + -0x380), 
                             *(int32_t *)((int32_t)piVar22 + -0x37c), *(int32_t *)((int32_t)piVar22 + -0x414), 
                             *(int32_t *)((int32_t)piVar22 + -0x410), *(int32_t *)((int32_t)piVar22 + -0x40c), 
                             *(int32_t *)((int32_t)piVar22 + -0x408), *(int32_t *)((int32_t)piVar22 + -0x404), 
                             *(int32_t *)((int32_t)piVar22 + -1000), *(int32_t *)((int32_t)piVar22 + -0x3f0), 
                             *(int32_t *)((int32_t)piVar22 + -0x3ec), *(int32_t *)((int32_t)piVar22 + -0x400), 
                             *(int32_t *)((int32_t)piVar22 + -0x3e4), *(int32_t *)((int32_t)piVar22 + -0x3d4), 
                             *(int32_t *)((int32_t)piVar22 + -0x3f4), *(int32_t *)((int32_t)piVar22 + -0x3e0), 
                             *(int32_t *)((int32_t)piVar22 + -0x3f8), *(int32_t *)((int32_t)piVar22 + -0x3dc), 
                             *(int32_t *)((int32_t)piVar22 + -0x3fc), *(int32_t *)((int32_t)piVar22 + -0x3d8));
        printf(*(undefined4 *)((int32_t)piVar22 + 0xc00), *(int32_t *)((int32_t)piVar22 + 0xc04), 
               *(int32_t *)((int32_t)piVar22 + 0xc08), *(int32_t *)((int32_t)piVar22 + 0xc0c), 
               *(int32_t *)((int32_t)piVar22 + -0x40c), *(int32_t *)((int32_t)piVar22 + -0x410));
    }
    return uVar5;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01370 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memset failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00a30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01908 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

uint32_t fcn.bfc01370(int32_t arg3, int32_t arg2, int32_t arg1, int32_t arg4)
{
    undefined *puVar1;
    undefined *arg1_00;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int32_t arg3_00;
    int32_t iVar5;
    int32_t unaff_s0;
    int32_t unaff_s1;
    uint32_t uVar6;
    int32_t unaff_s2;
    int32_t unaff_s3;
    int32_t unaff_s4;
    undefined *puVar7;
    undefined *puVar8;
    int32_t *piVar9;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    uint32_t uVar10;
    int32_t in_stack_0000001c;
    undefined4 in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffd8;
    int32_t in_stack_ffffffdc;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    
    if ((uint32_t)arg3 < 2 != 0) {
        return (uint32_t)((uint32_t)arg3 < 2);
    }
    uVar2 = (uint32_t)*(uint8_t *)arg2;
    if (uVar2 == 0x73) {
        uVar2 = arg3 - 1;
        if (uVar2 == 0) {
            return 0x73;
        }
        if (*(char *)(arg1 + 0x31) == '\0') {
code_r0xbfc017e0:
            uVar2 = 0;
            if ((*(uint32_t *)0xa0180050 & 4) != 0) {
                uVar2 = fcn.bfc05988(in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84, in_stack_fffffbec, 
                                     in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                                     in_stack_fffffc18, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc00, 
                                     in_stack_fffffc1c, in_stack_fffffc2c, in_stack_fffffc0c, in_stack_fffffc20, 
                                     in_stack_fffffc08, in_stack_fffffc24, in_stack_fffffc04, in_stack_fffffc28);
                printf(in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, in_stack_00000c0c, in_stack_fffffbf4, 
                       in_stack_fffffbf0);
            }
            return uVar2;
        }
        uVar6 = *(uint8_t *)(arg1 + 0x30) - 3;
        uVar10 = uVar2 / uVar6;
        if (uVar6 == 0) {
            trap(0x1c00);
        }
        *(int32_t *)(arg1 + 0x5c) = *(int32_t *)(arg1 + 0x5c) + 1;
        if (uVar10 < 0x10) {
            if (uVar2 % uVar6 != 0) {
                uVar10 = uVar10 + 1;
            }
        } else {
            uVar10 = 0x10;
        }
        uVar2 = 0;
        iVar3 = 0;
        puVar1 = &stack0xffffffb8;
        while( true ) {
            if (uVar10 <= uVar2) {
                return 0;
            }
            uVar6 = *(uint8_t *)(arg1 + 0x30) - 3;
            if ((uint32_t)(*(int32_t *)(puVar1 + 0x14) - iVar3) < uVar6) {
                uVar6 = *(int32_t *)(puVar1 + 0x14) - iVar3;
            }
            arg1_00 = (undefined *)fcn.bfc03e88(*(int32_t *)(puVar1 + 0x14));
            uVar4 = *(undefined4 *)(arg1 + 0x2c);
            *arg1_00 = 0x9c;
            fcn.bfc01864(uVar4, arg1_00 + 1, puVar1[4]);
            arg1_00[5] = 0x73;
            *(undefined **)(puVar1 + 0x20) = arg1_00 + 6;
            fcn.bfc01908(arg1_00 + 6, 
                         (uint32_t)(uVar2 + 1 == uVar10) << 0xf | *(uint32_t *)(puVar1 + 0x18) | uVar2 & 0xf, puVar1[8])
            ;
            fcn.bfc07918((int32_t)(arg1_00 + 8), *(int32_t *)(puVar1 + 0x18), *(int32_t *)(puVar1 + 0x1c), 
                         *(int32_t *)(puVar1 + 0x20), *(int32_t *)(puVar1 + 8));
            arg3_00 = *(uint8_t *)(arg1 + 0x30) - 1;
            iVar3 = iVar3 + uVar6;
            iVar5 = fcn.bfc00a30(arg1, *(undefined4 *)(puVar1 + 0x28), arg3_00, puVar1[0x10]);
            if (iVar5 == 0) break;
            uVar4 = fcn.bfc03e50(*(int32_t *)(puVar1 + 0x28));
            fcn.bfc01930(uVar4, arg1_00, *(uint8_t *)(arg1 + 0x30) + 5, 0xbfc0184c);
            iVar5 = fcn.bfc01a48(*(undefined4 *)(arg1 + 0x6c), puVar1[0x1c]);
            puVar7 = puVar1 + 0x20;
            if (iVar5 == 0) {
                fcn.bfc01984(uVar4, puVar1[0x20]);
                fcn.bfc03efc(*(int32_t *)(puVar1 + 0x38), *(int32_t *)(puVar1 + 0x3c));
                puVar7 = puVar1 + 0x28;
            }
            uVar2 = uVar2 + 1 & 0xff;
            puVar1 = puVar7;
        }
        printf2(4, arg3_00, 0xa01802dc, puVar1[0x14]);
        in_stack_0000001c = *(int32_t *)(puVar1 + 0x5c);
        unaff_s8 = *(int32_t *)(puVar1 + 0x58);
        iVar3 = 1;
        piVar9 = (int32_t *)(puVar1 + 0x60);
    } else {
        if (uVar2 < 0x74) {
            if (uVar2 != 0x17) {
                return uVar2;
            }
            if ((arg3 == 1) || (uVar2 = (uint32_t)(*(uint8_t *)(arg1 + 0x30) - 1 < arg3 - 1U), uVar2 != 0)) {
                return uVar2;
            }
            puVar1 = (undefined *)fcn.bfc03e88(unaff_s0);
            memset(in_stack_ffffffe8, unaff_s0, unaff_s1, in_stack_ffffffd8, in_stack_ffffffdc);
            iVar3 = *(int32_t *)(arg1 + 0x2c);
            *puVar1 = 0x9c;
            fcn.bfc01864(iVar3, (int32_t)(puVar1 + 1));
            puVar1[5] = 0x17;
            fcn.bfc07918((int32_t)(puVar1 + 6), unaff_s1, unaff_s2, unaff_s3, in_stack_ffffffe0);
            arg1_00 = (undefined *)fcn.bfc03e50(unaff_retaddr);
            fcn.bfc01930(arg1_00, puVar1, *(uint8_t *)(arg1 + 0x30) + 5, 0xbfc0184c);
            uVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x6c));
            if (uVar2 != 0) {
                return uVar2;
            }
            fcn.bfc01984((int32_t)arg1_00);
            iVar3 = 0x18;
            piVar9 = (int32_t *)&stack0x00000020;
        } else {
            if (uVar2 != 0xc3) {
                if (uVar2 != 0xd2) {
                    return uVar2;
                }
                if (arg3 != 0x21) {
                    return 0x20;
                }
                fcn.bfc07918(arg1 + 0x34, in_stack_ffffffec, in_stack_fffffff0, unaff_s0, in_stack_ffffffdc);
                fcn.bfc07918(arg1 + 0x48, in_stack_fffffff0, unaff_s0, unaff_s1, in_stack_ffffffe0);
                fcn.bfc07918(arg1 + 0x50, unaff_s0, unaff_s1, unaff_retaddr, in_stack_ffffffe4);
                *(undefined *)(arg1 + 0x31) = 1;
                return 1;
            }
            if (arg3 == 1) {
                return 0xc3;
            }
            if (*(char *)(arg1 + 0x31) == '\0') goto code_r0xbfc017e0;
            puVar1 = (undefined *)fcn.bfc03e88(unaff_s0);
            iVar3 = *(int32_t *)(arg1 + 0x2c);
            *puVar1 = 0x9c;
            fcn.bfc01864(iVar3, (int32_t)(puVar1 + 1));
            puVar1[5] = 0xc3;
            fcn.bfc07918((int32_t)(puVar1 + 6), unaff_s0, unaff_s1, unaff_s2, in_stack_ffffffd4);
            iVar5 = *(uint8_t *)(arg1 + 0x30) - 1;
            iVar3 = fcn.bfc00a30(arg1, (int32_t)(puVar1 + 6), iVar5);
            if (iVar3 == 0) {
                printf2(4, iVar5, -0x5fe7fca8);
                puVar8 = &stack0xffffffe4;
                iVar3 = 1;
                arg1_00 = puVar1;
            } else {
                arg1_00 = (undefined *)fcn.bfc03e50(unaff_s4);
                fcn.bfc01930(arg1_00, puVar1, *(uint8_t *)(arg1 + 0x30) + 5, 0xbfc0184c);
                uVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x6c));
                if (uVar2 != 0) {
                    return uVar2;
                }
                fcn.bfc01984((int32_t)arg1_00);
                puVar8 = &stack0xfffffff0;
                iVar3 = 0x18;
            }
            in_stack_0000001c = *(int32_t *)(puVar8 + 0x2c);
            piVar9 = (int32_t *)(puVar8 + 0x30);
        }
    }
    piVar9[-1] = in_stack_0000001c;
    piVar9[-2] = unaff_s8;
    *piVar9 = (int32_t)arg1_00;
    piVar9[1] = iVar3;
    uVar2 = fcn.bfc06d40(*piVar9, piVar9[1], piVar9[-7], piVar9[-2], piVar9[-6], piVar9[-5], piVar9[-4], piVar9[-3]);
    return uVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01250 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc01250(int32_t arg1, int32_t arg4, int32_t arg3, int32_t arg2)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t unaff_s1;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    int32_t iStack00000018;
    
    puVar1 = (undefined *)fcn.bfc03e88(unaff_s1);
    iVar2 = *(int32_t *)(arg1 + 0x2c);
    *puVar1 = 0x4d;
    fcn.bfc01864(iVar2, (int32_t)(puVar1 + 1));
    iStack00000018 = fcn.bfc03e50(unaff_retaddr);
    fcn.bfc01930(iStack00000018, puVar1, 5, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x6c));
    if (iVar2 == 0) {
        fcn.bfc01984(iStack00000018);
        fcn.bfc06d40(iStack00000018, 0x18, unaff_retaddr, unaff_s8, in_stack_00000000, in_stack_00000004, 
                     in_stack_00000008, in_stack_0000000c);
        return;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.

undefined8 fcn.bfc04678(int32_t arg3, int32_t arg4, int32_t arg_0h, int32_t arg_4h, int32_t arg_8h, int32_t arg_ch)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    
    iVar5 = *(int32_t *)0xa0180d8c * 8;
    uVar6 = *(uint32_t *)(iVar5 + -0x5fe7f23c);
    *(uint32_t *)0xa0180d8c = *(int32_t *)0xa0180d8c + 1 & 0x8000000f;
    if ((int32_t)*(uint32_t *)0xa0180d8c < 0) {
        *(uint32_t *)0xa0180d8c = (*(uint32_t *)0xa0180d8c - 1 | 0xfffffff0) + 1;
    }
    uVar7 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f23c);
    uVar3 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f240);
    uVar4 = uVar3 ^ uVar3 << 0x1b;
    uVar7 = uVar7 ^ (uVar3 >> 5 | uVar7 << 0x1b);
    iVar2 = *(uint32_t *)0xa0180d8c * 8;
    *(uint32_t *)(iVar2 + -0x5fe7f240) =
         *(uint32_t *)(iVar5 + -0x5fe7f240) ^ uVar6 >> 0xe ^ uVar4 ^ (uVar7 << 0x13 | uVar4 >> 0xd);
    *(uint32_t *)(iVar2 + -0x5fe7f23c) = uVar6 ^ uVar7 ^ uVar7 >> 0xd;
    uVar6 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f240);
    iVar1 = (uint64_t)uVar6 * 0xcf637165;
    return CONCAT44((int32_t)iVar1, 
                    *(int32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f23c) * -0x309c8e9b + uVar6 * 0x19e4b16e +
                    (int32_t)((uint64_t)iVar1 >> 0x20));
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.

int32_t strlen(int32_t arg_10h, int32_t arg_0h)
{
    int32_t in_a0;
    int32_t iStack16;
    
    iStack16 = 0;
    while (*(char *)(in_a0 + iStack16) != '\0') {
        iStack16 = iStack16 + 1;
    }
    return iStack16;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function printf3 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.

int32_t printf3(int32_t arg_20h, int32_t arg_24h, int32_t arg_28h, int32_t arg_2ch, int32_t arg_14h, int32_t arg_10h)
{
    int32_t iVar1;
    int32_t in_a0;
    int32_t in_a1;
    int32_t in_a2;
    int32_t in_a3;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000014;
    int32_t in_stack_00000018;
    int32_t in_stack_0000002c;
    int32_t in_stack_0000007c;
    int32_t in_stack_00000080;
    int32_t in_stack_00000084;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    
    iVar1 = fcn.bfc05988(in_stack_0000007c, in_stack_00000080, in_stack_00000084, in_stack_ffffffec, in_stack_fffffff0, 
                         (int32_t)&stack0x00000008, unaff_s8, unaff_retaddr, in_stack_00000018, arg_14h, 
                         in_stack_00000014, in_a0, arg_20h, in_stack_0000002c, in_a3, arg_24h, in_a2, arg_28h, in_a1, 
                         arg_2ch);
    *(undefined *)(in_a0 + iVar1) = 0;
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc03f3c(int32_t arg_18h)
{
    int32_t in_a0;
    int32_t unaff_s8;
    int32_t in_stack_00000004;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    int32_t in_stack_fffffff4;
    
    fcn.bfc06d40(in_a0, in_stack_00000004, in_stack_ffffffe4, unaff_s8, in_stack_ffffffe8, in_stack_ffffffec, 
                 in_stack_fffffff0, in_stack_fffffff4);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01d90 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

int32_t fcn.bfc01d90(int32_t arg3, int32_t arg1, int32_t arg4)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t in_a1;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t arg1_00;
    int32_t in_stack_ffffffd0;
    int32_t in_stack_ffffffe8;
    
    iVar3 = arg3 + 1;
    puVar1 = (undefined *)fcn.bfc03e88(in_a1);
    *puVar1 = 0x73;
    fcn.bfc07918((int32_t)(puVar1 + 1), arg3, in_a1, in_stack_ffffffe8, in_stack_ffffffd0);
    arg1_00 = *(int32_t *)(arg1 + 4);
    iVar2 = fcn.bfc03e50(unaff_s0);
    fcn.bfc01930(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(arg1_00 + 0x10) < 0x20) && (iVar2 = fcn.bfc07e9c(iVar2, arg1_00), iVar2 != 0)) {
        *(int32_t *)(arg1_00 + 0x10) = *(int32_t *)(arg1_00 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc070c0 failed, args may be inaccurate.

undefined4
fcn.bfc070c0(int32_t arg1, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h, int32_t arg_4h, int32_t arg_8h,
            int32_t arg_0h)
{
    undefined4 uVar1;
    int32_t in_a1;
    uint32_t in_a2;
    uint32_t uStack24;
    
    if (in_a2 == 0) {
        uVar1 = 0;
    } else {
        uStack24 = 0;
        while ((uStack24 < in_a2 && (*(char *)(arg1 + uStack24) == *(char *)(in_a1 + uStack24)))) {
            uStack24 = uStack24 + 1;
        }
        if (uStack24 == in_a2) {
            uVar1 = 0;
        } else {
            if (*(uint8_t *)(in_a1 + uStack24) < *(uint8_t *)(arg1 + uStack24)) {
                uVar1 = 1;
            } else {
                uVar1 = 0xffffffff;
            }
        }
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

void fcn.bfc020b4(int32_t arg1)
{
    int32_t arg2;
    int32_t in_a1;
    undefined *puVar1;
    undefined auStack32 [20];
    
    puVar1 = auStack32;
    arg2 = *(int32_t *)(arg1 + 0x10);
    while ((arg2 != 0 && (in_a1 != *(int32_t *)(arg2 + 0x90)))) {
        arg2 = fcn.bfc07d50(arg2, *puVar1);
        puVar1 = puVar1 + 4;
    }
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

int32_t fcn.bfc01e28(int32_t arg3, int32_t arg1, int32_t arg4)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t in_a1;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t arg1_00;
    int32_t in_stack_ffffffd0;
    int32_t in_stack_ffffffe8;
    
    iVar3 = arg3 + 1;
    puVar1 = (undefined *)fcn.bfc03e88(in_a1);
    *puVar1 = 0xc3;
    fcn.bfc07918((int32_t)(puVar1 + 1), arg3, in_a1, in_stack_ffffffe8, in_stack_ffffffd0);
    arg1_00 = *(int32_t *)(arg1 + 4);
    iVar2 = fcn.bfc03e50(unaff_s0);
    fcn.bfc01930(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(arg1_00 + 0x10) < 0x20) && (iVar2 = fcn.bfc07e9c(iVar2, arg1_00), iVar2 != 0)) {
        *(int32_t *)(arg1_00 + 0x10) = *(int32_t *)(arg1_00 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0210c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc018f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.

void fcn.bfc0210c(int32_t arg1, int32_t arg2, int32_t arg3)
{
    undefined4 arg2_00;
    int32_t iVar1;
    int32_t iVar2;
    undefined4 in_a3;
    uint32_t uVar3;
    undefined *puVar4;
    undefined *puVar5;
    int32_t in_stack_fffffbcc;
    int32_t in_stack_fffffbdc;
    int32_t in_stack_fffffbe0;
    int32_t in_stack_fffffbe4;
    undefined auStack1046 [1018];
    
    arg2_00 = fcn.bfc018f4(arg2 + 1);
    iVar1 = fcn.bfc020b4(arg1);
    puVar5 = &stack0xfffffbd0;
    if (iVar1 != 0) {
        if (*(char *)arg2 == '\x01') {
            uVar3 = (uint32_t)*(uint8_t *)(arg2 + 5);
            if (uVar3 <= arg3 - 6U) {
                iVar2 = *(int32_t *)(iVar1 + 0xa4);
                if (0x200 < uVar3 + iVar2) {
                    uVar3 = 0x200 - iVar2;
                }
                puVar4 = &stack0xfffffbd0;
                if (uVar3 != 0) {
                    fcn.bfc07918(*(int32_t *)(iVar1 + 0xa8) + iVar2, in_stack_fffffbdc, in_stack_fffffbe0, 
                                 in_stack_fffffbe4, in_stack_fffffbcc);
                    *(uint32_t *)(iVar1 + 0xa4) = *(int32_t *)(iVar1 + 0xa4) + uVar3;
                    puVar4 = &stack0xfffffbd4;
                    if (*(code **)(iVar1 + 0x98) != (code *)0x0) {
                        (**(code **)(iVar1 + 0x98))(arg2 + 6, uVar3);
                        puVar4 = &stack0xfffffbd4;
                    }
                }
                puVar4[0x10] = 1;
                fcn.bfc01864(arg2_00, puVar4 + 0x11, *puVar4);
                puVar5 = puVar4 + 4;
                puVar4[0x19] = (char)uVar3;
                iVar1 = 6;
                goto code_r0xbfc0220c;
            }
        } else {
            if (*(char *)arg2 == '\x02') {
                uVar3 = *(int32_t *)(iVar1 + 0xa4) - *(int32_t *)(iVar1 + 0xa0);
                if (*(uint8_t *)(arg2 + 5) < uVar3) {
                    uVar3 = (uint32_t)*(uint8_t *)(arg2 + 5);
                }
                puVar4 = &stack0xfffffbd0;
                if (uVar3 != 0) {
                    fcn.bfc07918((int32_t)&stack0xfffffbe6, in_stack_fffffbdc, in_stack_fffffbe0, in_stack_fffffbe4, 
                                 in_stack_fffffbcc);
                    *(uint32_t *)(iVar1 + 0xa0) = *(int32_t *)(iVar1 + 0xa0) + uVar3;
                    puVar4 = &stack0xfffffbd4;
                    if (*(code **)(iVar1 + 0x9c) != (code *)0x0) {
                        (**(code **)(iVar1 + 0x9c))(auStack1046, uVar3);
                        puVar4 = &stack0xfffffbd4;
                    }
                }
                puVar4[0x10] = 2;
                fcn.bfc01864(arg2_00, puVar4 + 0x11, *puVar4);
                puVar5 = puVar4 + 4;
                puVar4[0x19] = (char)uVar3;
                iVar1 = uVar3 + 6;
                goto code_r0xbfc0220c;
            }
        }
    }
    iVar1 = 2;
code_r0xbfc0220c:
    fcn.bfc01e28(iVar1, arg1, in_a3, *puVar5);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ba0 failed, args may be inaccurate.

uint32_t fcn.bfc01ba0(int32_t arg1, int32_t arg2, int32_t arg3)
{
    uint32_t uVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    
    if (((uint32_t)arg2 <= *(uint32_t *)(arg1 + 0xc)) && ((uint32_t)arg3 <= *(uint32_t *)(arg1 + 0xc))) {
        puVar3 = (uint8_t *)(*(int32_t *)(arg1 + 0x10) + arg2);
        uVar1 = 0x512078cd;
        puVar2 = puVar3;
        while (puVar2 != puVar3 + arg3) {
            uVar1 = *(uint32_t *)(((*puVar2 ^ uVar1) & 0xff) * 4 + -0x5fe7fbd0) ^ uVar1 >> 8;
            puVar2 = puVar2 + 1;
        }
        return ~uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fbc failed, args may be inaccurate.

undefined4 fcn.bfc07fbc(int32_t *param_1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if ((int32_t *)param_1[2] != (int32_t *)0x0) {
        uVar1 = 0;
        if ((param_1 != (int32_t *)0x0) && (piVar3 = (int32_t *)param_1[2], piVar3 == (int32_t *)param_1[2])) {
            iVar4 = *param_1;
            if (iVar4 != 0) {
                *(int32_t *)(iVar4 + 4) = param_1[1];
            }
            piVar2 = (int32_t *)param_1[1];
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (param_1 == (int32_t *)piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (param_1 == (int32_t *)piVar3[1]) {
                piVar3[1] = *param_1;
            }
            iVar4 = *piVar3;
            param_1[2] = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01bdc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf3 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.

int32_t fcn.bfc01bdc(int32_t arg1, int32_t arg2)
{
    int32_t arg1_00;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t unaff_s2;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_ffffffd0;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    arg1_00 = fcn.bfc03e88(in_stack_ffffffe4);
    fcn.bfc07918(arg1_00, in_stack_ffffffe0, in_stack_ffffffe4, in_stack_ffffffe8, in_stack_ffffffd0);
    *(undefined *)(arg1_00 + (uint32_t)*(uint8_t *)(arg1 + 0x8c)) = 0;
    printf3(unaff_s1, unaff_s2, unaff_retaddr, in_stack_00000000, (uint32_t)*(uint8_t *)(arg1 + 0x94), in_stack_ffffffe4
           );
    fcn.bfc03f3c(unaff_s0);
    return unaff_s2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02008 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc070c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

undefined4 fcn.bfc02008(int32_t arg1)
{
    int32_t iVar1;
    uint32_t in_a2;
    undefined4 *in_a3;
    int32_t arg2;
    int32_t *piVar2;
    undefined auStack40 [16];
    
    piVar2 = (int32_t *)auStack40;
    arg2 = *(int32_t *)(arg1 + 0x10);
    do {
        if (arg2 == 0) {
            *in_a3 = 0;
            return 0;
        }
        if (*(uint8_t *)(arg2 + 0x8c) == in_a2) {
            iVar1 = fcn.bfc070c0(arg2 + 0xc, piVar2[5], piVar2[6], piVar2[7], *piVar2, piVar2[1], piVar2[-1]);
            piVar2 = piVar2 + 1;
            if (iVar1 == 0) {
                *in_a3 = *(undefined4 *)(arg2 + 0x90);
                return 1;
            }
        }
        arg2 = fcn.bfc07d50(arg2, *(undefined *)piVar2);
        piVar2 = (int32_t *)((int32_t)piVar2 + 4);
    } while( true );
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc025d4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

int32_t fcn.bfc025d4(int32_t arg1)
{
    int32_t arg2;
    int32_t iVar1;
    undefined *puVar2;
    undefined auStack32 [20];
    
    puVar2 = auStack32;
    arg2 = *(int32_t *)(arg1 + 0x10);
    iVar1 = 0;
    while (arg2 != 0) {
        iVar1 = iVar1 + 1;
        arg2 = fcn.bfc07d50(arg2, *puVar2);
        puVar2 = puVar2 + 4;
    }
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01884 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.

void fcn.bfc01884(int32_t arg2)
{
    undefined4 arg2_00;
    undefined *in_a0;
    int32_t in_a2;
    int32_t in_a3;
    int32_t *piVar1;
    int32_t *piVar2;
    undefined auStack32 [20];
    
    if (0x1f < (uint32_t)arg2) {
        piVar1 = (int32_t *)auStack32;
        do {
            arg2_00 = fcn.bfc04678(in_a2, in_a3, piVar1[-1], *piVar1, piVar1[1], piVar1[2]);
            piVar2 = piVar1 + 1;
            if ((uint32_t)arg2 < 4) {
                *in_a0 = (char)arg2_00;
            } else {
                fcn.bfc01864(arg2_00, in_a0, *(undefined *)(piVar1 + 1));
                piVar2 = piVar1 + 2;
            }
            arg2 = arg2 - 1;
            in_a0 = in_a0 + 1;
            piVar1 = piVar2;
        } while (arg2 != 0);
        return;
    }
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01cf8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

int32_t fcn.bfc01cf8(int32_t arg3, int32_t arg1, int32_t arg4)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t in_a1;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t arg1_00;
    int32_t in_stack_ffffffd0;
    int32_t in_stack_ffffffe8;
    
    iVar3 = arg3 + 1;
    puVar1 = (undefined *)fcn.bfc03e88(in_a1);
    *puVar1 = 0x17;
    fcn.bfc07918((int32_t)(puVar1 + 1), arg3, in_a1, in_stack_ffffffe8, in_stack_ffffffd0);
    arg1_00 = *(int32_t *)(arg1 + 4);
    iVar2 = fcn.bfc03e50(unaff_s0);
    fcn.bfc01930(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(arg1_00 + 0x10) < 0x20) && (iVar2 = fcn.bfc07e9c(iVar2, arg1_00), iVar2 != 0)) {
        *(int32_t *)(arg1_00 + 0x10) = *(int32_t *)(arg1_00 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc028d0 failed, args may be inaccurate.

void fcn.bfc028d0(int32_t arg2, int32_t arg4, int32_t arg3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    
    uVar3 = *(uint32_t *)arg2;
    uVar2 = *(uint32_t *)(arg2 + 4);
    uVar1 = 0x3e778b90;
    do {
        uVar4 = uVar1 + *(int32_t *)(arg3 + (uVar1 & 3) * 4);
        uVar1 = uVar1 + 0x83e778b9;
        uVar3 = uVar3 + (uVar4 ^ (uVar2 << 4 ^ uVar2 >> 5) + uVar2);
        uVar2 = uVar2 + (uVar1 + *(int32_t *)(arg3 + (uVar1 >> 9 & 0xc)) ^ (uVar3 * 0x10 ^ uVar3 >> 5) + uVar3);
    } while (uVar1 != 0x7cef1720);
    *(uint32_t *)arg2 = uVar3;
    *(uint32_t *)(arg2 + 4) = uVar2;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b14 failed, args may be inaccurate.

void fcn.bfc03b14(int32_t arg1)
{
    *(undefined4 *)(arg1 + 8) = 0x67452301;
    *(undefined4 *)(arg1 + 0xc) = 0xefcdab89;
    *(undefined4 *)(arg1 + 0x10) = 0x98badcfe;
    *(undefined4 *)(arg1 + 0x14) = 0x10325476;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

undefined4 fcn.bfc03b50(int32_t arg1, int32_t arg3)
{
    undefined *puVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t arg1_00;
    int32_t in_a1;
    int32_t unaff_s0;
    undefined *puVar4;
    undefined4 unaff_s8;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    puVar4 = &stack0xffffffd8;
    uVar3 = *(uint32_t *)arg1;
    uVar2 = uVar3 + arg3 & 0x1fffffff;
    *(uint32_t *)arg1 = uVar2;
    if (uVar2 < uVar3) {
        *(int32_t *)(arg1 + 4) = *(int32_t *)(arg1 + 4) + 1;
    }
    uVar3 = uVar3 & 0x3f;
    *(uint32_t *)(arg1 + 4) = *(int32_t *)(arg1 + 4) + ((uint32_t)arg3 >> 0x1d);
    puVar1 = &stack0xffffffd8;
    if (uVar3 != 0) {
        uVar2 = 0x40 - uVar3;
        arg1_00 = arg1 + uVar3 + 0x18;
        if ((uint32_t)arg3 < uVar2) goto code_r0xbfc03bdc;
        fcn.bfc07918(arg1_00, in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0, in_stack_ffffffd4);
        in_a1 = in_a1 + uVar2;
        arg3 = arg3 - uVar2;
        fcn.bfc02d20(arg1, arg1 + 0x18, 0x40);
        puVar1 = &stack0xffffffe0;
    }
    puVar4 = puVar1;
    if (0x3f < (uint32_t)arg3) {
        in_a1 = fcn.bfc02d20(arg1, in_a1, arg3 & 0xffffffc0, *puVar4);
        puVar4 = puVar4 + 4;
        arg3 = arg3 & 0x3f;
    }
    arg1_00 = arg1 + 0x18;
code_r0xbfc03bdc:
    *(undefined4 *)(puVar4 + 0x24) = unaff_s8;
    *(int32_t *)(puVar4 + 0x28) = arg1_00;
    *(int32_t *)(puVar4 + 0x2c) = in_a1;
    *(int32_t *)(puVar4 + 0x30) = arg3;
    *(undefined4 *)(puVar4 + 0x18) = 0;
    while (*(uint32_t *)(puVar4 + 0x18) < *(uint32_t *)(puVar4 + 0x30)) {
        *(undefined *)(*(int32_t *)(puVar4 + 0x28) + *(int32_t *)(puVar4 + 0x18)) =
             *(undefined *)(*(int32_t *)(puVar4 + 0x2c) + *(int32_t *)(puVar4 + 0x18));
        *(int32_t *)(puVar4 + 0x18) = *(int32_t *)(puVar4 + 0x18) + 1;
    }
    return *(undefined4 *)(puVar4 + 0x28);
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03c54 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memset failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

int32_t fcn.bfc03c54(int32_t arg3, int32_t arg1, int32_t arg2)
{
    int32_t in_v0;
    uint32_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t *piVar4;
    int32_t unaff_s8;
    int32_t in_stack_ffffffdc;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_ffffffec;
    
    if (0xf < (uint32_t)arg3) {
        piVar4 = (int32_t *)&stack0xffffffe0;
        uVar1 = *(uint32_t *)arg1;
        *(undefined *)(arg1 + (uVar1 & 0x3f) + 0x18) = 0x80;
        if (0x40 - ((uVar1 & 0x3f) + 1) < 8) {
            memset(in_stack_ffffffec, unaff_s0, unaff_s1, in_stack_ffffffdc, in_stack_ffffffe0);
            fcn.bfc02d20(arg1, arg1 + 0x18, 0x40);
            piVar4 = (int32_t *)&stack0xffffffe8;
        }
        memset(piVar4[3], piVar4[4], piVar4[5], piVar4[-1], *piVar4);
        iVar2 = *(int32_t *)arg1 << 3;
        *(int32_t *)arg1 = iVar2;
        *(char *)(arg1 + 0x50) = (char)iVar2;
        *(char *)(arg1 + 0x51) = (char)((uint32_t)iVar2 >> 8);
        *(char *)(arg1 + 0x53) = (char)((uint32_t)iVar2 >> 0x18);
        uVar3 = *(undefined4 *)(arg1 + 4);
        *(char *)(arg1 + 0x52) = (char)((uint32_t)iVar2 >> 0x10);
        *(char *)(arg1 + 0x54) = (char)uVar3;
        *(char *)(arg1 + 0x55) = (char)((uint32_t)uVar3 >> 8);
        *(char *)(arg1 + 0x56) = (char)((uint32_t)uVar3 >> 0x10);
        *(char *)(arg1 + 0x57) = (char)((uint32_t)uVar3 >> 0x18);
        fcn.bfc02d20(arg1, arg1 + 0x18, 0x40, *(undefined *)(piVar4 + 1));
        *(char *)arg2 = (char)*(undefined4 *)(arg1 + 8);
        *(char *)(arg2 + 1) = (char)((uint32_t)*(undefined4 *)(arg1 + 8) >> 8);
        *(char *)(arg2 + 2) = (char)*(undefined2 *)(arg1 + 10);
        *(undefined *)(arg2 + 3) = *(undefined *)(arg1 + 0xb);
        *(char *)(arg2 + 4) = (char)*(undefined4 *)(arg1 + 0xc);
        *(char *)(arg2 + 5) = (char)((uint32_t)*(undefined4 *)(arg1 + 0xc) >> 8);
        *(char *)(arg2 + 6) = (char)*(undefined2 *)(arg1 + 0xe);
        *(undefined *)(arg2 + 7) = *(undefined *)(arg1 + 0xf);
        *(char *)(arg2 + 8) = (char)*(undefined4 *)(arg1 + 0x10);
        *(char *)(arg2 + 9) = (char)((uint32_t)*(undefined4 *)(arg1 + 0x10) >> 8);
        *(char *)(arg2 + 10) = (char)*(undefined2 *)(arg1 + 0x12);
        *(undefined *)(arg2 + 0xb) = *(undefined *)(arg1 + 0x13);
        *(char *)(arg2 + 0xc) = (char)*(undefined4 *)(arg1 + 0x14);
        *(char *)(arg2 + 0xd) = (char)((uint32_t)*(undefined4 *)(arg1 + 0x14) >> 8);
        *(char *)(arg2 + 0xe) = (char)*(undefined2 *)(arg1 + 0x16);
        *(undefined *)(arg2 + 0xf) = *(undefined *)(arg1 + 0x17);
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 0x14) = 0;
        *(undefined4 *)(arg1 + 0x10) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        memset(piVar4[5], piVar4[6], piVar4[7], piVar4[1], piVar4[2]);
        piVar4[10] = unaff_s8;
        piVar4[0xb] = arg1 + 0x58;
        piVar4[0xc] = 0;
        piVar4[0xd] = 0x40;
        piVar4[7] = 0;
        *(char *)(piVar4 + 8) = (char)piVar4[0xc];
        while ((uint32_t)piVar4[7] < (uint32_t)piVar4[0xd]) {
            *(undefined *)(piVar4[0xb] + piVar4[7]) = *(undefined *)(piVar4 + 8);
            piVar4[7] = piVar4[7] + 1;
        }
        return piVar4[0xb];
    }
    return in_v0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ec0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.

int32_t fcn.bfc01ec0(int32_t arg3, int32_t arg1, int32_t arg4)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t in_a1;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t arg1_00;
    int32_t in_stack_ffffffd0;
    int32_t in_stack_ffffffe8;
    
    iVar3 = arg3 + 1;
    puVar1 = (undefined *)fcn.bfc03e88(in_a1);
    *puVar1 = 0xd2;
    fcn.bfc07918((int32_t)(puVar1 + 1), arg3, in_a1, in_stack_ffffffe8, in_stack_ffffffd0);
    arg1_00 = *(int32_t *)(arg1 + 4);
    iVar2 = fcn.bfc03e50(unaff_s0);
    fcn.bfc01930(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(arg1_00 + 0x10) < 0x20) && (iVar2 = fcn.bfc07e9c(iVar2, arg1_00), iVar2 != 0)) {
        *(int32_t *)(arg1_00 + 0x10) = *(int32_t *)(arg1_00 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01884 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01cf8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc028d0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b14 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03c54 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ec0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0210c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01d90 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc018f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ba0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02008 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc025d4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07e9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fbc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01908 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01bdc failed, args may be inaccurate.

void fcn.bfc02b48(int32_t arg3, int32_t arg1, int32_t arg2)
{
    undefined uVar1;
    undefined uVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int32_t *piVar5;
    undefined2 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined *puVar9;
    undefined4 uVar10;
    undefined *puVar11;
    uint32_t uVar12;
    undefined4 uVar13;
    undefined *in_a3;
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    char cVar17;
    int32_t unaff_s0;
    int32_t unaff_s2;
    int32_t unaff_s3;
    int32_t unaff_s4;
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    undefined *puVar22;
    int32_t *piVar23;
    int32_t *piVar24;
    undefined *puVar25;
    undefined *puVar26;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    undefined *puStack00000014;
    int32_t in_stack_fffffd8c;
    int32_t in_stack_fffffd94;
    int32_t in_stack_fffffd9c;
    int32_t in_stack_fffffda0;
    int32_t in_stack_fffffda4;
    int32_t in_stack_fffffda8;
    int32_t in_stack_fffffdac;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffe0;
    
    if ((uint32_t)arg3 < 4) {
        return;
    }
    cVar17 = *(char *)arg2;
    if (cVar17 != 's') {
        if (cVar17 == -0x3d) {
            if (arg3 - 1U < 6) {
                fcn.bfc01e28(2, arg1, (int32_t)in_a3);
            } else {
                fcn.bfc0210c(arg1, arg2 + 1, arg3 - 1U);
            }
            return;
        }
        if (cVar17 != '\x17') {
            return;
        }
        if (((*(uint8_t *)(arg2 + 1) & 0xf0) == 0x70) && (0x60 < arg3 - 1U)) {
            fcn.bfc07918((int32_t)&stack0xffffff74, in_stack_fffffd9c, in_stack_fffffda0, in_stack_fffffda4, 
                         in_stack_fffffd8c);
            fcn.bfc01884(0x60);
            fcn.bfc07918((int32_t)&stack0xfffffe59, in_stack_fffffda4, in_stack_fffffda8, in_stack_fffffdac, 
                         in_stack_fffffd94);
            fcn.bfc01cf8(0x61, arg1, (int32_t)in_a3);
            iVar14 = 0;
            iVar15 = arg1 + 0x18;
            iVar16 = 0x60;
            puVar11 = &stack0xffffff84;
            puVar9 = &stack0xfffffda0;
            do {
                puVar25 = puVar9;
                fcn.bfc028d0(puVar11 + iVar14, in_a3, iVar15, *puVar25);
                iVar14 = iVar14 + 8;
                puVar11 = puVar25 + 0x1e8;
                puVar9 = puVar25 + 4;
            } while (iVar14 != iVar16);
            iVar14 = 0;
            iVar16 = 0x60;
            puVar9 = puVar25;
            do {
                puVar26 = puVar9;
                fcn.bfc028d0(puVar26 + iVar14 + 0x188, in_a3, iVar15, puVar26[4]);
                iVar14 = iVar14 + 8;
                puVar9 = puVar26 + 4;
            } while (iVar14 != iVar16);
            iVar14 = 0;
            do {
                iVar15 = iVar14 + 300;
                iVar4 = iVar14 + 0x1ec;
                iVar16 = iVar14 + 0x18c;
                iVar14 = iVar14 + 4;
                *(uint32_t *)(puVar26 + iVar15) = *(uint32_t *)(puVar26 + iVar4) ^ *(uint32_t *)(puVar26 + iVar16);
            } while (iVar14 != 0x60);
            *(undefined4 *)(puVar26 + 0x1c) = *(undefined4 *)(puVar26 + 0x138);
            *(undefined4 *)(puVar26 + 0x18) = *(undefined4 *)(puVar26 + 0x134);
            printf2(4, *(undefined4 *)(puVar26 + 300), 0xa0180924, puVar26[8]);
            fcn.bfc03b14(puVar26 + 0x34, puVar26[0xc]);
            fcn.bfc03b50(puVar26 + 0x38, 0x30, puVar26[0x10]);
            fcn.bfc03c54(0x10, puVar26 + 0x3c, puVar26 + 600, puVar26[0x14]);
            fcn.bfc03b14(puVar26 + 0x40, puVar26[0x18]);
            fcn.bfc03b50(puVar26 + 0x44, 0x30, puVar26[0x1c]);
            fcn.bfc03c54(0x10, puVar26 + 0x48, puVar26 + 0x274, puVar26[0x20]);
            uVar13 = *(undefined4 *)(puVar26 + 0x26c);
            *(undefined4 *)(puVar26 + 0x48) = *(undefined4 *)(puVar26 + 0x284);
            *(undefined4 *)(puVar26 + 0x44) = *(undefined4 *)(puVar26 + 0x280);
            *(undefined4 *)(puVar26 + 0x40) = *(undefined4 *)(puVar26 + 0x27c);
            *(undefined4 *)(puVar26 + 0x3c) = *(undefined4 *)(puVar26 + 0x278);
            *(undefined4 *)(puVar26 + 0x38) = *(undefined4 *)(puVar26 + 0x274);
            *(undefined4 *)(puVar26 + 0x34) = *(undefined4 *)(puVar26 + 0x270);
            printf2(4, *(undefined4 *)(puVar26 + 0x268), 0xa0180944, puVar26[0x24]);
            fcn.bfc01ec0(0x20, arg1, uVar13, puVar26[0x28]);
            return;
        }
        return;
    }
    if (arg3 == 1) {
        return;
    }
    uVar3 = *(uint8_t *)(arg2 + 1);
    if (uVar3 == 0x52) {
        puVar22 = &stack0xffffffb8;
        if (3 < arg3 - 2U) {
            fcn.bfc018f4(arg2 + 2);
            iVar14 = fcn.bfc020b4(arg1);
            puVar22 = &stack0xffffffc0;
            if (iVar14 != 0) {
                puVar9 = (undefined *)fcn.bfc03e88(in_stack_ffffffd4);
                iVar14 = fcn.bfc01bdc(iVar14, (int32_t)(puVar9 + 3));
                *puVar9 = 0x28;
                puVar9[1] = 0;
                puVar9[2] = (char)iVar14;
                fcn.bfc01d90(iVar14 + 3, arg1, (int32_t)in_a3);
                fcn.bfc03f3c(in_stack_ffffffe0);
                return;
            }
        }
        fcn.bfc01d90(2, arg1, in_a3, *puVar22);
        return;
    }
    if (0x52 < uVar3) {
        if (uVar3 == 0x71) {
            if (1 < arg3 - 2U) {
                iVar14 = fcn.bfc01918(arg2 + 2);
                puStack00000014 = (undefined *)fcn.bfc03e88(unaff_s2);
                *puStack00000014 = 0xe2;
                fcn.bfc01908((int32_t)(puStack00000014 + 1), iVar14);
                fcn.bfc07918((int32_t)(puStack00000014 + 3), unaff_s2, unaff_s3, unaff_s4, in_stack_ffffffe0);
                fcn.bfc01d90(iVar14 + 3, arg1, (int32_t)in_a3);
                fcn.bfc06d40((int32_t)puStack00000014, 1, unaff_s4, unaff_s8, unaff_retaddr, in_stack_00000000, 
                             in_stack_00000004, in_stack_00000008);
                return;
            }
            return;
        }
        if (uVar3 != 0x87) {
            return;
        }
        puVar21 = &stack0xffffffd8;
        if (3 < arg3 - 2U) {
            fcn.bfc018f4(arg2 + 2);
            iVar14 = fcn.bfc020b4(arg1);
            puVar21 = &stack0xffffffe0;
            puVar20 = &stack0xffffffe0;
            uVar6 = 0x294;
            if (iVar14 != 0) {
                if (*(int32_t *)(iVar14 + 0xa8) != 0) {
                    fcn.bfc03f3c(unaff_s0);
                    puVar20 = &stack0xffffffe4;
                }
                fcn.bfc07fbc(iVar14);
                fcn.bfc03efc(*(int32_t *)(puVar20 + 0x18), *(int32_t *)(puVar20 + 0x1c));
                puVar21 = puVar20 + 8;
                uVar6 = 0x94;
            }
            *(undefined2 *)(puVar21 + 0x10) = uVar6;
        }
        fcn.bfc01d90(2, arg1, in_a3, *puVar21);
        return;
    }
    if (uVar3 != 0x23) {
        if (uVar3 != 0x3f) {
            return;
        }
        puVar19 = &stack0xffffffc8;
        if (arg3 - 2U < 8) {
            uVar13 = 2;
        } else {
            uVar7 = fcn.bfc01918(arg2 + 2);
            iVar14 = fcn.bfc018f4(arg2 + 4);
            uVar8 = fcn.bfc01918(arg2 + 8);
            iVar15 = fcn.bfc020b4(arg1);
            puVar18 = &stack0xffffffd8;
            if (iVar15 != 0) {
                uVar12 = *(uint32_t *)(iVar15 + 0xa4);
                if ((uVar7 <= uVar12) && (uVar8 <= uVar12)) {
                    if (uVar12 < uVar8 + uVar7) {
                        fcn.bfc01864(iVar14, (int32_t)&stack0xffffffea);
                        fcn.bfc01d90(6, arg1, (int32_t)in_a3);
                        puVar18 = &stack0xffffffe0;
                    }
                    uVar13 = fcn.bfc01ba0(iVar15 + 0x98, uVar8, uVar7, *puVar18);
                    *(undefined2 *)(puVar18 + 0x14) = 0x8faa;
                    fcn.bfc01864(iVar14, puVar18 + 0x16, puVar18[4]);
                    fcn.bfc01864(uVar13, puVar18 + 0x1e, puVar18[8]);
                    puVar19 = puVar18 + 0xc;
                    uVar13 = 10;
                    goto code_r0xbfc02340;
                }
            }
            fcn.bfc01864(iVar14, (int32_t)&stack0xffffffea);
            puVar19 = &stack0xffffffdc;
            uVar13 = 6;
        }
code_r0xbfc02340:
        fcn.bfc01d90(uVar13, arg1, in_a3, *puVar19);
        return;
    }
    uVar7 = arg3 - 2;
    if (uVar7 < 4) {
code_r0xbfc02654:
        printf2(4, uVar7, -0x5fe7f7a0);
        piVar23 = (int32_t *)&stack0xffffffc4;
    } else {
        uVar3 = *(uint8_t *)(arg2 + 4);
        uVar8 = (uint32_t)uVar3;
        if ((uVar7 < uVar8 + 3) || (in_a3 = &stack0xffffffd8, (char)uVar3 < '\0')) goto code_r0xbfc02654;
        uVar1 = *(undefined *)(arg2 + 2);
        uVar2 = *(undefined *)(arg2 + 3);
        uVar7 = uVar8;
        iVar14 = fcn.bfc02008(arg1);
        if (iVar14 != 0) {
            printf2(4, uVar7, -0x5fe7f76c);
            piVar23 = &stack0xffffffc8;
code_r0xbfc026d8:
            fcn.bfc01864(unaff_s0, piVar23 + 0x12, *piVar23);
            piVar23 = (int32_t *)(piVar23 + 4);
            uVar13 = 6;
            goto code_r0xbfc026e4;
        }
        uVar12 = fcn.bfc025d4(arg1);
        cVar17 = 'd';
        piVar5 = (int32_t *)&stack0xffffffc8;
        if (7 < uVar12) {
            printf2(4, uVar7, -0x5fe7f73c);
            piVar23 = &stack0xffffffcc;
            unaff_s0 = 8;
            goto code_r0xbfc026d8;
        }
        do {
            piVar24 = piVar5;
            uVar13 = fcn.bfc04678(uVar7, (int32_t)in_a3, piVar24[-1], *piVar24, piVar24[1], piVar24[2]);
            iVar14 = fcn.bfc020b4(arg1, *(undefined *)(piVar24 + 1));
            piVar23 = piVar24 + 2;
            cVar17 = cVar17 + -1;
            if (iVar14 == 0) {
                iVar14 = fcn.bfc03e50(piVar24[7]);
                fcn.bfc07d30(iVar14, *(undefined *)(piVar24 + 3));
                *(undefined4 *)(iVar14 + 0xa0) = 0;
                *(undefined4 *)(iVar14 + 0xa4) = 0;
                uVar10 = fcn.bfc03e88(piVar24[9]);
                *(undefined4 *)(iVar14 + 0xa8) = uVar10;
                *(undefined4 *)(iVar14 + 0x9c) = 0xbfc01b58;
                *(undefined4 *)(iVar14 + 0x98) = 0xbfc01b10;
                uVar7 = 0;
                while ((uVar7 & 0xff) < uVar8) {
                    *(undefined *)(iVar14 + uVar7 + 0xc) = ((undefined *)(arg2 + 2))[uVar7 + 3];
                    uVar7 = uVar7 + 1;
                }
                *(uint8_t *)(iVar14 + 0x8c) = uVar3;
                *(undefined4 *)(iVar14 + 0x90) = uVar13;
                *(undefined *)(iVar14 + 0x94) = uVar1;
                *(undefined *)(iVar14 + 0x95) = uVar2;
                fcn.bfc07e9c(iVar14, arg1 + 0xc, *(undefined *)(piVar24 + 5));
                *(undefined2 *)(piVar24 + 10) = 0x5e;
                fcn.bfc01864(uVar13, (int32_t)piVar24 + 0x2a, *(undefined *)(piVar24 + 6));
                fcn.bfc01d90(6, arg1, in_a3, *(undefined *)(piVar24 + 7));
                printf2(4, uVar13, 0xa01808f8, *(undefined *)(piVar24 + 8));
                return;
            }
            piVar5 = piVar24 + 2;
        } while (cVar17 != '\0');
        *(undefined2 *)(piVar24 + 6) = 0x15e;
    }
    uVar13 = 2;
code_r0xbfc026e4:
    fcn.bfc01d90(uVar13, arg1, in_a3, *(undefined *)piVar23);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

void fcn.bfc02d20(int32_t arg1, int32_t arg2, int32_t arg3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t in_t2;
    uint32_t uVar12;
    uint32_t uVar13;
    uint32_t in_t4;
    uint32_t uVar14;
    uint32_t uVar15;
    uint32_t in_t6;
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    uint32_t in_t8;
    uint32_t uVar24;
    uint32_t in_t9;
    uint32_t uVar25;
    uint32_t uVar26;
    int32_t iStack132;
    
    iStack132 = *(int32_t *)(arg1 + 8);
    uVar21 = *(uint32_t *)(arg1 + 0xc);
    uVar22 = *(uint32_t *)(arg1 + 0x10);
    uVar23 = *(uint32_t *)(arg1 + 0x14);
    uVar1 = arg2;
    do {
        uVar3 = uVar1 + 3 & 3;
        uVar4 = uVar1 & 3;
        uVar25 = (*(int32_t *)((uVar1 + 3) - uVar3) << (3 - uVar3) * 8 | in_t9 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)(uVar1 - uVar4) >> uVar4 * 8;
        uVar3 = ((uVar22 ^ uVar23) & uVar21 ^ uVar23) + iStack132 + -0x28955b88 + uVar25;
        *(uint32_t *)(arg1 + 0x58) = uVar25;
        uVar2 = (uVar3 * 0x80 | uVar3 >> 0x19) + uVar21;
        uVar3 = uVar1 + 7 & 3;
        uVar4 = uVar1 + 4 & 3;
        uVar12 = (*(int32_t *)((uVar1 + 7) - uVar3) << (3 - uVar3) * 8 | in_t2 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 4) - uVar4) >> uVar4 * 8;
        uVar4 = ((uVar21 ^ uVar22) & uVar2 ^ uVar22) + uVar23 + 0xe8c7b756 + uVar12;
        *(uint32_t *)(arg1 + 0x5c) = uVar12;
        uVar5 = uVar4 >> 0x14;
        uVar3 = uVar1 + 0xb & 3;
        uVar8 = (uVar4 * 0x1000 | uVar5) + uVar2;
        uVar4 = uVar1 + 8 & 3;
        uVar5 = (*(int32_t *)((uVar1 + 0xb) - uVar3) << (3 - uVar3) * 8 | uVar5 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 8) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(arg1 + 0x60) = uVar5;
        uVar3 = ((uVar2 ^ uVar21) & uVar8 ^ uVar21) + uVar22 + 0x242070db + uVar5;
        uVar6 = (uVar3 >> 0xf | uVar3 * 0x20000) + uVar8;
        uVar3 = uVar1 + 0xf & 3;
        uVar4 = uVar1 + 0xc & 3;
        uVar14 = (*(int32_t *)((uVar1 + 0xf) - uVar3) << (3 - uVar3) * 8 | in_t4 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0xc) - uVar4) >> uVar4 * 8;
        uVar4 = ((uVar2 ^ uVar8) & uVar6 ^ uVar2) + uVar21 + 0xc1bdceee + uVar14;
        *(uint32_t *)(arg1 + 100) = uVar14;
        uVar9 = uVar4 * 0x400000;
        uVar3 = uVar1 + 0x13 & 3;
        uVar7 = (uVar4 >> 10 | uVar9) + uVar6;
        uVar4 = uVar1 + 0x10 & 3;
        uVar9 = (*(int32_t *)((uVar1 + 0x13) - uVar3) << (3 - uVar3) * 8 | uVar9 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x10) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(arg1 + 0x68) = uVar9;
        uVar3 = uVar1 + 0x17 & 3;
        uVar2 = ((uVar8 ^ uVar6) & uVar7 ^ uVar8) + uVar9 + 0xf57c0faf + uVar2;
        uVar4 = uVar1 + 0x14 & 3;
        uVar16 = (*(int32_t *)((uVar1 + 0x17) - uVar3) << (3 - uVar3) * 8 | in_t6 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x14) - uVar4) >> uVar4 * 8;
        uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar7;
        uVar8 = uVar16 + 0x4787c62a + uVar8;
        *(uint32_t *)(arg1 + 0x6c) = uVar16;
        uVar10 = ((uVar6 ^ uVar7) & uVar2 ^ uVar6) + uVar8;
        uVar3 = uVar1 + 0x1b & 3;
        uVar4 = uVar1 + 0x18 & 3;
        uVar8 = (*(int32_t *)((uVar1 + 0x1b) - uVar3) << (3 - uVar3) * 8 | uVar8 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x18) - uVar4) >> uVar4 * 8;
        uVar10 = (uVar10 * 0x1000 | uVar10 >> 0x14) + uVar2;
        *(uint32_t *)(arg1 + 0x70) = uVar8;
        uVar3 = uVar1 + 0x1f & 3;
        uVar6 = ((uVar7 ^ uVar2) & uVar10 ^ uVar7) + uVar8 + 0xa8304613 + uVar6;
        uVar4 = uVar1 + 0x1c & 3;
        uVar24 = (*(int32_t *)((uVar1 + 0x1f) - uVar3) << (3 - uVar3) * 8 | in_t8 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x1c) - uVar4) >> uVar4 * 8;
        uVar6 = (uVar6 >> 0xf | uVar6 * 0x20000) + uVar10;
        *(uint32_t *)(arg1 + 0x74) = uVar24;
        uVar3 = uVar1 + 0x23 & 3;
        uVar7 = ((uVar2 ^ uVar10) & uVar6 ^ uVar2) + uVar24 + 0xfd469501 + uVar7;
        uVar4 = uVar1 + 0x20 & 3;
        uVar11 = (*(int32_t *)((uVar1 + 0x23) - uVar3) << (3 - uVar3) * 8 |
                 uVar24 + 0xfd469501 & 0xffffffffU >> (uVar3 + 1) * 8) & -1 << (4 - uVar4) * 8 |
                 *(uint32_t *)((uVar1 + 0x20) - uVar4) >> uVar4 * 8;
        uVar15 = (uVar7 >> 10 | uVar7 * 0x400000) + uVar6;
        uVar2 = uVar11 + 0x698098d8 + uVar2;
        *(uint32_t *)(arg1 + 0x78) = uVar11;
        uVar4 = ((uVar10 ^ uVar6) & uVar15 ^ uVar10) + uVar2;
        uVar3 = uVar1 + 0x27 & 3;
        uVar7 = (uVar4 * 0x80 | uVar4 >> 0x19) + uVar15;
        uVar4 = uVar1 + 0x24 & 3;
        uVar2 = (*(int32_t *)((uVar1 + 0x27) - uVar3) << (3 - uVar3) * 8 | uVar2 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x24) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(arg1 + 0x7c) = uVar2;
        uVar10 = ((uVar6 ^ uVar15) & uVar7 ^ uVar6) + uVar2 + 0x8b44f7af + uVar10;
        uVar3 = uVar1 + 0x2b & 3;
        uVar4 = uVar1 + 0x28 & 3;
        uVar13 = (*(int32_t *)((uVar1 + 0x2b) - uVar3) << (3 - uVar3) * 8 |
                 uVar2 + 0x8b44f7af & 0xffffffffU >> (uVar3 + 1) * 8) & -1 << (4 - uVar4) * 8 |
                 *(uint32_t *)((uVar1 + 0x28) - uVar4) >> uVar4 * 8;
        uVar17 = (uVar10 * 0x1000 | uVar10 >> 0x14) + uVar7;
        uVar6 = (uVar13 - 0xa44f) + uVar6;
        *(uint32_t *)(arg1 + 0x80) = uVar13;
        uVar10 = ((uVar15 ^ uVar7) & uVar17 ^ uVar15) + uVar6;
        uVar3 = uVar1 + 0x2f & 3;
        uVar4 = uVar1 + 0x2c & 3;
        uVar6 = (*(int32_t *)((uVar1 + 0x2f) - uVar3) << (3 - uVar3) * 8 | uVar6 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x2c) - uVar4) >> uVar4 * 8;
        uVar10 = (uVar10 >> 0xf | uVar10 * 0x20000) + uVar17;
        *(uint32_t *)(arg1 + 0x84) = uVar6;
        uVar15 = uVar6 + 0x895cd7be + uVar15;
        uVar18 = ((uVar7 ^ uVar17) & uVar10 ^ uVar7) + uVar15;
        uVar3 = uVar1 + 0x33 & 3;
        uVar4 = uVar1 + 0x30 & 3;
        uVar15 = (*(int32_t *)((uVar1 + 0x33) - uVar3) << (3 - uVar3) * 8 | uVar15 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x30) - uVar4) >> uVar4 * 8;
        uVar19 = (uVar18 >> 10 | uVar18 * 0x400000) + uVar10;
        uVar7 = uVar15 + 0x6b901122 + uVar7;
        *(uint32_t *)(arg1 + 0x88) = uVar15;
        uVar4 = ((uVar17 ^ uVar10) & uVar19 ^ uVar17) + uVar7;
        uVar3 = uVar1 + 0x37 & 3;
        uVar18 = (uVar4 * 0x80 | uVar4 >> 0x19) + uVar19;
        uVar4 = uVar1 + 0x34 & 3;
        uVar7 = (*(int32_t *)((uVar1 + 0x37) - uVar3) << (3 - uVar3) * 8 | uVar7 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x34) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(arg1 + 0x8c) = uVar7;
        uVar17 = uVar7 + 0xfd987193 + uVar17;
        uVar20 = ((uVar10 ^ uVar19) & uVar18 ^ uVar10) + uVar17;
        uVar3 = uVar1 + 0x3b & 3;
        uVar4 = uVar1 + 0x38 & 3;
        uVar17 = (*(int32_t *)((uVar1 + 0x3b) - uVar3) << (3 - uVar3) * 8 | uVar17 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x38) - uVar4) >> uVar4 * 8;
        uVar26 = (uVar20 * 0x1000 | uVar20 >> 0x14) + uVar18;
        *(uint32_t *)(arg1 + 0x90) = uVar17;
        uVar10 = uVar17 + 0xa679438e + uVar10;
        uVar20 = ((uVar19 ^ uVar18) & uVar26 ^ uVar19) + uVar10;
        uVar3 = uVar1 + 0x3f & 3;
        uVar4 = uVar1 + 0x3c & 3;
        uVar3 = (*(int32_t *)((uVar1 + 0x3f) - uVar3) << (3 - uVar3) * 8 | uVar10 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x3c) - uVar4) >> uVar4 * 8;
        uVar20 = (uVar20 >> 0xf | uVar20 * 0x20000) + uVar26;
        uVar4 = ((uVar18 ^ uVar26) & uVar20 ^ uVar18) + uVar3 + 0x49b40821 + uVar19;
        uVar19 = (uVar4 >> 10 | uVar4 * 0x400000) + uVar20;
        uVar4 = ((uVar20 ^ uVar19) & uVar26 ^ uVar20) + uVar12 + 0xf61e2562 + uVar18;
        uVar10 = (uVar4 * 0x20 | uVar4 >> 0x1b) + uVar19;
        uVar4 = ((uVar19 ^ uVar10) & uVar20 ^ uVar19) + uVar8 + 0xc040b340 + uVar26;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar18 = ((uVar10 ^ uVar4) & uVar19 ^ uVar10) + uVar6 + 0x265e5a51 + uVar20;
        uVar20 = (uVar18 * 0x4000 | uVar18 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar20) & uVar10 ^ uVar4) + uVar25 + 0xe9b6c7aa + uVar19;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar20;
        uVar10 = ((uVar20 ^ uVar18) & uVar4 ^ uVar20) + uVar16 + 0xd62f105d + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar20 ^ uVar18) + uVar13 + 0x2441453 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar3 + 0xd8a1e681 + uVar20;
        uVar19 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar19) & uVar10 ^ uVar4) + uVar9 + 0xe7d3fbc8 + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar19;
        uVar10 = ((uVar19 ^ uVar18) & uVar4 ^ uVar19) + uVar2 + 0x21e1cde6 + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar19 ^ uVar18) + uVar17 + 0xc33707d6 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar14 + 0xf4d50d87 + uVar19;
        uVar19 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar19) & uVar10 ^ uVar4) + uVar11 + 0x455a14ed + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar19;
        uVar10 = ((uVar19 ^ uVar18) & uVar4 ^ uVar19) + uVar7 + 0xa9e3e905 + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar19 ^ uVar18) + uVar5 + 0xfcefa3f8 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar24 + 0x676f02d9 + uVar19;
        uVar20 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar20) & uVar10 ^ uVar4) + uVar15 + 0x8d2a4c8a + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar20;
        uVar10 = (uVar16 - 0x5c6be) + uVar10 + (uVar4 ^ uVar20 ^ uVar18);
        uVar19 = (uVar10 * 0x10 | uVar10 >> 0x1c) + uVar18;
        uVar4 = uVar11 + 0x8771f681 + uVar4 + (uVar20 ^ uVar18 ^ uVar19);
        uVar10 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar19;
        uVar4 = uVar6 + 0x6d9d6122 + uVar20 + (uVar18 ^ uVar19 ^ uVar10);
        uVar4 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar18 = uVar17 + 0xfde5380c + uVar18 + (uVar19 ^ uVar10 ^ uVar4);
        uVar18 = (uVar18 >> 9 | uVar18 * 0x800000) + uVar4;
        uVar19 = uVar12 + 0xa4beea44 + uVar19 + (uVar10 ^ uVar4 ^ uVar18);
        uVar19 = (uVar19 * 0x10 | uVar19 >> 0x1c) + uVar18;
        uVar10 = uVar9 + 0x4bdecfa9 + uVar10 + (uVar4 ^ uVar18 ^ uVar19);
        uVar10 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar19;
        uVar4 = uVar24 + 0xf6bb4b60 + uVar4 + (uVar18 ^ uVar19 ^ uVar10);
        uVar4 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar18 = uVar13 + 0xbebfbc70 + uVar18 + (uVar19 ^ uVar10 ^ uVar4);
        uVar20 = (uVar18 >> 9 | uVar18 * 0x800000) + uVar4;
        uVar18 = uVar7 + 0x289b7ec6 + uVar19 + (uVar10 ^ uVar4 ^ uVar20);
        uVar18 = (uVar18 * 0x10 | uVar18 >> 0x1c) + uVar20;
        uVar10 = uVar25 + 0xeaa127fa + uVar10 + (uVar4 ^ uVar20 ^ uVar18);
        uVar10 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar18;
        uVar4 = uVar14 + 0xd4ef3085 + uVar4 + (uVar20 ^ uVar18 ^ uVar10);
        uVar19 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar4 = uVar8 + 0x4881d05 + uVar20 + (uVar18 ^ uVar10 ^ uVar19);
        uVar4 = (uVar4 >> 9 | uVar4 * 0x800000) + uVar19;
        uVar18 = uVar2 + 0xd9d4d039 + uVar18 + (uVar10 ^ uVar19 ^ uVar4);
        uVar18 = (uVar18 * 0x10 | uVar18 >> 0x1c) + uVar4;
        uVar10 = uVar15 + 0xe6db99e5 + uVar10 + (uVar19 ^ uVar4 ^ uVar18);
        uVar20 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar18;
        uVar10 = uVar3 + 0x1fa27cf8 + uVar19 + (uVar4 ^ uVar18 ^ uVar20);
        uVar10 = (uVar10 * 0x10000 | uVar10 >> 0x10) + uVar20;
        uVar4 = uVar5 + 0xc4ac5665 + uVar4 + (uVar18 ^ uVar20 ^ uVar10);
        uVar4 = (uVar4 >> 9 | uVar4 * 0x800000) + uVar10;
        uVar18 = ((~uVar20 | uVar4) ^ uVar10) + uVar25 + 0xf4292244 + uVar18;
        uVar18 = (uVar18 * 0x40 | uVar18 >> 0x1a) + uVar4;
        uVar19 = ((~uVar10 | uVar18) ^ uVar4) + uVar24 + 0x432aff97 + uVar20;
        uVar19 = (uVar19 * 0x400 | uVar19 >> 0x16) + uVar18;
        uVar10 = ((~uVar4 | uVar19) ^ uVar18) + uVar17 + 0xab9423a7 + uVar10;
        uVar17 = (uVar10 * 0x8000 | uVar10 >> 0x11) + uVar19;
        uVar4 = ((~uVar18 | uVar17) ^ uVar19) + uVar16 + 0xfc93a039 + uVar4;
        uVar16 = (uVar4 >> 0xb | uVar4 * 0x200000) + uVar17;
        uVar4 = ((~uVar19 | uVar16) ^ uVar17) + uVar15 + 0x655b59c3 + uVar18;
        uVar15 = (uVar4 * 0x40 | uVar4 >> 0x1a) + uVar16;
        uVar4 = ((~uVar17 | uVar15) ^ uVar16) + uVar14 + 0x8f0ccc92 + uVar19;
        uVar10 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar15;
        uVar4 = ((~uVar16 | uVar10) ^ uVar15) + (uVar13 - 0x100b83) + uVar17;
        uVar13 = (uVar4 * 0x8000 | uVar4 >> 0x11) + uVar10;
        uVar4 = ((~uVar15 | uVar13) ^ uVar10) + uVar12 + 0x85845dd1 + uVar16;
        in_t9 = uVar4 >> 0xb;
        uVar12 = (in_t9 | uVar4 * 0x200000) + uVar13;
        uVar4 = ((~uVar10 | uVar12) ^ uVar13) + uVar11 + 0x6fa87e4f + uVar15;
        in_t8 = uVar4 * 0x40;
        uVar4 = (in_t8 | uVar4 >> 0x1a) + uVar12;
        *(uint32_t *)(arg1 + 0x94) = uVar3;
        uVar3 = ((~uVar13 | uVar4) ^ uVar12) + uVar3 + 0xfe2ce6e0 + uVar10;
        uVar10 = (uVar3 * 0x400 | uVar3 >> 0x16) + uVar4;
        uVar3 = ((~uVar12 | uVar10) ^ uVar4) + uVar8 + 0xa3014314 + uVar13;
        in_t6 = uVar3 * 0x8000;
        uVar8 = (in_t6 | uVar3 >> 0x11) + uVar10;
        uVar3 = ((~uVar4 | uVar8) ^ uVar10) + uVar7 + 0x4e0811a1 + uVar12;
        uVar7 = (uVar3 >> 0xb | uVar3 * 0x200000) + uVar8;
        uVar3 = ((~uVar10 | uVar7) ^ uVar8) + uVar9 + 0xf7537e82 + uVar4;
        uVar4 = (uVar3 * 0x40 | uVar3 >> 0x1a) + uVar7;
        uVar3 = ((~uVar8 | uVar4) ^ uVar7) + uVar6 + 0xbd3af235 + uVar10;
        in_t4 = uVar3 * 0x400;
        in_t2 = (in_t4 | uVar3 >> 0x16) + uVar4;
        uVar3 = ((~uVar7 | in_t2) ^ uVar4) + uVar5 + 0x2ad7d2bb + uVar8;
        iStack132 = iStack132 + uVar4;
        uVar3 = (uVar3 * 0x8000 | uVar3 >> 0x11) + in_t2;
        uVar4 = ((~uVar4 | uVar3) ^ in_t2) + uVar2 + 0xeb86d391 + uVar7;
        uVar22 = uVar22 + uVar3;
        uVar1 = uVar1 + 0x40;
        uVar21 = uVar21 + (uVar4 >> 0xb | uVar4 * 0x200000) + uVar3;
        uVar23 = uVar23 + in_t2;
    } while (uVar1 != arg2 + arg3);
    *(uint32_t *)(arg1 + 0xc) = uVar21;
    *(uint32_t *)(arg1 + 0x10) = uVar22;
    *(uint32_t *)(arg1 + 0x14) = uVar23;
    *(int32_t *)(arg1 + 8) = iStack132;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc041a0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE

int32_t fcn.bfc041a0(int32_t arg1, int32_t arg2)
{
    int32_t in_v0;
    int32_t iVar1;
    undefined4 in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    
    if (arg2 != 0) {
        if (((uint32_t)arg2 < *(uint32_t *)arg1) || (*(uint32_t *)arg1 + 0x10000 < (uint32_t)arg2)) {
            iVar1 = 0;
            if ((*(uint32_t *)0xa0180050 & 1) != 0) {
                iVar1 = fcn.bfc05988(in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84, in_stack_fffffbec, 
                                     in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                                     in_stack_fffffc18, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc00, 
                                     in_stack_fffffc1c, in_stack_fffffc2c, in_stack_fffffc0c, in_stack_fffffc20, 
                                     in_stack_fffffc08, in_stack_fffffc24, in_stack_fffffc04, in_stack_fffffc28);
                printf(in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, in_stack_00000c0c, in_stack_fffffbf4, 
                       in_stack_fffffbf0);
            }
            return iVar1;
        }
        iVar1 = *(int32_t *)(arg1 + 4);
        *(int32_t *)(arg2 + 8) = iVar1;
        *(int32_t *)(iVar1 + 0xc) = arg2;
        iVar1 = *(int32_t *)(arg1 + 8);
        *(undefined4 *)(arg2 + 0xc) = 0;
        *(int32_t *)(arg1 + 8) = iVar1 + 1;
        *(int32_t *)(arg1 + 4) = arg2;
        in_v0 = *(int32_t *)(arg1 + 0xc) + -1;
        *(int32_t *)(arg1 + 0xc) = in_v0;
    }
    return in_v0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc040f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.

int32_t * fcn.bfc040f4(int32_t arg1)
{
    int32_t iVar1;
    int32_t arg1_00;
    undefined in_a1;
    undefined in_a3;
    int32_t unaff_s0;
    int32_t *piVar2;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    piVar2 = (int32_t *)0x0;
    if ((*(int32_t *)(arg1 + 8) != 0) && (piVar2 = *(int32_t **)(arg1 + 4), piVar2 != (int32_t *)0x0)) {
        iVar1 = piVar2[2];
        *(int32_t *)(arg1 + 4) = iVar1;
        arg1_00 = *piVar2;
        *(undefined4 *)(iVar1 + 0xc) = 0;
        piVar2[2] = 0;
        piVar2[3] = 0;
        fcn.bfc07918(arg1_00, in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0, in_stack_ffffffd4);
        *(undefined *)(piVar2 + 1) = in_a3;
        *(undefined *)((int32_t)piVar2 + 5) = in_a1;
        *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + -1;
        *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + 1;
    }
    return piVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc043c0 failed, args may be inaccurate.

int16_t fcn.bfc043c0(int32_t arg1, int32_t arg2)
{
    int16_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    
    iVar1 = 0;
    uVar2 = 0;
    iVar3 = 4;
    do {
        iVar3 = *(int32_t *)(arg1 + iVar3 * 4);
        if (iVar3 != 0) {
            iVar1 = iVar1 + (uint16_t)*(uint8_t *)(iVar3 + 4);
        }
        uVar2 = uVar2 + 1 & 0xff;
        iVar3 = uVar2 + 4;
    } while (uVar2 <= *(uint8_t *)(arg1 + 0x52));
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function putc failed, args may be inaccurate.

undefined4 putc(int32_t arg_8h)
{
    undefined4 in_a0;
    
    do {
    } while ((**(uint32_t **)0xa0180064 & 2) == 0);
    **(undefined4 **)0xa0180060 = in_a0;
    return in_a0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function isdigit failed, args may be inaccurate.

undefined4 isdigit(int32_t arg_8h)
{
    undefined4 uVar1;
    int32_t in_a0;
    
    if ((in_a0 < 0x30) || (0x39 < in_a0)) {
        uVar1 = 0;
    } else {
        uVar1 = 1;
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function atoi failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function iswhitespace failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function isdigit failed, args may be inaccurate.

int32_t atoi(int32_t arg_28h, int32_t arg_10h, int32_t arg_14h, int32_t arg_1ch, int32_t arg_18h)
{
    int32_t iVar1;
    char *in_a0;
    undefined *puVar2;
    undefined *puVar3;
    char *pcStackX0;
    undefined auStack40 [4];
    int32_t aiStack36 [4];
    int32_t iStack20;
    int32_t iStack16;
    int32_t iStack12;
    
    if (in_a0 == (char *)0x0) {
        iStack20 = 0;
    } else {
        aiStack36[3] = 0;
        iStack20 = 1;
        iStack12 = 0;
        puVar2 = auStack40;
        pcStackX0 = in_a0;
        while( true ) {
            iVar1 = iswhitespace(*(int32_t *)(puVar2 + 4));
            puVar3 = puVar2 + 4;
            if (iVar1 == 0) break;
            pcStackX0 = pcStackX0 + 1;
            puVar2 = puVar2 + 4;
        }
        iStack16 = 0;
        while (*pcStackX0 != '\0') {
            if (*pcStackX0 == '-') {
                if (iStack16 != 0) {
                    return 0;
                }
                iStack20 = -1;
                iStack16 = 1;
            } else {
                if (*pcStackX0 == '+') {
                    if (iStack16 != 0) {
                        return 0;
                    }
                    iStack16 = 1;
                } else {
                    iVar1 = isdigit(*(int32_t *)(puVar3 + 4));
                    puVar3 = puVar3 + 4;
                    if (iVar1 == 0) break;
                    if ((iStack16 != 0) && (iStack16 != 1)) {
                        return 0;
                    }
                    iStack16 = 1;
                    aiStack36[3] = aiStack36[3] * 10 + *pcStackX0 + -0x30;
                    iStack12 = iStack12 + 1;
                    if (iStack12 == 9) break;
                }
            }
            iStack16 = 1;
            pcStackX0 = pcStackX0 + 1;
        }
        iStack20 = iStack20 * aiStack36[3];
    }
    return iStack20;
}

// WARNING: Removing unreachable block (ram,0xbfc04a30)
// WARNING: Removing unreachable block (ram,0xbfc04a6c)
// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.

void fcn.bfc049ec(int32_t arg_30h, int32_t arg_34h, int32_t arg_8h, int32_t arg_0h, int32_t arg_4h)
{
    int32_t in_a0;
    int32_t in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    
    pcStack48 = acStack40;
    iStack44 = 0;
    arg_4h = in_a0;
    if (in_a1 != 0) {
        do {
            *pcStack48 = (char)((uint32_t)arg_4h % 10) + '0';
            arg_4h = (uint32_t)arg_4h / 10;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
            arg_8h = in_a1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Removing unreachable block (ram,0xbfc04bb0)
// WARNING: Removing unreachable block (ram,0xbfc04bec)
// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.

void fcn.bfc04b30(int32_t arg_30h, int32_t arg_34h, int32_t arg_8h, int32_t arg_0h, int32_t arg_4h)
{
    int32_t in_a0;
    undefined *in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    
    pcStack48 = acStack40;
    iStack44 = 0;
    if (in_a1 != (undefined *)0x0) {
        arg_4h = in_a0;
        arg_8h = (int32_t)in_a1;
        if (in_a0 < 0) {
            *in_a1 = 0x2d;
            arg_8h = (int32_t)(in_a1 + 1);
            arg_4h = -in_a0;
        }
        do {
            *pcStack48 = (char)(arg_4h % 10) + '0';
            arg_4h = arg_4h / 10;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

void fcn.bfc04cb0(int32_t arg_30h, int32_t arg_34h, int32_t arg_8h, int32_t arg_0h, int32_t arg_4h)
{
    int32_t in_a0;
    int32_t in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    
    pcStack48 = acStack40;
    iStack44 = 0;
    arg_4h = in_a0;
    if (in_a1 != 0) {
        do {
            *pcStack48 = ((uint8_t)arg_4h & 0xf) + 0x30;
            if ('9' < *pcStack48) {
                *pcStack48 = *pcStack48 + '\a';
            }
            arg_4h = (uint32_t)arg_4h >> 4;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
            arg_8h = in_a1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06740 failed, args may be inaccurate.

int32_t * fcn.bfc06740(int32_t arg_18h, int32_t arg_0h, int32_t arg_4h, int32_t arg_8h, int32_t arg_ch)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    int32_t in_a0;
    uint32_t uStack24;
    
    piVar1 = *(int32_t **)0xa0180070;
    uStack24 = in_a0 + 4;
    if ((uStack24 & 0xfff) != 0) {
        uStack24 = ((uStack24 >> 0xc) + 1) * 0x1000;
    }
    puVar3 = (undefined4 *)((int32_t)*(int32_t **)0xa0180070 + (uStack24 - 8));
    iVar2 = (int32_t)*(int32_t **)0xa0180070 + uStack24;
    **(int32_t **)0xa0180070 = uStack24 - 4;
    *(int32_t *)0xa0180070 = (int32_t *)iVar2;
    puVar3[1] = 0;
    *puVar3 = *(undefined4 *)0xa0180d90;
    *(int32_t **)0xa0180d90 = piVar1;
    return piVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07830 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07770 failed, args may be inaccurate.

uint32_t fcn.bfc07830(int32_t arg_28h, int32_t arg_30h, int32_t arg_2ch, int32_t arg_10h, int32_t arg_14h,
                     int32_t arg_18h)
{
    int32_t in_a0;
    char in_a1;
    uint32_t in_a2;
    int32_t in_stack_ffffffdc;
    uint32_t uStack24;
    
    uStack24 = 0;
    while ((uStack24 < in_a2 && (*(undefined *)(in_a0 + uStack24) = 0, in_a1 != '\0'))) {
        *(undefined *)(in_a0 + uStack24) = 0;
        uStack24 = uStack24 + 1;
    }
    if (uStack24 == in_a2) {
        fcn.bfc07770(in_stack_ffffffdc);
    }
    return uStack24;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07770 failed, args may be inaccurate.

undefined4 fcn.bfc07770(int32_t arg_8h)
{
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function iswhitespace failed, args may be inaccurate.

undefined4 iswhitespace(int32_t arg_8h)
{
    undefined4 uVar1;
    int32_t in_a0;
    
    if ((((in_a0 == 0x20) || (in_a0 == 9)) || (in_a0 == 10)) || (((in_a0 == 0xb || (in_a0 == 0xc)) || (in_a0 == 0xd))))
    {
        uVar1 = 1;
    } else {
        uVar1 = 0;
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.

undefined4 fcn.bfc07f9c(int32_t arg1, int32_t arg2)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if (*(int32_t **)(arg1 + 8) != (int32_t *)0x0) {
        uVar1 = 0;
        if ((arg1 != 0) && (piVar3 = *(int32_t **)(arg1 + 8), piVar3 == *(int32_t **)(arg1 + 8))) {
            iVar4 = *(int32_t *)arg1;
            if (iVar4 != 0) {
                *(undefined4 *)(iVar4 + 4) = *(undefined4 *)(arg1 + 4);
            }
            piVar2 = *(int32_t **)(arg1 + 4);
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (arg1 == piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (arg1 == piVar3[1]) {
                piVar3[1] = *(int32_t *)arg1;
            }
            iVar4 = *piVar3;
            *(undefined4 *)(arg1 + 8) = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08cbc failed, args may be inaccurate.

int32_t fcn.bfc08cbc(int32_t arg2, int32_t arg1, int32_t arg4)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t in_a2;
    int32_t iVar4;
    
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 & 0xffffdfff, 0);
    iVar1 = 0;
    while( true ) {
        if (iVar1 == in_a2) {
            if ((**(uint32_t **)0xa0180088 & 6) == 2) {
                **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 4;
            }
            setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x2001, 0);
            return iVar1;
        }
        uVar2 = *(uint32_t *)(arg1 + 0x100c);
        if (0x800 < uVar2) break;
        iVar4 = *(int32_t *)(arg1 + 0x1010);
        uVar3 = iVar4 + 1;
        *(uint32_t *)(arg1 + 0x1010) = uVar3;
        *(undefined *)(arg1 + iVar4 + 0x800) = *(undefined *)(arg2 + iVar1);
        if (0x7ff < uVar3) {
            *(undefined4 *)(arg1 + 0x1010) = 0;
        }
        iVar1 = iVar1 + 1;
        *(uint32_t *)(arg1 + 0x100c) = uVar2 + 1;
    }
    return -1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc083b0 failed, args may be inaccurate.

uint32_t fcn.bfc083b0(int32_t arg2, int32_t arg3, int32_t arg1, int32_t arg4)
{
    uint32_t uVar1;
    char cVar2;
    uint32_t uVar3;
    uint8_t *puVar4;
    uint32_t uVar5;
    
    uVar1 = 0;
    if (arg3 != 0) {
        uVar1 = 0xffff;
        puVar4 = (uint8_t *)arg2;
        do {
            puVar4 = puVar4 + 1;
            uVar3 = (uint32_t)*puVar4;
            cVar2 = '\b';
            do {
                uVar5 = uVar3 ^ uVar1;
                uVar1 = uVar1 >> 1;
                if ((uVar5 & 1) != 0) {
                    uVar1 = uVar1 ^ 0x8408;
                }
                cVar2 = cVar2 + -1;
                uVar3 = uVar3 >> 1;
            } while (cVar2 != '\0');
            puVar4 = puVar4;
        } while (puVar4 != (uint8_t *)(arg2 + arg3));
        uVar1 = ~uVar1 >> 8 & 0xff | (~uVar1 & 0xff) << 8;
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0824c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

int32_t fcn.bfc0824c(int32_t arg2, int32_t arg1, int32_t arg4, int32_t arg3)
{
    undefined *puVar1;
    int32_t arg1_00;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t unaff_s2;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    
    printf2(4, arg2, -0x5fe7f540);
    puVar1 = (undefined *)fcn.bfc03e88(unaff_s0);
    iVar2 = *(int32_t *)(arg1 + 0x28);
    *puVar1 = 0x31;
    fcn.bfc01864(iVar2, (int32_t)(puVar1 + 1));
    puVar1[5] = (char)arg2;
    arg1_00 = fcn.bfc03e50(unaff_s2);
    fcn.bfc01930(arg1_00, puVar1, 6, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x34));
    if (iVar2 == 0) {
        fcn.bfc01984(arg1_00);
        iVar2 = in_stack_00000008;
        fcn.bfc03efc(in_stack_00000008, in_stack_0000000c);
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc085c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d04 failed, args may be inaccurate.

void fcn.bfc085c0(int32_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = fcn.bfc02d04(arg1 + 0x20);
    *(undefined4 *)(arg1 + 0x28) = uVar1;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08d80 failed, args may be inaccurate.

bool fcn.bfc08d80(int32_t arg1)
{
    return *(int32_t *)(arg1 + 0x1000) != 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08c20 failed, args may be inaccurate.

void fcn.bfc08c20(int32_t arg2, int32_t arg1, int32_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t in_a2;
    
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 & 0xffffefff, 0);
    iVar1 = 0;
    while ((*(int32_t *)(arg1 + 0x1000) != 0 && (in_a2 != iVar1))) {
        iVar2 = *(int32_t *)(arg1 + 0x1008);
        *(int32_t *)(arg1 + 0x1008) = iVar2 + 1;
        *(undefined *)(arg2 + iVar1) = *(undefined *)(arg1 + iVar2);
        if (0x7ff < *(uint32_t *)(arg1 + 0x1008)) {
            *(undefined4 *)(arg1 + 0x1008) = 0;
        }
        iVar1 = iVar1 + 1;
        *(int32_t *)(arg1 + 0x1000) = *(int32_t *)(arg1 + 0x1000) + -1;
    }
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x1001, 0);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08184 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

int32_t fcn.bfc08184(int32_t arg3, int32_t arg1, int32_t arg4, int32_t arg2)
{
    undefined *puVar1;
    int32_t arg1_00;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    puVar1 = (undefined *)fcn.bfc03e88(in_stack_ffffffe4);
    iVar2 = *(int32_t *)(arg1 + 0x28);
    *puVar1 = 0x37;
    fcn.bfc01864(iVar2, (int32_t)(puVar1 + 1));
    fcn.bfc07918((int32_t)(puVar1 + 5), in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0, in_stack_ffffffd4);
    arg1_00 = fcn.bfc03e50(unaff_s1);
    fcn.bfc01930(arg1_00, puVar1, arg3 + 5, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x34));
    if (iVar2 == 0) {
        fcn.bfc01984(arg1_00);
        iVar2 = in_stack_00000000;
        fcn.bfc03efc(in_stack_00000000, in_stack_00000004);
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08418 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc018f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memset failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc083b0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01908 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08cbc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

uint32_t fcn.bfc08418(int32_t arg2, int32_t arg1, int32_t arg4, int32_t arg3)
{
    uint32_t uVar1;
    undefined *arg2_00;
    int32_t arg2_01;
    undefined *arg1_00;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t unaff_s2;
    undefined *puVar2;
    undefined4 unaff_s8;
    char in_stack_00000010;
    undefined4 in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffd8;
    
    if (*(char *)arg2 != -100) {
        uVar1 = 5;
        if (*(char *)arg2 == 'M') {
            if (arg3 != 5) goto code_r0xbfc017e0;
            uVar1 = fcn.bfc018f4(arg2 + 1);
            if (*(uint32_t *)(arg1 + 0x2c) < uVar1) {
                *(uint32_t *)(arg1 + 0x2c) = uVar1;
            }
        }
        return uVar1;
    }
    uVar1 = arg4 - 3;
    if (in_stack_00000010 == '\0') {
        uVar1 = arg4 - 1;
    }
    if (arg3 - 5U == (uVar1 & 0xff)) {
        uVar1 = fcn.bfc018f4(arg2 + 1);
        if (*(uint32_t *)(arg1 + 0x2c) < uVar1) {
            *(uint32_t *)(arg1 + 0x2c) = uVar1;
        }
        arg2_00 = (undefined *)fcn.bfc03e88(unaff_s1);
        memset(unaff_s0, unaff_s1, unaff_s2, in_stack_ffffffd4, in_stack_ffffffd8);
        puVar2 = &stack0xffffffdc;
        arg1_00 = arg2_00 + 1;
        *arg2_00 = (char)*(undefined4 *)(arg1 + 0xc);
        if (in_stack_00000010 != '\0') {
            arg2_01 = fcn.bfc083b0(arg2 + 5, arg3 - 5U, arg1, arg4);
            fcn.bfc01908((int32_t)arg1_00, arg2_01);
            puVar2 = &stack0xffffffe4;
            arg1_00 = arg2_00 + 3;
        }
        fcn.bfc07918((int32_t)arg1_00, *(int32_t *)(puVar2 + 0xc), *(int32_t *)(puVar2 + 0x10), 
                     *(int32_t *)(puVar2 + 0x14), *(int32_t *)(puVar2 + -4));
        fcn.bfc08cbc(arg2_00, *(undefined4 *)(arg1 + 0x30), arg4, puVar2[4]);
        *(undefined4 *)(puVar2 + 0x34) = *(undefined4 *)(puVar2 + 0x34);
        *(undefined4 *)(puVar2 + 0x30) = unaff_s8;
        *(undefined **)(puVar2 + 0x38) = arg2_00;
        *(undefined4 *)(puVar2 + 0x3c) = 1;
        uVar1 = fcn.bfc06d40(*(int32_t *)(puVar2 + 0x38), *(int32_t *)(puVar2 + 0x3c), *(int32_t *)(puVar2 + 0x1c), 
                             *(int32_t *)(puVar2 + 0x30), *(int32_t *)(puVar2 + 0x20), *(int32_t *)(puVar2 + 0x24), 
                             *(int32_t *)(puVar2 + 0x28), *(int32_t *)(puVar2 + 0x2c));
        return uVar1;
    }
code_r0xbfc017e0:
    uVar1 = 0;
    if ((*(uint32_t *)0xa0180050 & 2) != 0) {
        uVar1 = fcn.bfc05988(in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84, in_stack_fffffbec, 
                             in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                             in_stack_fffffc18, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc00, 
                             in_stack_fffffc1c, in_stack_fffffc2c, in_stack_fffffc0c, in_stack_fffffc20, 
                             in_stack_fffffc08, in_stack_fffffc24, in_stack_fffffc04, in_stack_fffffc28);
        printf(in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, in_stack_00000c0c, in_stack_fffffbf4, 
               in_stack_fffffbf0);
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08150 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08cbc failed, args may be inaccurate.

void fcn.bfc08150(int32_t arg1, int32_t arg2, int32_t arg3)
{
    int32_t in_a3;
    undefined uStack24;
    undefined uStack23;
    
    uStack24 = (undefined)*(undefined4 *)(arg1 + 0x14);
    uStack23 = 0;
    fcn.bfc08cbc((int32_t)&uStack24, *(int32_t *)(arg1 + 0x30), in_a3);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0830c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01864 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01930 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01a48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.

int32_t fcn.bfc0830c(int32_t arg1, int32_t arg4, int32_t arg3, int32_t arg2)
{
    undefined *puVar1;
    int32_t arg1_00;
    int32_t iVar2;
    int32_t unaff_s1;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_ffffffec;
    
    puVar1 = (undefined *)fcn.bfc03e88(in_stack_ffffffec);
    iVar2 = *(int32_t *)(arg1 + 0x28);
    *puVar1 = 0x4a;
    fcn.bfc01864(iVar2, (int32_t)(puVar1 + 1));
    arg1_00 = fcn.bfc03e50(unaff_s1);
    fcn.bfc01930(arg1_00, puVar1, 5, 0xbfc0184c);
    iVar2 = fcn.bfc01a48(*(int32_t *)(arg1 + 0x34));
    if (iVar2 == 0) {
        fcn.bfc01984(arg1_00);
        iVar2 = in_stack_00000004;
        fcn.bfc03efc(in_stack_00000004, in_stack_00000008);
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08ba8 failed, args may be inaccurate.

void fcn.bfc08ba8(int32_t arg1)
{
    *(undefined4 *)(arg1 + 0x1000) = 0;
    *(undefined4 *)(arg1 + 0x1004) = 0;
    *(undefined4 *)(arg1 + 0x1008) = 0;
    *(undefined4 *)(arg1 + 0x100c) = 0;
    *(undefined4 *)(arg1 + 0x1010) = 0;
    *(undefined4 *)(arg1 + 0x1014) = 0;
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x1001, 0);
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x2001, 0);
    **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 1;
    **(uint32_t **)0xa0180080 = **(uint32_t **)0xa0180080 | 1;
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dd4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type signed int for variable arg1 to Decompiler type: Unknown type identifier
// signed

void fcn.bfc08dd4(undefined4 arg1, int32_t arg2, int32_t arg4, int32_t arg3, int32_t arg_18h, int32_t arg_1ch,
                 int32_t arg_0h, int32_t arg_4h, int32_t arg_8h)
{
    uint32_t uVar1;
    uint32_t uStack24;
    uint32_t uStack20;
    int32_t iStack16;
    
    uStack24 = 10;
    uStack20 = 0;
    iStack16 = 0;
    while (iStack16 < 0x10) {
        uStack24 = uStack24 ^ (uStack20 << 0x14 | uStack24 >> 0xc);
        uStack20 = uStack20 ^ uStack20 >> 0xc;
        uVar1 = uStack24 ^ uStack24 << 0x19;
        uStack20 = uStack20 ^ (uStack24 >> 7 | uStack20 << 0x19);
        uStack24 = uVar1 ^ (uStack20 << 5 | uVar1 >> 0x1b);
        uStack20 = uStack20 ^ uStack20 >> 0x1b;
        *(int32_t *)(iStack16 * 8 + -0x5fe7f240) = (int32_t)((uint64_t)uStack24 * 0xd81ecd35);
        *(uint32_t *)(iStack16 * 8 + -0x5fe7f23c) =
             uStack20 * -0x27e132cb + uStack24 * 0x19071d96 + (int32_t)((uint64_t)uStack24 * 0xd81ecd35 >> 0x20);
        iStack16 = iStack16 + 1;
    }
    *(undefined4 *)0xa0180d8c = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01840 failed, args may be inaccurate.

void fcn.bfc01840(undefined4 param_1)
{
    *(undefined4 *)0xa0180050 = param_1;
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc019cc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03e88 failed, args may be inaccurate.

int32_t fcn.bfc019cc(int32_t arg1, int32_t arg_10h, int32_t arg_14h, int32_t arg_0h)
{
    int32_t iVar1;
    int32_t in_a1;
    int32_t unaff_retaddr;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_fffffff0;
    
    fcn.bfc07d40(arg1);
    *(undefined4 *)(arg1 + 0xc) = 0;
    *(undefined4 *)(arg1 + 0x10) = 0;
    strlen(in_stack_fffffff0, in_stack_ffffffe0);
    iVar1 = fcn.bfc03e88(unaff_retaddr);
    *(int32_t *)(arg1 + 0xc) = iVar1;
    arg_0h = 0;
    while (*(char *)(in_a1 + arg_0h) != '\0') {
        *(undefined *)(iVar1 + arg_0h) = *(undefined *)(in_a1 + arg_0h);
        arg_0h = arg_0h + 1;
    }
    *(undefined *)(iVar1 + arg_0h) = 0;
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08080 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02cd0 failed, args may be inaccurate.

void fcn.bfc08080(int32_t arg1)
{
    undefined4 in_a1;
    undefined4 in_a2;
    undefined4 in_a3;
    undefined4 in_stack_00000014;
    
    *(undefined4 *)arg1 = 0xc0;
    *(undefined4 *)(arg1 + 4) = 0x10;
    *(undefined4 *)(arg1 + 8) = 0x20;
    *(undefined4 *)(arg1 + 0xc) = 0xe3;
    *(undefined4 *)(arg1 + 0x10) = 0x79;
    *(undefined4 *)(arg1 + 0x14) = 0x13;
    *(undefined4 *)(arg1 + 0x18) = 0x55;
    *(undefined4 *)(arg1 + 0x1c) = 0x31;
    fcn.bfc02cd0(arg1 + 0x20);
    *(undefined4 *)(arg1 + 0x30) = in_stack_00000014;
    *(undefined4 *)(arg1 + 0x34) = in_a1;
    *(char *)(arg1 + 0x1c2) = (char)*(undefined4 *)(arg1 + 8);
    *(undefined4 *)(arg1 + 0x38) = in_a2;
    *(undefined4 *)(arg1 + 0x3c) = in_a3;
    *(undefined4 *)(arg1 + 0x2c) = 0;
    *(undefined4 *)(arg1 + 0x28) = 0;
    *(undefined2 *)(arg1 + 0x1c0) = 0;
    *(undefined4 *)(arg1 + 0x1c4) = 0;
    *(undefined *)(arg1 + 0x1c8) = 1;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc008b0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_14h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03fd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02cd0 failed, args may be inaccurate.

void fcn.bfc008b0(int32_t arg1)
{
    undefined4 in_a1;
    undefined4 in_a2;
    undefined4 in_a3;
    undefined4 in_stack_0000001c;
    undefined4 in_stack_00000020;
    
    fcn.bfc03fd8();
    fcn.bfc07d40(arg1 + 0x10);
    fcn.bfc02cd0(arg1 + 0x20);
    *(undefined4 *)(arg1 + 0x70) = in_stack_0000001c;
    *(undefined4 *)(arg1 + 100) = in_a1;
    *(undefined4 *)(arg1 + 0x68) = in_a2;
    *(undefined4 *)(arg1 + 0x6c) = in_a3;
    *(undefined4 *)(arg1 + 0x58) = 0;
    *(undefined4 *)(arg1 + 0x5c) = 0;
    *(undefined4 *)(arg1 + 0x74) = in_stack_00000020;
    *(undefined4 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x2c) = 0;
    *(undefined4 *)(arg1 + 0x60) = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01c70 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d40 failed, args may be inaccurate.

void fcn.bfc01c70(int32_t arg1)
{
    undefined4 in_a1;
    undefined4 in_a2;
    undefined4 in_a3;
    
    *(undefined4 *)arg1 = in_a1;
    *(undefined4 *)(arg1 + 4) = in_a2;
    *(undefined4 *)(arg1 + 8) = in_a3;
    fcn.bfc07d40(arg1 + 0xc);
    *(undefined4 *)(arg1 + 0x18) = 0xa5b5c5d5;
    *(undefined4 *)(arg1 + 0x1c) = 0x12345678;
    *(undefined4 *)(arg1 + 0x20) = 0x41414141;
    *(undefined4 *)(arg1 + 0x24) = 0xcccccccc;
    *(undefined4 *)(arg1 + 0x28) = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08148 failed, args may be inaccurate.

void fcn.bfc08148(int32_t arg1)
{
    undefined4 in_a2;
    undefined4 in_a3;
    
    *(undefined4 *)(arg1 + 0x20) = in_a2;
    *(undefined4 *)(arg1 + 0x24) = in_a3;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0096c failed, args may be inaccurate.

void fcn.bfc0096c(int32_t arg1)
{
    undefined4 in_a2;
    undefined4 in_a3;
    
    *(undefined4 *)(arg1 + 0x20) = in_a2;
    *(undefined4 *)(arg1 + 0x24) = in_a3;
    return;
}

// WARNING: Removing unreachable block (ram,0xbfc08788)
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc085ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0824c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc085c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08d80 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08c20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01918 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc083b0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08184 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01af4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01aac failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08418 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0830c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08150 failed, args may be inaccurate.

int32_t fcn.bfc085ec(int32_t arg2, int32_t arg1, int32_t arg3, int32_t arg4)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    uint32_t arg4_00;
    uint32_t uVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    undefined4 unaff_s8;
    undefined4 uVar11;
    int32_t aiStackX0 [4];
    int32_t aiStack1020 [36];
    int32_t aiStack876 [210];
    undefined auStack36 [4];
    undefined auStack32 [4];
    undefined auStack28 [16];
    
    uVar4 = 0xa0180b70;
    printf2(4, arg3, -0x5fe7f490);
    puVar8 = auStack36;
    if (*(char *)(arg1 + 0x1c8) != '\0') {
        uVar4 = *(int32_t *)(arg1 + 8) - 3U & 0xff;
        fcn.bfc0824c(uVar4, arg1, arg4, arg3);
        puVar8 = auStack32;
        *(undefined *)(arg1 + 0x1c8) = 0;
    }
    fcn.bfc085c0(arg1, *puVar8);
    if (*(uint32_t *)arg1 < (uint32_t)*(uint8_t *)(arg1 + 0x1c2)) {
        *(char *)(arg1 + 0x1c2) = (char)*(uint32_t *)arg1;
    }
    iVar2 = fcn.bfc08d80(*(undefined4 *)(arg1 + 0x30), puVar8[4]);
    puVar9 = puVar8 + 8;
    if (iVar2 == 0) {
code_r0xbfc086d8:
        uVar3 = (uint32_t)*(uint16_t *)(arg1 + 0x1c0);
        arg4_00 = (uint32_t)*(uint8_t *)(arg1 + 0x1c2);
        if (uVar3 < arg4_00) goto code_r0xbfc08774;
    } else {
        uVar3 = (uint32_t)*(uint16_t *)(arg1 + 0x1c0);
        arg4_00 = (uint32_t)*(uint8_t *)(arg1 + 0x1c2);
        puVar9 = puVar8 + 8;
        if (uVar3 < arg4_00) {
            iVar6 = arg4_00 - uVar3;
            iVar2 = fcn.bfc08c20(arg1 + 0x40 + uVar3, *(undefined4 *)(arg1 + 0x30), arg4_00, puVar8[8]);
            puVar9 = puVar8 + 0xc;
            if (iVar2 < 1) {
                return iVar2;
            }
            uVar3 = iVar2 + (uint32_t)*(uint16_t *)(arg1 + 0x1c0) & 0xffff;
            *(int16_t *)(arg1 + 0x1c0) = (int16_t)uVar3;
            uVar4 = 0xa0180000;
            if (*(uint8_t *)(arg1 + 0x1c2) < uVar3) {
                uVar4 = 0xa0180b80;
                printf2(1, iVar6, 0xa0180b80, puVar8[0xc]);
                puVar9 = puVar8 + 0x10;
                *(undefined2 *)(arg1 + 0x1c0) = 0;
            }
            goto code_r0xbfc086d8;
        }
    }
    uVar5 = 0xa0180bb4;
    printf2(1, uVar3, 0xa0180bb4, *puVar9);
    uVar3 = (uint32_t)*(uint8_t *)(arg1 + 0x40);
    *(undefined2 *)(arg1 + 0x1c0) = 0;
    if (uVar3 == *(uint32_t *)(arg1 + 0xc)) {
        iVar2 = fcn.bfc01918(arg1 + 0x41, puVar9[4]);
        uVar4 = arg1 + 0x43;
        uVar7 = *(uint8_t *)(arg1 + 0x1c2) - 3;
        uVar3 = uVar7;
        iVar6 = fcn.bfc083b0(uVar4, uVar7, arg1, arg4_00, puVar9[8]);
        if (iVar6 != iVar2) {
            uVar11 = *(undefined4 *)(puVar9 + 0x30);
            uVar5 = *(undefined4 *)(puVar9 + 0x28);
            goto code_r0xbfc017e0;
        }
        arg4_00 = 1;
        fcn.bfc08184(uVar3, arg1, 1, uVar4, puVar9[0xc]);
        puVar9 = puVar9 + 0x10;
        goto code_r0xbfc08774;
    }
    if (uVar3 != *(uint32_t *)(arg1 + 0x10)) {
        if (uVar3 != *(uint32_t *)(arg1 + 0x14)) {
            uVar4 = 0xa0180cf4;
            printf2(2, uVar3, 0xa0180cf4, puVar9[4]);
            puVar9 = puVar9 + 8;
            goto code_r0xbfc08774;
        }
        *(char *)(arg1 + 0x1c2) = (char)*(undefined4 *)(arg1 + 8);
        fcn.bfc08150(arg1, uVar5, uVar3, puVar9[4]);
        puVar10 = puVar9 + 8;
        uVar4 = *(uint32_t *)(arg1 + 8);
code_r0xbfc088e4:
        uVar4 = uVar4 - 3 & 0xff;
        fcn.bfc0824c(uVar4, arg1, arg4_00, uVar3, *puVar10);
        puVar9 = puVar10 + 4;
code_r0xbfc08774:
        uVar7 = *(int32_t *)(arg1 + 0x1c4) + 1;
        if (uVar7 % 0x14 == 0) {
            *(undefined4 *)(arg1 + 0x1c4) = 0;
            fcn.bfc0830c(arg1, arg4_00, uVar3, uVar4, *puVar9);
            puVar9 = puVar9 + 4;
        } else {
            *(uint32_t *)(arg1 + 0x1c4) = uVar7;
        }
        iVar2 = fcn.bfc01af4(*(undefined4 *)(arg1 + 0x38), *puVar9);
        if (iVar2 == 0) {
            return 0;
        }
        printf2(4, uVar3, 0xa0180d18, puVar9[4]);
        iVar2 = fcn.bfc01aac(*(undefined4 *)(arg1 + 0x38), puVar9[8]);
        uVar5 = *(undefined4 *)(iVar2 + 0xc);
        uVar11 = *(undefined4 *)(iVar2 + 0x10);
        uVar1 = *(uint8_t *)(arg1 + 0x1c2);
        *(undefined4 *)(puVar9 + 0x1c) = 1;
        fcn.bfc08418(uVar5, arg1, (uint32_t)uVar1, uVar11, puVar9[0xc]);
        fcn.bfc01984(iVar2, puVar9[0x10]);
        *(undefined4 *)(puVar9 + 0x38) = *(undefined4 *)(puVar9 + 0x38);
        *(undefined4 *)(puVar9 + 0x34) = unaff_s8;
        *(int32_t *)(puVar9 + 0x3c) = iVar2;
        *(undefined4 *)(puVar9 + 0x40) = 0x18;
        iVar2 = fcn.bfc06d40(*(int32_t *)(puVar9 + 0x3c), *(int32_t *)(puVar9 + 0x40), *(int32_t *)(puVar9 + 0x20), 
                             *(int32_t *)(puVar9 + 0x34), *(int32_t *)(puVar9 + 0x24), *(int32_t *)(puVar9 + 0x28), 
                             *(int32_t *)(puVar9 + 0x2c), *(int32_t *)(puVar9 + 0x30));
        return iVar2;
    }
    uVar4 = fcn.bfc01918(arg1 + 0x41, puVar9[4]);
    arg4_00 = fcn.bfc083b0(arg1 + 0x43, *(uint8_t *)(arg1 + 0x1c2) - 3, arg1, arg4_00, puVar9[8]);
    if (arg4_00 == uVar4) {
        uVar1 = *(uint8_t *)(arg1 + 0x43);
        uVar7 = (uint32_t)uVar1;
        arg4_00 = *(uint32_t *)arg1;
        uVar4 = *(uint32_t *)(arg1 + 4);
        if ((uVar7 <= arg4_00) && (uVar4 <= uVar7)) {
            if ((uVar1 & 3) != 0) {
                uVar11 = *(undefined4 *)(puVar9 + 0x30);
                uVar5 = *(undefined4 *)(puVar9 + 0x28);
                goto code_r0xbfc017e0;
            }
            *(uint8_t *)(arg1 + 0x1c2) = uVar1;
            uVar3 = uVar7 - 3;
            printf2(4, uVar3, 0xa0180cc0, puVar9[0xc]);
            puVar10 = puVar9 + 0x10;
            uVar4 = (uint32_t)*(uint8_t *)(arg1 + 0x1c2);
            goto code_r0xbfc088e4;
        }
    }
    uVar11 = *(undefined4 *)(puVar9 + 0x30);
    uVar5 = *(undefined4 *)(puVar9 + 0x28);
    uVar7 = uVar4;
code_r0xbfc017e0:
    *(uint32_t *)(puVar9 + 0x3c) = uVar7;
    *(undefined4 *)(puVar9 + 0x2c) = uVar5;
    *(undefined4 *)(puVar9 + 0x30) = uVar11;
    *(uint32_t *)(puVar9 + 0x40) = arg4_00;
    *(undefined **)(puVar9 + 0x24) = puVar9 + 0x3c;
    iVar2 = 0;
    if ((*(uint32_t *)0xa0180050 & 4) != 0) {
        iVar2 = fcn.bfc05988(*(int32_t *)(puVar9 + -0x350), *(int32_t *)(puVar9 + -0x34c), *(int32_t *)(puVar9 + -0x348)
                             , *(int32_t *)(puVar9 + -0x3e0), *(int32_t *)(puVar9 + -0x3dc), 
                             *(int32_t *)(puVar9 + -0x3d8), *(int32_t *)(puVar9 + -0x3d4), *(int32_t *)(puVar9 + -0x3d0)
                             , *(int32_t *)(puVar9 + -0x3b4), *(int32_t *)(puVar9 + -0x3bc), 
                             *(int32_t *)(puVar9 + -0x3b8), *(int32_t *)(puVar9 + -0x3cc), *(int32_t *)(puVar9 + -0x3b0)
                             , *(int32_t *)(puVar9 + -0x3a0), *(int32_t *)(puVar9 + -0x3c0), 
                             *(int32_t *)(puVar9 + -0x3ac), *(int32_t *)(puVar9 + -0x3c4), *(int32_t *)(puVar9 + -0x3a8)
                             , *(int32_t *)(puVar9 + -0x3c8), *(int32_t *)(puVar9 + -0x3a4));
        printf(*(undefined4 *)(puVar9 + 0xc34), *(int32_t *)(puVar9 + 0xc38), *(int32_t *)(puVar9 + 0xc3c), 
               *(int32_t *)(puVar9 + 0xc40), *(int32_t *)(puVar9 + -0x3d8), *(int32_t *)(puVar9 + -0x3dc));
    }
    return iVar2;
}

// WARNING: Removing unreachable block (ram,0xbfc0170c)
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc015e0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc013e8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01af4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01aac failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01454 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01370 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d04 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01250 failed, args may be inaccurate.

uint32_t fcn.bfc015e0(int32_t arg2, int32_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    int32_t in_a2;
    int32_t in_a3;
    undefined *puVar4;
    undefined *puVar5;
    undefined *puVar6;
    undefined auStackX0 [16];
    int32_t in_stack_00000010;
    int32_t in_stack_00000014;
    undefined auStack20 [4];
    undefined auStack16 [4];
    
    printf2(4, in_a2, -0x5fe7fc6c);
    fcn.bfc013e8(arg1);
    iVar1 = fcn.bfc01af4(*(int32_t *)(arg1 + 100));
    puVar4 = auStack20;
    if (iVar1 != 0) {
        printf2(4, in_a2, -0x5fe7fc38);
        iVar1 = fcn.bfc01aac(*(int32_t *)(arg1 + 100));
        in_a2 = *(int32_t *)(iVar1 + 0x10);
        fcn.bfc01454(in_a2, *(int32_t *)(iVar1 + 0xc), arg1, in_a3);
        fcn.bfc01984(iVar1);
        fcn.bfc03efc(in_stack_00000010, in_stack_00000014);
        puVar4 = (undefined *)*(BADSPACEBASE **)0x74;
    }
    iVar1 = fcn.bfc01af4(*(undefined4 *)(arg1 + 0x70), *puVar4);
    puVar5 = puVar4 + 4;
    if (iVar1 != 0) {
        printf2(4, in_a2, 0xa01803dc, puVar4[4]);
        iVar1 = fcn.bfc01aac(*(undefined4 *)(arg1 + 0x70), puVar4[8]);
        in_a2 = *(int32_t *)(iVar1 + 0x10);
        fcn.bfc01370(in_a2, *(undefined4 *)(iVar1 + 0xc), arg1, in_a3, puVar4[0xc]);
        fcn.bfc01984(iVar1, puVar4[0x10]);
        fcn.bfc03efc(*(int32_t *)(puVar4 + 0x28), *(int32_t *)(puVar4 + 0x2c));
        puVar5 = puVar4 + 0x18;
    }
    iVar1 = fcn.bfc01af4(*(undefined4 *)(arg1 + 0x74), *puVar5);
    puVar6 = puVar5 + 4;
    uVar3 = 0xa0180000;
    if (iVar1 != 0) {
        printf2(4, in_a2, 0xa01803f0, puVar5[4]);
        uVar3 = fcn.bfc01aac(*(undefined4 *)(arg1 + 0x74), puVar5[8]);
        fcn.bfc01984(uVar3, puVar5[0xc]);
        uVar3 = 0x18;
        fcn.bfc03efc(*(int32_t *)(puVar5 + 0x24), *(int32_t *)(puVar5 + 0x28));
        puVar6 = puVar5 + 0x14;
    }
    uVar2 = *(int32_t *)(arg1 + 0x60) + 1;
    if (uVar2 % 0xf0 == 0) {
        *(undefined4 *)(arg1 + 0x60) = 0;
        fcn.bfc01250(arg1, in_a3, in_a2, uVar3, *puVar6);
        puVar6 = puVar6 + 4;
    } else {
        *(uint32_t *)(arg1 + 0x60) = uVar2;
    }
    fcn.bfc02d04(arg1 + 0x20, *puVar6);
    uVar2 = fcn.bfc07cd8(*(int32_t *)(puVar6 + 8));
    if (uVar2 < 0x1c9c381 != 0) {
        return (uint32_t)(uVar2 < 0x1c9c381);
    }
    *(int32_t *)(puVar6 + 0x30) = in_a2;
    *(undefined4 *)(puVar6 + 0x20) = *(undefined4 *)(puVar6 + 0x1c);
    *(undefined4 *)(puVar6 + 0x24) = *(undefined4 *)(puVar6 + 0x24);
    *(int32_t *)(puVar6 + 0x34) = in_a3;
    *(undefined **)(puVar6 + 0x18) = puVar6 + 0x30;
    uVar2 = 0;
    if ((*(uint32_t *)0xa0180050 & 4) != 0) {
        uVar2 = fcn.bfc05988(*(int32_t *)(puVar6 + -0x35c), *(int32_t *)(puVar6 + -0x358), *(int32_t *)(puVar6 + -0x354)
                             , *(int32_t *)(puVar6 + -0x3ec), *(int32_t *)(puVar6 + -1000), 
                             *(int32_t *)(puVar6 + -0x3e4), *(int32_t *)(puVar6 + -0x3e0), *(int32_t *)(puVar6 + -0x3dc)
                             , *(int32_t *)(puVar6 + -0x3c0), *(int32_t *)(puVar6 + -0x3c8), 
                             *(int32_t *)(puVar6 + -0x3c4), *(int32_t *)(puVar6 + -0x3d8), *(int32_t *)(puVar6 + -0x3bc)
                             , *(int32_t *)(puVar6 + -0x3ac), *(int32_t *)(puVar6 + -0x3cc), 
                             *(int32_t *)(puVar6 + -0x3b8), *(int32_t *)(puVar6 + -0x3d0), *(int32_t *)(puVar6 + -0x3b4)
                             , *(int32_t *)(puVar6 + -0x3d4), *(int32_t *)(puVar6 + -0x3b0));
        printf(*(undefined4 *)(puVar6 + 0xc28), *(int32_t *)(puVar6 + 0xc2c), *(int32_t *)(puVar6 + 0xc30), 
               *(int32_t *)(puVar6 + 0xc34), *(int32_t *)(puVar6 + -0x3e4), *(int32_t *)(puVar6 + -1000));
    }
    return uVar2;
}

// WARNING: Removing unreachable block (ram,0xbfc02c6c)
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01af4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01aac failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01984 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03efc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function printf failed, args may be inaccurate.
// WARNING: [r2ghidra] Failed to match type FILE * for variable arg_8h to Decompiler type: Unknown type identifier FILE

undefined4 fcn.bfc02b9c(int32_t arg2, int32_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int32_t in_a2;
    undefined *puVar4;
    undefined *puVar5;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    undefined auStack24 [12];
    
    printf2(4, in_a2, -0x5fe7f668);
    iVar1 = fcn.bfc01af4(*(int32_t *)arg1);
    puVar4 = auStack24;
    if (iVar1 != 0) {
        printf2(4, in_a2, -0x5fe7f630);
        iVar1 = fcn.bfc01aac(*(int32_t *)arg1);
        in_a2 = *(int32_t *)(iVar1 + 0x10);
        fcn.bfc02b48(in_a2, arg1, *(int32_t *)(iVar1 + 0xc));
        fcn.bfc01984(iVar1);
        fcn.bfc03efc(in_stack_0000000c, in_stack_00000010);
        puVar4 = &stack0xfffffffc;
    }
    iVar1 = fcn.bfc01af4(*(undefined4 *)(arg1 + 8), *puVar4);
    puVar5 = puVar4 + 4;
    if (iVar1 != 0) {
        printf2(4, in_a2, 0xa01809e4, puVar4[4]);
        uVar2 = fcn.bfc01aac(*(undefined4 *)(arg1 + 8), puVar4[8]);
        fcn.bfc01984(uVar2, puVar4[0xc]);
        fcn.bfc03efc(*(int32_t *)(puVar4 + 0x24), *(int32_t *)(puVar4 + 0x28));
        puVar5 = puVar4 + 0x14;
    }
    uVar3 = *(int32_t *)(arg1 + 0x28) + 1;
    *(uint32_t *)(arg1 + 0x28) = uVar3;
    if (uVar3 % 200 != 0) {
        return 0xa0180000;
    }
    *(undefined4 *)(puVar5 + 0x28) = *(undefined4 *)0xa0180da4;
    *(undefined4 *)(puVar5 + 0x18) = *(undefined4 *)(puVar5 + 0x14);
    *(undefined4 *)(puVar5 + 0x1c) = *(undefined4 *)(puVar5 + 0x1c);
    *(undefined4 *)(puVar5 + 0x2c) = *(undefined4 *)0xa0180da0;
    *(undefined **)(puVar5 + 0x10) = puVar5 + 0x28;
    uVar2 = 0;
    if ((*(uint32_t *)0xa0180050 & 4) != 0) {
        uVar2 = fcn.bfc05988(*(int32_t *)(puVar5 + -0x364), *(int32_t *)(puVar5 + -0x360), *(int32_t *)(puVar5 + -0x35c)
                             , *(int32_t *)(puVar5 + -0x3f4), *(int32_t *)(puVar5 + -0x3f0), 
                             *(int32_t *)(puVar5 + -0x3ec), *(int32_t *)(puVar5 + -1000), *(int32_t *)(puVar5 + -0x3e4)
                             , *(int32_t *)(puVar5 + -0x3c8), *(int32_t *)(puVar5 + -0x3d0), 
                             *(int32_t *)(puVar5 + -0x3cc), *(int32_t *)(puVar5 + -0x3e0), *(int32_t *)(puVar5 + -0x3c4)
                             , *(int32_t *)(puVar5 + -0x3b4), *(int32_t *)(puVar5 + -0x3d4), 
                             *(int32_t *)(puVar5 + -0x3c0), *(int32_t *)(puVar5 + -0x3d8), *(int32_t *)(puVar5 + -0x3bc)
                             , *(int32_t *)(puVar5 + -0x3dc), *(int32_t *)(puVar5 + -0x3b8));
        printf(*(undefined4 *)(puVar5 + 0xc20), *(int32_t *)(puVar5 + 0xc24), *(int32_t *)(puVar5 + 0xc28), 
               *(int32_t *)(puVar5 + 0xc2c), *(int32_t *)(puVar5 + -0x3ec), *(int32_t *)(puVar5 + -0x3f0));
    }
    return uVar2;
}
