
// WARNING: This function may have set the stack pointer
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00000 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc00000(void)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    undefined uVar3;
    int32_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int32_t iVar7;
    code *pcVar8;
    int32_t iVar9;
    undefined4 uVar10;
    
    iVar2 = 0;
    uVar3 = 0;
    iVar4 = 0;
    setCopReg(0, *(undefined4 *)0x2010, 0, 0);
    setCopReg(0, *(undefined4 *)0x2020, 0, 0);
    setCopReg(0, *(undefined4 *)0x2038, 0, 0);
    iVar6 = 0x40;
    iVar7 = 0;
    iVar9 = 0x700;
    do {
        iVar6 = iVar6 + -1;
        setCopReg(0, *(undefined4 *)0x2000, iVar6 * 0x100, 0);
        setCopReg(0, *(undefined4 *)0x2008, iVar9, 0);
        setCopReg(0, *(undefined4 *)0x2028, iVar7, 0);
        TLB_write_indexed_entry
                  (*(undefined4 *)0x2000, *(undefined4 *)0x2028, *(undefined4 *)0x2008, *(undefined4 *)0x200c, 
                   *(undefined4 *)0x2014);
        iVar7 = iVar7 + 0x1000;
        iVar9 = iVar9 + 0x1000;
    } while (iVar6 != 0);
    setCopReg(0, *(undefined4 *)0x2028, 0, 0);
    puVar5 = (undefined4 *)0xbfc08ef8;
    pcVar8 = gp;
    do {
        *(undefined4 *)pcVar8 = *puVar5;
        puVar5 = puVar5 + 1;
        pcVar8 = (code *)((int32_t)pcVar8 + 4);
    } while (puVar5 != (undefined4 *)0xbfc09c8c);
    uVar10 = 0xbfc00510;
    main(0, 0, 0, 0);
    trap(0);
    *(int32_t *)0xa00fffec = 0;
    *(undefined4 *)0xa00ffff0 = 0;
    *(undefined4 *)0xa00ffff8 = 0;
    *(undefined4 *)0xa00ffff4 = 0;
    *(int32_t *)0xa00fffe8 = 0;
    *(int32_t *)0xa00fffe4 = 0;
    *(undefined4 *)0xa00ffffc = uVar10;
    puVar1 = (undefined *)malloc(0);
    *puVar1 = uVar3;
    memcpy(*(int32_t *)0xa00fffe0, *(int32_t *)0xa00fffe4, *(int32_t *)0xa00fffe8);
    queue_node = (queue_node *)malloc2(*(int32_t *)0xa00fffec);
    init_queue_node(queue_node, puVar1, iVar4 + 1, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(iVar2 + 0x68), queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        *(undefined4 *)0xa0100010 = 0;
        *(undefined4 *)0xa010001c = 0x18;
        *(queue_node **)0xa0100018 = queue_node;
        fcn.bfc06d40(queue_node, 0x18, *(int32_t *)0xa0100000, "UL: MACRLL"._0_4_, "UL: MACRLL"._4_4_, 
                     *(int32_t *)0xa010000c, 0, 0x18);
        return;
    }
    return;
}

// WARNING: This function may have set the stack pointer
// WARNING: [r2ghidra] Matching calling convention n32 of function loc.bfc00400 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void loc.bfc00400(void)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    undefined uVar3;
    int32_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int32_t iVar7;
    code *pcVar8;
    int32_t iVar9;
    undefined4 uVar10;
    
    iVar2 = 0;
    uVar3 = 0;
    iVar4 = 0;
    setCopReg(0, *(undefined4 *)0x2010, 0, 0);
    setCopReg(0, *(undefined4 *)0x2020, 0, 0);
    setCopReg(0, *(undefined4 *)0x2038, 0, 0);
    iVar6 = 0x40;
    iVar7 = 0;
    iVar9 = 0x700;
    do {
        iVar6 = iVar6 + -1;
        setCopReg(0, *(undefined4 *)0x2000, iVar6 * 0x100, 0);
        setCopReg(0, *(undefined4 *)0x2008, iVar9, 0);
        setCopReg(0, *(undefined4 *)0x2028, iVar7, 0);
        TLB_write_indexed_entry
                  (*(undefined4 *)0x2000, *(undefined4 *)0x2028, *(undefined4 *)0x2008, *(undefined4 *)0x200c, 
                   *(undefined4 *)0x2014);
        iVar7 = iVar7 + 0x1000;
        iVar9 = iVar9 + 0x1000;
    } while (iVar6 != 0);
    setCopReg(0, *(undefined4 *)0x2028, 0, 0);
    puVar5 = (undefined4 *)0xbfc08ef8;
    pcVar8 = gp;
    do {
        *(undefined4 *)pcVar8 = *puVar5;
        puVar5 = puVar5 + 1;
        pcVar8 = (code *)((int32_t)pcVar8 + 4);
    } while (puVar5 != (undefined4 *)0xbfc09c8c);
    uVar10 = 0xbfc00510;
    main(0, 0, 0, 0);
    trap(0);
    *(int32_t *)0xa00fffec = 0;
    *(undefined4 *)0xa00ffff0 = 0;
    *(undefined4 *)0xa00ffff8 = 0;
    *(undefined4 *)0xa00ffff4 = 0;
    *(int32_t *)0xa00fffe8 = 0;
    *(int32_t *)0xa00fffe4 = 0;
    *(undefined4 *)0xa00ffffc = uVar10;
    puVar1 = (undefined *)malloc(0);
    *puVar1 = uVar3;
    memcpy(*(int32_t *)0xa00fffe0, *(int32_t *)0xa00fffe4, *(int32_t *)0xa00fffe8);
    queue_node = (queue_node *)malloc2(*(int32_t *)0xa00fffec);
    init_queue_node(queue_node, puVar1, iVar4 + 1, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(iVar2 + 0x68), queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        *(undefined4 *)0xa0100010 = 0;
        *(undefined4 *)0xa010001c = 0x18;
        *(queue_node **)0xa0100018 = queue_node;
        fcn.bfc06d40(queue_node, 0x18, *(int32_t *)0xa0100000, "UL: MACRLL"._0_4_, "UL: MACRLL"._4_4_, 
                     *(int32_t *)0xa010000c, 0, 0x18);
        return;
    }
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08ba8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dd4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function lock_input? failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function new_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_mac failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_rll failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_14h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_rrl failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08148 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0096c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function mac_layer failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function link_layer failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function resource_layer failed, args may be inaccurate.

void main(void)
{
    queue_struct **ppqVar1;
    int32_t in_stack_ffffecec;
    int32_t in_stack_ffffecf0;
    int32_t in_stack_ffffed00;
    int32_t in_stack_ffffed04;
    int32_t in_stack_ffffed08;
    int32_t in_stack_ffffed0c;
    int32_t in_stack_ffffed10;
    int32_t in_stack_ffffed14;
    undefined *puStack4840;
    queue_struct *pqStack4836;
    queue_struct *pqStack4832;
    undefined auStack712 [468];
    undefined auStack244 [124];
    undefined auStack120 [32];
    undefined auStack88 [32];
    undefined auStack56 [40];
    
    fcn.bfc08ba8(&stack0xffffed00);
    *(undefined **)0xa0180db0 = &stack0xffffed00;
    fcn.bfc08dd4(in_stack_ffffecec, in_stack_ffffecf0, in_stack_ffffed00, in_stack_ffffed04);
    lock_input?(0);
    // esilref: 'UL: MACRLL'
    new_queue((queue_struct *)(auStack56 + 0x20), (char *)0xa0180d3c, in_stack_ffffed00, in_stack_ffffed04);
    // esilref: 'UL: RLLRRL'
    new_queue((queue_struct *)(auStack56 + 0x10), (char *)0xa0180d48, in_stack_ffffed04, in_stack_ffffed08);
    // esilref: 'DL: RRLRLL'
    new_queue((queue_struct *)auStack56, (char *)0xa0180d54, in_stack_ffffed08, in_stack_ffffed0c);
    // esilref: 'DL: RLLMAC'
    new_queue((queue_struct *)(auStack88 + 0x10), (char *)0xa0180d60, in_stack_ffffed0c, in_stack_ffffed10);
    // esilref: 'GLOBAL'
    new_queue((queue_struct *)auStack88, (char *)0xa0180d6c, in_stack_ffffed10, in_stack_ffffed14);
    puStack4840 = *(undefined **)0xa0180db0;
    init_mac((mac_struct *)auStack712);
    pqStack4836 = (queue_struct *)auStack56;
    pqStack4832 = (queue_struct *)auStack88;
    init_rll((rll_struct *)auStack244);
    init_rrl(auStack120, &stack0xfffffff0, (queue_struct *)auStack56, (queue_struct *)auStack88);
    fcn.bfc08148(auStack712 + 0xc);
    fcn.bfc0096c(auStack244 + 0xc);
    ppqVar1 = &pqStack4836;
    do {
        mac_layer((undefined *)((int32_t)ppqVar1 + 0x1030), *(undefined *)ppqVar1);
        link_layer((undefined *)((int32_t)ppqVar1 + 0x1204), *(undefined *)((int32_t)ppqVar1 + 4));
        resource_layer((undefined *)((int32_t)ppqVar1 + 0x1280));
        ppqVar1 = (queue_struct **)((int32_t)ppqVar1 + 0xc);
    } while( true );
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08960 failed, args may be inaccurate.

void fcn.bfc08960(void)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    
    iVar1 = *(int32_t *)0xa0180db0;
    uVar3 = **(undefined4 **)0xa0180084;
    if (*(int32_t *)(*(int32_t *)0xa0180db0 + 0x1000) + 4U < 0x801) {
        iVar2 = *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1004);
        *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 0x18);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 0x10);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)((uint32_t)uVar3 >> 8);
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        iVar2 = *(int32_t *)(iVar1 + 0x1004);
        *(int32_t *)(iVar1 + 0x1004) = iVar2 + 1;
        *(char *)(iVar1 + iVar2) = (char)uVar3;
        iVar1 = *(int32_t *)0xa0180db0;
        if (0x7ff < *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1004)) {
            *(undefined4 *)(*(int32_t *)0xa0180db0 + 0x1004) = 0;
        }
        *(int32_t *)(iVar1 + 0x1000) = *(int32_t *)(iVar1 + 0x1000) + 4;
    }
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08a98 failed, args may be inaccurate.

void fcn.bfc08a98(void)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    
    iVar5 = *(int32_t *)0xa0180db0;
    if (*(uint32_t *)(*(int32_t *)0xa0180db0 + 0x100c) < 4) {
        **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 8;
        return;
    }
    iVar6 = *(int32_t *)(*(int32_t *)0xa0180db0 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(*(int32_t *)0xa0180db0 + 0x1014) = uVar7;
    uVar1 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar2 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar3 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    iVar6 = *(int32_t *)(iVar5 + 0x1014);
    uVar7 = iVar6 + 1;
    *(uint32_t *)(iVar5 + 0x1014) = uVar7;
    uVar4 = *(uint8_t *)(iVar5 + iVar6 + 0x800);
    if (0x7ff < uVar7) {
        *(undefined4 *)(iVar5 + 0x1014) = 0;
    }
    **(uint32_t **)0xa018008c =
         (uint32_t)uVar3 << 8 | (uint32_t)uVar4 | (uint32_t)uVar2 << 0x10 | (uint32_t)uVar1 << 0x18;
    *(int32_t *)(iVar5 + 0x100c) = *(int32_t *)(iVar5 + 0x100c) + -4;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dc4 failed, args may be inaccurate.

void fcn.bfc08dc4(void)
{
    *(undefined4 *)0xa101000c = 3;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc? failed, args may be inaccurate.

void malloc(int32_t arg_18h)
{
    int32_t in_a0;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    int32_t in_stack_0000001c;
    int32_t in_stack_fffffff4;
    
    malloc?(in_stack_fffffff4, unaff_s8, unaff_retaddr, in_a0, in_stack_00000004, in_stack_00000008, in_stack_0000000c, 
            in_stack_00000010, in_stack_0000001c);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc? failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06740 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.

uint32_t *
malloc?(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h, int32_t arg_24h,
       int32_t arg_28h, int32_t arg_2ch, int32_t arg_38h)
{
    uint32_t in_a0;
    int32_t *piVar1;
    uint32_t uStackX0;
    int32_t aiStack56 [4];
    uint32_t *puStack40;
    uint32_t *puStack36;
    uint32_t **ppuStack32;
    uint32_t *puStack28;
    uint32_t uStack24;
    uint32_t *puStack20;
    uint32_t *puStack16;
    uint32_t **ppuStack12;
    
    piVar1 = aiStack56;
    if (in_a0 < 8) {
        uStackX0 = 8;
    } else {
        uStackX0 = in_a0;
        if ((in_a0 & 3) != 0) {
            uStackX0 = ((in_a0 >> 2) + 1) * 4;
        }
    }
    puStack40 = *(uint32_t **)0xa0180d90;
    while( true ) {
        if (puStack40 == (uint32_t *)0x0) {
            puStack40 = (uint32_t *)fcn.bfc06740(*piVar1, piVar1[1], piVar1[2], piVar1[5]);
            piVar1 = piVar1 + 1;
        }
        puStack36 = puStack40;
        ppuStack32 = (uint32_t **)((int32_t)puStack40 + ((*puStack40 & 0xfffffffc) - 4));
        if (uStackX0 <= *puStack40) break;
        puStack40 = *ppuStack32;
    }
    puStack28 = puStack40 + 1;
    uStack24 = *puStack40 - uStackX0;
    *puStack40 = uStackX0;
    *puStack40 = *puStack40 | 1;
    if (uStack24 < 0xc) {
        if (puStack40 == *(uint32_t **)0xa0180d90) {
            *(uint32_t **)0xa0180d90 = *ppuStack32;
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(undefined4 *)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = 0;
            }
        } else {
            if (ppuStack32[1] != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)ppuStack32[1] + ((*ppuStack32[1] & 0xfffffffc) - 4)) = *ppuStack32;
            }
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = ppuStack32[1];
            }
        }
    } else {
        puStack20 = (uint32_t *)((int32_t)puStack40 + uStackX0 + 4);
        puStack16 = puStack20;
        *puStack20 = uStack24 - 4;
        ppuStack12 = ppuStack32;
        if (ppuStack32 != (uint32_t **)((int32_t)puStack20 + ((*puStack20 & 0xfffffffc) - 4))) {
    // esilref: 'Footer != in malloc'
            fcn.bfc065f8(piVar1[3], piVar1[4], piVar1[0x407], piVar1[0x408], piVar1[0x409], piVar1[0x40a]);
            return (uint32_t *)0x0;
        }
        if (puStack40 == *(uint32_t **)0xa0180d90) {
            *(uint32_t **)0xa0180d90 = puStack20;
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = puStack20;
            }
        } else {
            if (ppuStack32[1] != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)ppuStack32[1] + ((*ppuStack32[1] & 0xfffffffc) - 4)) = puStack20;
            }
            if (*ppuStack32 != (uint32_t *)0x0) {
                *(uint32_t **)((int32_t)*ppuStack32 + (**ppuStack32 & 0xfffffffc)) = puStack20;
            }
        }
        *puStack40 = *puStack40 | 2;
    }
    fcn.bfc079a8(*piVar1, piVar1[3], piVar1[4], piVar1[5]);
    return puStack40 + 1;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.

int32_t memcpy(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h)
{
    int32_t in_a0;
    int32_t in_a1;
    uint32_t in_a2;
    uint32_t uStack16;
    int32_t arg_0h;
    
    uStack16 = 0;
    while (uStack16 < in_a2) {
        *(undefined *)(in_a0 + uStack16) = *(undefined *)(in_a1 + uStack16);
        uStack16 = uStack16 + 1;
    }
    return in_a0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc? failed, args may be inaccurate.

void malloc2(int32_t arg_18h)
{
    int32_t in_a0;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    int32_t in_stack_0000001c;
    int32_t in_stack_fffffff4;
    
    malloc?(in_stack_fffffff4, unaff_s8, unaff_retaddr, in_a0, in_stack_00000004, in_stack_00000008, in_stack_0000000c, 
            in_stack_00000010, in_stack_0000001c);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes2 failed, args may be inaccurate.

void init_queue_node(int32_t param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    zero_12bytes2();
    *(undefined4 *)(param_1 + 0xc) = param_2;
    *(undefined4 *)(param_1 + 0x10) = param_3;
    *(undefined4 *)(param_1 + 0x14) = param_4;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes2 failed, args may be inaccurate.

void zero_12bytes2(undefined4 *param_1)
{
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

int32_t add_to_queue(int32_t param_1, int32_t param_2)
{
    int32_t iVar1;
    
    if (param_2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(param_1 + 0x10) < 0x20) && (iVar1 = add_data_block_to_linked_list(), iVar1 != 0)) {
        *(int32_t *)(param_1 + 0x10) = *(int32_t *)(param_1 + 0x10) + 1;
    } else {
        iVar1 = 0;
    }
    return iVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

undefined4 add_data_block_to_linked_list(int32_t *param_1, undefined4 *param_2)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    
    uVar1 = 0;
    if ((param_2 != (undefined4 *)0x0) && (param_2[2] == 0)) {
        if (param_1[1] == 0) {
            param_2[1] = 0;
            *param_2 = 0;
            param_1[2] = (int32_t)param_2;
            param_1[1] = (int32_t)param_2;
        } else {
            puVar3 = (undefined4 *)param_1[2];
            *param_2 = 0;
            param_2[1] = puVar3;
            *puVar3 = param_2;
            param_1[2] = (int32_t)param_2;
        }
        iVar2 = *param_1;
        param_2[2] = param_1;
        *param_1 = iVar2 + 1;
        uVar1 = 1;
    }
    // return list length
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.

undefined4 destruct_queue_node(queue_node *queue_node)
{
    undefined4 uVar1;
    uint32_t *puVar2;
    int32_t iVar3;
    int32_t *piVar4;
    uint32_t uVar5;
    
    // a0: new struct
    if ((queue_node->data_chunk != (queue_data_chunk *)0x0) && ((code *)queue_node->destructor_fcn != (code *)0x0)) {
        (*(code *)queue_node->destructor_fcn)();
    }
    if ((int32_t *)queue_node->curr_queue != (int32_t *)0x0) {
        uVar1 = 0;
        if ((queue_node != (queue_node *)0x0) &&
           (piVar4 = (int32_t *)queue_node->curr_queue, piVar4 == (int32_t *)queue_node->curr_queue)) {
            uVar5 = queue_node->next;
            if (uVar5 != 0) {
                *(uint32_t *)(uVar5 + 4) = queue_node->prev;
            }
            puVar2 = (uint32_t *)queue_node->prev;
            if (puVar2 != (uint32_t *)0x0) {
                *puVar2 = uVar5;
            }
            if (queue_node == (queue_node *)piVar4[2]) {
                piVar4[2] = (int32_t)puVar2;
            }
            if (queue_node == (queue_node *)piVar4[1]) {
                piVar4[1] = queue_node->next;
            }
            iVar3 = *piVar4;
            queue_node->curr_queue = 0;
            *piVar4 = iVar3 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function u16 failed, args may be inaccurate.

undefined2 u16(undefined2 *param_1)
{
    return *param_1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.

int32_t fcn.bfc07cd8(int32_t arg_8h)
{
    int32_t in_a0;
    
    if (in_a0 < 0) {
        in_a0 = -in_a0;
    }
    return in_a0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.

undefined4 debug_print(void)
{
    undefined4 uVar1;
    int32_t in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    
    uVar1 = fcn.bfc05988(in_stack_fffffbec, in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                         in_stack_fffffc00, in_stack_fffffc04, in_stack_fffffc08, in_stack_fffffc0c, in_stack_fffffc10, 
                         in_stack_fffffc14, in_stack_fffffc18, in_stack_fffffc1c, in_stack_fffffc20, in_stack_fffffc24, 
                         in_stack_fffffc28, in_stack_fffffc2c, in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84);
    // esilref: 'DEBUG::&s
    // '
    fcn.bfc065f8(in_stack_fffffbf0, in_stack_fffffbf4, in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, 
                 in_stack_00000c0c);
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07284 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07a34 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

int32_t fcn.bfc05988(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h,
                    int32_t arg_24h, int32_t arg_28h, int32_t arg_2ch, int32_t arg_30h, int32_t arg_34h, int32_t arg_38h
                    , int32_t arg_3ch, int32_t arg_40h, int32_t arg_44h, int32_t arg_48h, int32_t arg_4ch,
                    int32_t arg_50h, int32_t arg_a0h, int32_t arg_a4h, int32_t arg_a8h)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t in_a0;
    char *in_a1;
    char **in_a2;
    undefined *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    int32_t *piVar9;
    int32_t *piVar10;
    char *pcStackX4;
    char **ppcStackX8;
    undefined auStack160 [16];
    int32_t aiStack144 [4];
    uint32_t uStack128;
    int32_t iStack124;
    char *pcStack120;
    char *pcStack116;
    char *pcStack112;
    char *pcStack108;
    uint32_t uStack104;
    undefined4 uStack100;
    char *pcStack96;
    char *pcStack92;
    char *pcStack88;
    undefined uStack84;
    char acStack80 [68];
    
    piVar10 = (int32_t *)auStack160;
    aiStack144[0] = 0;
    pcStackX4 = in_a1;
    ppcStackX8 = in_a2;
    if (in_a1 == (char *)0x0) {
        aiStack144[0] = -1;
    } else {
        while (*pcStackX4 != '\0') {
            if (*pcStackX4 == '%') {
                pcVar2 = pcStackX4 + 1;
                aiStack144[1] = 0;
                aiStack144[2] = 0;
                aiStack144[3] = 0;
                uStack128 = 0;
                uStack100 = 0;
                if (*pcVar2 == '%') {
                    *(undefined *)(in_a0 + aiStack144[0]) = 0x25;
                    pcStackX4 = pcStackX4 + 2;
                    aiStack144[0] = aiStack144[0] + 1;
                } else {
                    pcVar1 = pcVar2;
                    if (*pcVar2 == '-') {
                        uStack128 = 1;
                        pcVar1 = pcStackX4 + 2;
                    }
                    pcStackX4 = pcVar1;
                    uStack128 = (uint32_t)(*pcVar2 == '-');
                    iVar3 = fcn.bfc07284(*(int32_t *)((int32_t)piVar10 + 4));
                    puVar6 = (undefined *)((int32_t)piVar10 + 4);
                    if (iVar3 != 0) {
                        if (*pcStackX4 == '0') {
                            aiStack144[3] = 1;
                            pcStackX4 = pcStackX4 + 1;
                        }
                        iVar3 = fcn.bfc07284(*(int32_t *)((int32_t)piVar10 + 8));
                        puVar6 = (undefined *)((int32_t)piVar10 + 8);
                        if (iVar3 != 0) {
                            aiStack144[1] =
                                 fcn.bfc07a34(*(int32_t *)((int32_t)piVar10 + 0x14), 
                                              *(int32_t *)((int32_t)piVar10 + 0x18), 
                                              *(int32_t *)((int32_t)piVar10 + 0x1c), 
                                              *(int32_t *)((int32_t)piVar10 + 0x20), 
                                              *(int32_t *)((int32_t)piVar10 + 0x2c));
                            puVar7 = (undefined *)((int32_t)piVar10 + 0xc);
                            while( true ) {
                                iVar3 = fcn.bfc07284(*(int32_t *)(puVar7 + 4));
                                puVar6 = puVar7 + 4;
                                puVar7 = puVar7 + 4;
                                if (iVar3 == 0) break;
                                pcStackX4 = pcStackX4 + 1;
                            }
                        }
                    }
                    piVar10 = (int32_t *)puVar6;
                    if (*pcStackX4 == '.') {
                        aiStack144[2] =
                             fcn.bfc07a34(*(int32_t *)(puVar6 + 0xc), *(int32_t *)(puVar6 + 0x10), 
                                          *(int32_t *)(puVar6 + 0x14), *(int32_t *)(puVar6 + 0x18), 
                                          *(int32_t *)(puVar6 + 0x24));
                        puVar8 = puVar6 + 4;
                        do {
                            pcStackX4 = pcStackX4 + 1;
                            iVar3 = fcn.bfc07284(*(int32_t *)(puVar8 + 4));
                            piVar10 = (int32_t *)(puVar8 + 4);
                            puVar8 = puVar8 + 4;
                        } while (iVar3 != 0);
                    }
                    if (*pcStackX4 == 'c') {
                        pcVar2 = *ppcStackX8;
                        uStack84 = (char)pcVar2;
                        if (uStack128 == 0) {
                            iStack124 = 0;
                            while (iStack124 < aiStack144[1] + -1) {
                                if (aiStack144[3] == 0) {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                } else {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                }
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        *(char *)(in_a0 + aiStack144[0]) = (char)pcVar2;
                        aiStack144[0] = aiStack144[0] + 1;
                        if (uStack128 != 0) {
                            iStack124 = 0;
                            while (iStack124 < aiStack144[1] + -1) {
                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        pcStackX4 = pcStackX4 + 1;
                        ppcStackX8 = ppcStackX8 + 1;
                    } else {
                        if (*pcStackX4 == 'u') {
                            pcStack88 = *ppcStackX8;
                            fcn.bfc049ec(*piVar10, piVar10[1], piVar10[0xb], piVar10[0xc]);
                            iVar3 = aiStack144[1];
                            iVar4 = strlen(piVar10[4]);
                            piVar10 = piVar10 + 2;
                            if (uStack128 == 0) {
                                iStack124 = 0;
                                while (iStack124 < iVar3 - iVar4) {
                                    if (aiStack144[3] == 0) {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                    } else {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                    }
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStack120 = acStack80;
                            while (*pcStack120 != '\0') {
                                *(char *)(in_a0 + aiStack144[0]) = *pcStack120;
                                aiStack144[0] = aiStack144[0] + 1;
                                pcStack120 = pcStack120 + 1;
                            }
                            if (uStack128 != 0) {
                                iStack124 = 0;
                                while (iStack124 < iVar3 - iVar4) {
                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStackX4 = pcStackX4 + 1;
                            ppcStackX8 = ppcStackX8 + 1;
                        } else {
                            if (*pcStackX4 == 'd') {
                                pcStack92 = *ppcStackX8;
                                fcn.bfc04b30(*piVar10, piVar10[1], piVar10[0xb], piVar10[0xc]);
                                iVar3 = aiStack144[1];
                                iVar4 = strlen(piVar10[4]);
                                piVar10 = piVar10 + 2;
                                if (uStack128 == 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iVar3 - iVar4) {
                                        if (aiStack144[3] == 0) {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                        } else {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                        }
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStack116 = acStack80;
                                while (*pcStack116 != '\0') {
                                    *(char *)(in_a0 + aiStack144[0]) = *pcStack116;
                                    aiStack144[0] = aiStack144[0] + 1;
                                    pcStack116 = pcStack116 + 1;
                                }
                                if (uStack128 != 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iVar3 - iVar4) {
                                        *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStackX4 = pcStackX4 + 1;
                                ppcStackX8 = ppcStackX8 + 1;
                            } else {
                                if (*pcStackX4 == 'x') {
                                    pcStack96 = *ppcStackX8;
                                    fcn.bfc04cb0(*piVar10, piVar10[1], piVar10[0xb], piVar10[0xc]);
                                    iVar3 = aiStack144[1];
                                    iVar4 = strlen(piVar10[4]);
                                    piVar10 = piVar10 + 2;
                                    if (uStack128 == 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iVar3 - iVar4) {
                                            if (aiStack144[3] == 0) {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                            } else {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                            }
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStack112 = acStack80;
                                    while (*pcStack112 != '\0') {
                                        *(char *)(in_a0 + aiStack144[0]) = *pcStack112;
                                        aiStack144[0] = aiStack144[0] + 1;
                                        pcStack112 = pcStack112 + 1;
                                    }
                                    if (uStack128 != 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iVar3 - iVar4) {
                                            *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStackX4 = pcStackX4 + 1;
                                    ppcStackX8 = ppcStackX8 + 1;
                                } else {
                                    if (*pcStackX4 == 's') {
                                        pcStack108 = *ppcStackX8;
                                        piVar9 = piVar10;
                                        if (aiStack144[2] < 1) {
code_r0xbfc063a0:
                                            uStack104 = strlen(*(int32_t *)((int32_t)piVar9 + 0xc));
                                            piVar10 = (int32_t *)((int32_t)piVar9 + 4);
                                        } else {
                                            uVar5 = strlen(piVar10[3]);
                                            piVar9 = piVar10 + 1;
                                            piVar10 = piVar10 + 1;
                                            if (uVar5 <= (uint32_t)aiStack144[2]) goto code_r0xbfc063a0;
                                            uStack104 = aiStack144[2];
                                        }
                                        aiStack144[1] = aiStack144[1] - uStack104;
                                        if (uStack128 == 0) {
                                            iStack124 = 0;
                                            while (iStack124 < aiStack144[1]) {
                                                if (aiStack144[3] == 0) {
                                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                                } else {
                                                    *(undefined *)(in_a0 + aiStack144[0]) = 0x30;
                                                }
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        while ((*pcStack108 != '\0' && (0 < (int32_t)uStack104))) {
                                            *(char *)(in_a0 + aiStack144[0]) = *pcStack108;
                                            aiStack144[0] = aiStack144[0] + 1;
                                            pcStack108 = pcStack108 + 1;
                                            uStack104 = uStack104 - 1;
                                        }
                                        if (uStack128 != 0) {
                                            iStack124 = 0;
                                            while (iStack124 < aiStack144[1]) {
                                                *(undefined *)(in_a0 + aiStack144[0]) = 0x20;
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        pcStackX4 = pcStackX4 + 1;
                                        ppcStackX8 = ppcStackX8 + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                *(char *)(in_a0 + aiStack144[0]) = *pcStackX4;
                pcStackX4 = pcStackX4 + 1;
                aiStack144[0] = aiStack144[0] + 1;
            }
        }
        *(undefined *)(in_a0 + aiStack144[0]) = 0;
    }
    return aiStack144[0];
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04e20 failed, args may be inaccurate.

undefined4
fcn.bfc065f8(int32_t arg_10h, int32_t arg_14h, int32_t arg_1020h, int32_t arg_1024h, int32_t arg_1028h,
            int32_t arg_102ch)
{
    undefined4 uVar1;
    undefined auStackX4 [8];
    int32_t in_stack_ffffefec;
    int32_t in_stack_ffffeff0;
    int32_t in_stack_ffffeff8;
    int32_t in_stack_ffffeffc;
    int32_t in_stack_fffff000;
    int32_t in_stack_fffff004;
    int32_t in_stack_fffff008;
    int32_t in_stack_fffff00c;
    int32_t in_stack_fffff010;
    int32_t in_stack_fffff014;
    int32_t in_stack_fffff018;
    int32_t in_stack_fffff01c;
    int32_t in_stack_fffff020;
    int32_t in_stack_fffff024;
    int32_t in_stack_fffff028;
    int32_t in_stack_fffff02c;
    int32_t in_stack_fffff07c;
    int32_t in_stack_fffff080;
    
    uVar1 = fcn.bfc04e20(in_stack_ffffefec, in_stack_ffffeff0, (int32_t)auStackX4, in_stack_ffffeff8, in_stack_ffffeffc
                         , in_stack_fffff000, in_stack_fffff004, in_stack_fffff008, in_stack_fffff00c, in_stack_fffff010
                         , in_stack_fffff014, in_stack_fffff018, in_stack_fffff01c, in_stack_fffff020, in_stack_fffff024
                         , in_stack_fffff028, in_stack_fffff02c, in_stack_fffff07c, in_stack_fffff080);
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04e20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04990 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07284 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07a34 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

int32_t fcn.bfc04e20(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h,
                    int32_t arg_24h, int32_t arg_28h, int32_t arg_2ch, int32_t arg_30h, int32_t arg_34h, int32_t arg_38h
                    , int32_t arg_3ch, int32_t arg_40h, int32_t arg_44h, int32_t arg_48h, int32_t arg_4ch,
                    int32_t arg_50h, int32_t arg_a0h, int32_t arg_a4h)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    char *in_a0;
    char **in_a1;
    undefined *puVar6;
    undefined *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    int32_t *piVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    int32_t *piVar13;
    int32_t *piVar14;
    char *pcStackX0;
    char **ppcStackX4;
    undefined auStack160 [16];
    int32_t aiStack144 [4];
    uint32_t uStack128;
    int32_t iStack124;
    char *pcStack120;
    char *pcStack116;
    char *pcStack112;
    char *pcStack108;
    uint32_t uStack104;
    int32_t iStack100;
    char *pcStack96;
    char *pcStack92;
    char *pcStack88;
    undefined uStack84;
    char acStack80 [68];
    
    piVar14 = (int32_t *)auStack160;
    aiStack144[0] = 0;
    pcStackX0 = in_a0;
    ppcStackX4 = in_a1;
    if (in_a0 == (char *)0x0) {
        aiStack144[0] = -1;
    } else {
        while (*pcStackX0 != '\0') {
            if (*pcStackX0 == '%') {
                pcVar2 = pcStackX0 + 1;
                aiStack144[1] = 0;
                aiStack144[2] = 0;
                aiStack144[3] = 0;
                uStack128 = 0;
                iStack100 = 0;
                if (*pcVar2 == '%') {
                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                    pcStackX0 = pcStackX0 + 2;
                    aiStack144[0] = aiStack144[0] + 1;
                } else {
                    pcVar1 = pcVar2;
                    if (*pcVar2 == '-') {
                        uStack128 = 1;
                        pcVar1 = pcStackX0 + 2;
                    }
                    pcStackX0 = pcVar1;
                    uStack128 = (uint32_t)(*pcVar2 == '-');
                    iVar3 = fcn.bfc07284(*(int32_t *)((int32_t)piVar14 + 4));
                    puVar6 = (undefined *)((int32_t)piVar14 + 4);
                    if (iVar3 != 0) {
                        if (*pcStackX0 == '0') {
                            aiStack144[3] = 1;
                            pcStackX0 = pcStackX0 + 1;
                        }
                        iVar3 = fcn.bfc07284(*(int32_t *)((int32_t)piVar14 + 8));
                        puVar6 = (undefined *)((int32_t)piVar14 + 8);
                        if (iVar3 != 0) {
                            aiStack144[1] =
                                 fcn.bfc07a34(*(int32_t *)((int32_t)piVar14 + 0x14), 
                                              *(int32_t *)((int32_t)piVar14 + 0x18), 
                                              *(int32_t *)((int32_t)piVar14 + 0x1c), 
                                              *(int32_t *)((int32_t)piVar14 + 0x20), 
                                              *(int32_t *)((int32_t)piVar14 + 0x2c));
                            puVar7 = (undefined *)((int32_t)piVar14 + 0xc);
                            while( true ) {
                                iVar3 = fcn.bfc07284(*(int32_t *)(puVar7 + 4));
                                puVar6 = puVar7 + 4;
                                puVar7 = puVar7 + 4;
                                if (iVar3 == 0) break;
                                pcStackX0 = pcStackX0 + 1;
                            }
                        }
                    }
                    piVar14 = (int32_t *)puVar6;
                    if (*pcStackX0 == '.') {
                        aiStack144[2] =
                             fcn.bfc07a34(*(int32_t *)(puVar6 + 0xc), *(int32_t *)(puVar6 + 0x10), 
                                          *(int32_t *)(puVar6 + 0x14), *(int32_t *)(puVar6 + 0x18), 
                                          *(int32_t *)(puVar6 + 0x24));
                        puVar8 = puVar6 + 4;
                        do {
                            pcStackX0 = pcStackX0 + 1;
                            iVar3 = fcn.bfc07284(*(int32_t *)(puVar8 + 4));
                            piVar14 = (int32_t *)(puVar8 + 4);
                            puVar8 = puVar8 + 4;
                        } while (iVar3 != 0);
                    }
                    if (*pcStackX0 == 'c') {
                        uStack84 = (char)*ppcStackX4;
                        iStack100 = aiStack144[1] + -1;
                        if (uStack128 == 0) {
                            iStack124 = 0;
                            while (iStack124 < iStack100) {
                                if (aiStack144[3] == 0) {
                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                } else {
                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                }
                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                        puVar9 = (undefined *)((int32_t)piVar14 + 4);
                        aiStack144[0] = aiStack144[0] + 1;
                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                        if (uStack128 != 0) {
                            iStack124 = 0;
                            while (piVar14 = (int32_t *)puVar9, iStack124 < iStack100) {
                                fcn.bfc04990(*(int32_t *)(puVar9 + 4));
                                puVar9 = puVar9 + 4;
                                aiStack144[0] = aiStack144[0] + 1;
                                iStack124 = iStack124 + 1;
                            }
                        }
                        pcStackX0 = pcStackX0 + 1;
                        ppcStackX4 = ppcStackX4 + 1;
                    } else {
                        if (*pcStackX0 == 'u') {
                            pcStack88 = *ppcStackX4;
                            fcn.bfc049ec(*piVar14, piVar14[1], piVar14[0xb], piVar14[0xc]);
                            iVar3 = aiStack144[1];
                            iVar4 = strlen(piVar14[4]);
                            piVar10 = piVar14 + 2;
                            iStack100 = iVar3 - iVar4;
                            piVar14 = piVar14 + 2;
                            if (uStack128 == 0) {
                                iStack124 = 0;
                                while (piVar14 = piVar10, iStack124 < iStack100) {
                                    if (aiStack144[3] == 0) {
                                        fcn.bfc04990(*(int32_t *)((int32_t)piVar10 + 4));
                                    } else {
                                        fcn.bfc04990(*(int32_t *)((int32_t)piVar10 + 4));
                                    }
                                    piVar10 = (int32_t *)((int32_t)piVar10 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStack120 = acStack80;
                            while (*pcStack120 != '\0') {
                                fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                aiStack144[0] = aiStack144[0] + 1;
                                pcStack120 = pcStack120 + 1;
                            }
                            if (uStack128 != 0) {
                                iStack124 = 0;
                                while (iStack124 < iStack100) {
                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    iStack124 = iStack124 + 1;
                                }
                            }
                            pcStackX0 = pcStackX0 + 1;
                            ppcStackX4 = ppcStackX4 + 1;
                        } else {
                            if (*pcStackX0 == 'd') {
                                pcStack92 = *ppcStackX4;
                                fcn.bfc04b30(*piVar14, piVar14[1], piVar14[0xb], piVar14[0xc]);
                                iVar3 = aiStack144[1];
                                iVar4 = strlen(piVar14[4]);
                                piVar11 = piVar14 + 2;
                                iStack100 = iVar3 - iVar4;
                                piVar14 = piVar14 + 2;
                                if (uStack128 == 0) {
                                    iStack124 = 0;
                                    while (piVar14 = piVar11, iStack124 < iStack100) {
                                        if (aiStack144[3] == 0) {
                                            fcn.bfc04990(*(int32_t *)((int32_t)piVar11 + 4));
                                        } else {
                                            fcn.bfc04990(*(int32_t *)((int32_t)piVar11 + 4));
                                        }
                                        piVar11 = (int32_t *)((int32_t)piVar11 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStack116 = acStack80;
                                while (*pcStack116 != '\0') {
                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                    piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                    aiStack144[0] = aiStack144[0] + 1;
                                    pcStack116 = pcStack116 + 1;
                                }
                                if (uStack128 != 0) {
                                    iStack124 = 0;
                                    while (iStack124 < iStack100) {
                                        fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        iStack124 = iStack124 + 1;
                                    }
                                }
                                pcStackX0 = pcStackX0 + 1;
                                ppcStackX4 = ppcStackX4 + 1;
                            } else {
                                if (*pcStackX0 == 'x') {
                                    pcStack96 = *ppcStackX4;
                                    fcn.bfc04cb0(*piVar14, piVar14[1], piVar14[0xb], piVar14[0xc]);
                                    iVar3 = aiStack144[1];
                                    iVar4 = strlen(piVar14[4]);
                                    piVar12 = piVar14 + 2;
                                    iStack100 = iVar3 - iVar4;
                                    piVar14 = piVar14 + 2;
                                    if (uStack128 == 0) {
                                        iStack124 = 0;
                                        while (piVar14 = piVar12, iStack124 < iStack100) {
                                            if (aiStack144[3] == 0) {
                                                fcn.bfc04990(*(int32_t *)((int32_t)piVar12 + 4));
                                            } else {
                                                fcn.bfc04990(*(int32_t *)((int32_t)piVar12 + 4));
                                            }
                                            piVar12 = (int32_t *)((int32_t)piVar12 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStack112 = acStack80;
                                    while (*pcStack112 != '\0') {
                                        fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                        piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                        aiStack144[0] = aiStack144[0] + 1;
                                        pcStack112 = pcStack112 + 1;
                                    }
                                    if (uStack128 != 0) {
                                        iStack124 = 0;
                                        while (iStack124 < iStack100) {
                                            fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                            piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            iStack124 = iStack124 + 1;
                                        }
                                    }
                                    pcStackX0 = pcStackX0 + 1;
                                    ppcStackX4 = ppcStackX4 + 1;
                                } else {
                                    if (*pcStackX0 == 's') {
                                        pcStack108 = *ppcStackX4;
                                        piVar13 = piVar14;
                                        if (aiStack144[2] < 1) {
code_r0xbfc05778:
                                            uStack104 = strlen(*(int32_t *)((int32_t)piVar13 + 0xc));
                                            piVar14 = (int32_t *)((int32_t)piVar13 + 4);
                                        } else {
                                            uVar5 = strlen(piVar14[3]);
                                            piVar13 = piVar14 + 1;
                                            piVar14 = piVar14 + 1;
                                            if (uVar5 <= (uint32_t)aiStack144[2]) goto code_r0xbfc05778;
                                            uStack104 = aiStack144[2];
                                        }
                                        iStack100 = aiStack144[1] - uStack104;
                                        if (uStack128 == 0) {
                                            iStack124 = 0;
                                            while (iStack124 < iStack100) {
                                                if (aiStack144[3] == 0) {
                                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                                } else {
                                                    fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                                }
                                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        while ((*pcStack108 != '\0' && (0 < (int32_t)uStack104))) {
                                            fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                            piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                            aiStack144[0] = aiStack144[0] + 1;
                                            pcStack108 = pcStack108 + 1;
                                            uStack104 = uStack104 - 1;
                                        }
                                        if (uStack128 != 0) {
                                            iStack124 = 0;
                                            while (iStack124 < iStack100) {
                                                fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                                                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                                                aiStack144[0] = aiStack144[0] + 1;
                                                iStack124 = iStack124 + 1;
                                            }
                                        }
                                        pcStackX0 = pcStackX0 + 1;
                                        ppcStackX4 = ppcStackX4 + 1;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                fcn.bfc04990(*(int32_t *)((int32_t)piVar14 + 4));
                piVar14 = (int32_t *)((int32_t)piVar14 + 4);
                pcStackX0 = pcStackX0 + 1;
                aiStack144[0] = aiStack144[0] + 1;
            }
        }
    }
    return aiStack144[0];
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

undefined4 * fcn.bfc07d50(int32_t param_1, undefined4 *param_2)
{
    if (param_2 != (undefined4 *)0x0) {
        if (param_2[2] != param_1) {
            return (undefined4 *)0x0;
        }
        param_2 = (undefined4 *)*param_2;
    }
    return param_2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc042dc failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc040f4 failed, args may be inaccurate.

int32_t fcn.bfc042dc(int32_t param_1, int32_t param_2, int32_t param_3, int32_t param_4, undefined param_5)
{
    int32_t iVar1;
    
    if (param_4 != 0) {
        iVar1 = fcn.bfc040f4(*(undefined4 *)(param_1 + 0xc), param_3, param_4, param_5);
        if (iVar1 != 0) {
            *(int32_t *)(param_1 + (param_3 + 4) * 4) = iVar1;
            if (param_2 != 0) {
                *(undefined *)(param_1 + 0x53) = 1;
                *(char *)(param_1 + 0x52) = (char)param_3;
                return param_2;
            }
            return 1;
        }
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04364 failed, args may be inaccurate.

char fcn.bfc04364(int32_t param_1)
{
    char cVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    
    cVar1 = *(char *)(param_1 + 0x53);
    uVar2 = 0;
    if (cVar1 != '\0') {
        uVar3 = 0;
        do {
            if (*(int32_t *)(param_1 + (uVar2 + 4) * 4) != 0) {
                uVar3 = uVar3 + 1 & 0xff;
            }
            uVar2 = uVar2 + 1 & 0xff;
        } while (uVar2 <= *(uint8_t *)(param_1 + 0x52));
        cVar1 = *(uint8_t *)(param_1 + 0x52) + 1 == uVar3;
    }
    return cVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04414 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc043c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.

undefined4 fcn.bfc04414(int32_t param_1, undefined4 param_2, uint32_t param_3, int16_t *param_4)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t *piVar3;
    int16_t iVar4;
    undefined *puVar5;
    undefined auStack36 [12];
    
    uVar1 = fcn.bfc043c0();
    puVar5 = auStack36;
    uVar2 = 0;
    if (uVar1 <= param_3) {
        piVar3 = (int32_t *)(param_1 + 0x10);
        iVar4 = 0;
        do {
            if (*piVar3 != 0) {
                memcpy(*(int32_t *)(puVar5 + 0xc), *(int32_t *)(puVar5 + 0x10), *(int32_t *)(puVar5 + 0x14));
                puVar5 = puVar5 + 4;
                iVar4 = iVar4 + (uint16_t)*(uint8_t *)(*piVar3 + 4);
            }
            piVar3 = piVar3 + 1;
            uVar2 = 1;
        } while (piVar3 != (int32_t *)(param_1 + 0x50));
        *param_4 = iVar4;
    }
    return uVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void free(queue_node *queue_node, uint32_t len, int32_t arg_18h, int32_t arg_1ch)
{
    int32_t unaff_s8;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    int32_t in_stack_fffffff4;
    
    fcn.bfc06d40(queue_node, len, in_stack_ffffffe8, in_stack_ffffffec, in_stack_fffffff0, in_stack_fffffff4, unaff_s8, 
                 len);
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc06d40(queue_node *queue_node, uint32_t len, int32_t arg_4h, int32_t arg_8h, int32_t arg_ch, int32_t arg_10h,
                 int32_t arg_14h, int32_t arg_20h)
{
    void **ppvVar1;
    void **ppvVar2;
    void **ppvVar3;
    int32_t iVar4;
    uint32_t **ppuVar5;
    int32_t arg_0h;
    
    ppvVar2 = &queue_node[-1].destructor_fcn;
    ppvVar1 = *(void ***)0xa0180d90;
    if (((uint32_t)*ppvVar2 & 1) != 0) {
        ppvVar1 = ppvVar2;
        if ((((uint32_t)*ppvVar2 & 2) == 0) ||
           (ppvVar3 = (void **)((int32_t)&queue_node->next + ((uint32_t)*ppvVar2 & 0xfffffffc)),
           ((uint32_t)*ppvVar3 & 1) != 0)) {
            *ppvVar2 = (void *)((uint32_t)*ppvVar2 & 0xfffffffe);
            ppuVar5 = (uint32_t **)((int32_t)ppvVar2 + (((uint32_t)*ppvVar2 & 0xfffffffc) - 4));
            *ppuVar5 = (uint32_t *)*(void ***)0xa0180d90;
            ppuVar5[1] = (uint32_t *)0x0;
            if (*(void ***)0xa0180d90 != (void **)0x0) {
                *(void ***)((int32_t)*(void ***)0xa0180d90 + ((uint32_t)**(void ***)0xa0180d90 & 0xfffffffc)) = ppvVar2;
            }
        } else {
            iVar4 = ((uint32_t)*ppvVar2 & 0xfffffffc) + ((uint32_t)*ppvVar3 & 0xfffffffc);
            *ppvVar2 = (void *)(iVar4 + 4);
            if (((uint32_t)*ppvVar3 & 2) != 0) {
                *ppvVar2 = (void *)((uint32_t)*ppvVar2 | 2);
            }
            if (ppvVar3 == *(void ***)0xa0180d90) {
                ppuVar5 = (uint32_t **)((int32_t)ppvVar2 + iVar4);
                if (*ppuVar5 != (uint32_t *)0x0) {
                    *(void ***)0xa0180d90 = ppvVar2;
                    *(void ***)((int32_t)*ppuVar5 + (**ppuVar5 & 0xfffffffc)) = ppvVar2;
                    ppvVar1 = *(void ***)0xa0180d90;
                }
            } else {
                ppuVar5 = (uint32_t **)((int32_t)ppvVar2 + iVar4);
                if (ppuVar5[1] != (uint32_t *)0x0) {
                    *(void ***)((int32_t)ppuVar5[1] + ((*ppuVar5[1] & 0xfffffffc) - 4)) = ppvVar2;
                }
                ppvVar1 = *(void ***)0xa0180d90;
                if (*ppuVar5 != (uint32_t *)0x0) {
                    *(void ***)((int32_t)*ppuVar5 + (**ppuVar5 & 0xfffffffc)) = ppvVar2;
                    ppvVar1 = *(void ***)0xa0180d90;
                }
            }
        }
    }
    *(void ***)0xa0180d90 = ppvVar1;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04278 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc041a0 failed, args may be inaccurate.

undefined4 fcn.bfc04278(int32_t *param_1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    piVar3 = param_1 + 4;
    do {
        if (*piVar3 != 0) {
            fcn.bfc041a0(param_1[3]);
        }
        *piVar3 = 0;
        piVar3 = piVar3 + 1;
    } while (piVar3 != param_1 + 0x14);
    if ((int32_t *)param_1[2] != (int32_t *)0x0) {
        uVar1 = 0;
        if ((param_1 != (int32_t *)0x0) && (piVar3 = (int32_t *)param_1[2], piVar3 == (int32_t *)param_1[2])) {
            iVar4 = *param_1;
            if (iVar4 != 0) {
                *(int32_t *)(iVar4 + 4) = param_1[1];
            }
            piVar2 = (int32_t *)param_1[1];
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (param_1 == (int32_t *)piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (param_1 == (int32_t *)piVar3[1]) {
                piVar3[1] = *param_1;
            }
            iVar4 = *piVar3;
            param_1[2] = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04214 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes2 failed, args may be inaccurate.

void fcn.bfc04214(int32_t param_1, undefined2 param_2, undefined4 param_3)
{
    undefined4 *puVar1;
    
    zero_12bytes2();
    *(undefined4 *)(param_1 + 0xc) = param_3;
    *(undefined2 *)(param_1 + 0x50) = param_2;
    *(undefined *)(param_1 + 0x52) = 0;
    *(undefined *)(param_1 + 0x53) = 0;
    puVar1 = (undefined4 *)(param_1 + 0x10);
    do {
        *puVar1 = 0;
        puVar1 = puVar1 + 1;
    } while (puVar1 != (undefined4 *)(param_1 + 0x50));
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function init_rll_subfcn failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.

void init_rll_subfcn(undefined4 *param_1)
{
    undefined4 uVar1;
    int32_t unaff_retaddr;
    
    uVar1 = malloc(unaff_retaddr);
    *param_1 = uVar1;
    param_1[1] = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes failed, args may be inaccurate.

void zero_12bytes(undefined4 *param_1)
{
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function gettime failed, args may be inaccurate.

void gettime(undefined4 *param_1)
{
    undefined4 uVar1;
    
    uVar1 = *(undefined4 *)0xa1010004;
    param_1[1] = 0;
    *param_1 = uVar1;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function return failed, args may be inaccurate.

void return(void)
{
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08024 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

void fcn.bfc08024(undefined4 *param_1)
{
    queue_node *queue_node;
    queue_node *pqVar1;
    undefined *puVar2;
    undefined auStack32 [20];
    
    puVar2 = auStack32;
    queue_node = (queue_node *)param_1[1];
    while (queue_node != (queue_node *)0x0) {
        pqVar1 = (queue_node *)queue_node->next;
        fcn.bfc07f9c(queue_node);
        free(queue_node, 0xc, *(int32_t *)(puVar2 + 0x18), *(int32_t *)(puVar2 + 0x1c));
        puVar2 = puVar2 + 8;
        queue_node = pqVar1;
    }
    param_1[1] = 0;
    param_1[2] = 0;
    *param_1 = 0;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

void fcn.bfc009a4(rll_struct *rll_struct, char *enc_key, char *what)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    
    uVar3 = *(uint32_t *)enc_key;
    uVar2 = *(uint32_t *)(enc_key + 4);
    uVar1 = 0x3e778b90;
    do {
        uVar4 = uVar1 + *(int32_t *)(what + (uVar1 & 3) * 4);
        uVar1 = uVar1 + 0x83e778b9;
        uVar3 = uVar3 + (uVar4 ^ (uVar2 << 4 ^ uVar2 >> 5) + uVar2);
        uVar2 = uVar2 + (uVar1 + *(int32_t *)(what + (uVar1 >> 9 & 0xc)) ^ (uVar3 * 0x10 ^ uVar3 >> 5) + uVar3);
    } while (uVar1 != 0x7cef1720);
    *(uint32_t *)enc_key = uVar3;
    *(uint32_t *)(enc_key + 4) = uVar2;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function decrypt_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

uint32_t decrypt_block(rll_struct *rll_struct, char *data_block, uint32_t data_len)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    uint8_t *puVar3;
    uint8_t *enc_key;
    uint32_t *what;
    uint32_t uVar4;
    undefined *puVar5;
    undefined auStack32 [20];
    
    uVar4 = (uint32_t)rll_struct->encryption_enabled;
    if (uVar4 != 0) {
        puVar5 = auStack32;
        puVar3 = (uint8_t *)(data_block + data_len);
        enc_key = rll_struct->encryption_key;
        what = &rll_struct->unk13;
        puVar1 = (uint8_t *)data_block;
        while (puVar3 != puVar1) {
            uVar2 = (uint32_t)(puVar1 + -(int32_t)data_block) & 7;
            if (uVar2 == 0) {
                fcn.bfc009a4(rll_struct, enc_key, what, *puVar5);
                puVar5 = puVar5 + 4;
            }
            *puVar1 = enc_key[uVar2] ^ *puVar1;
            puVar1 = puVar1 + 1;
        }
        return uVar4;
    }
    return 0;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.

int32_t fcn.bfc079a8(int32_t arg_4h, int32_t arg_10h, int32_t arg_14h, int32_t arg_18h)
{
    int32_t in_a0;
    undefined in_a1;
    uint32_t in_a2;
    uint32_t uStack16;
    int32_t arg_0h;
    
    uStack16 = 0;
    while (uStack16 < in_a2) {
        *(undefined *)(in_a0 + uStack16) = in_a1;
        uStack16 = uStack16 + 1;
    }
    return in_a0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.

void p32(undefined *param_1, undefined4 param_2)
{
    *param_1 = (char)param_2;
    param_1[1] = (char)((uint32_t)param_2 >> 8);
    param_1[2] = (char)((uint32_t)param_2 >> 0x10);
    param_1[3] = (char)((uint32_t)param_2 >> 0x18);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function p16 failed, args may be inaccurate.

void p16(undefined *param_1, undefined4 param_2)
{
    *param_1 = (char)param_2;
    param_1[1] = (char)((uint32_t)param_2 >> 8);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00a30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc009a4 failed, args may be inaccurate.

uint32_t fcn.bfc00a30(int32_t param_1, uint8_t *param_2, int32_t param_3)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    uint8_t *puVar3;
    int32_t enc_key;
    int32_t what;
    uint32_t uVar4;
    undefined *puVar5;
    undefined auStack32 [20];
    
    uVar4 = (uint32_t)*(uint8_t *)(param_1 + 0x31);
    if (uVar4 != 0) {
        puVar5 = auStack32;
        puVar3 = param_2 + param_3;
        enc_key = param_1 + 0x50;
        what = param_1 + 0x34;
        puVar1 = param_2;
        while (puVar3 != puVar1) {
            uVar2 = (uint32_t)(puVar1 + -(int32_t)param_2) & 7;
            if (uVar2 == 0) {
                fcn.bfc009a4(param_1, enc_key, what, *puVar5);
                puVar5 = puVar5 + 4;
            }
            *puVar1 = *(uint8_t *)(enc_key + uVar2) ^ *puVar1;
            puVar1 = puVar1 + 1;
        }
        return uVar4;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function time_passed failed, args may be inaccurate.

int32_t time_passed(int32_t *param_1)
{
    return *(int32_t *)0xa1010004 - *param_1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function empty_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

void empty_queue(undefined4 *param_1)
{
    queue_node *queue_node;
    queue_node *pqVar1;
    undefined *puVar2;
    undefined auStack32 [20];
    
    puVar2 = auStack32;
    queue_node = (queue_node *)param_1[1];
    while (queue_node != (queue_node *)0x0) {
        pqVar1 = (queue_node *)queue_node->next;
        fcn.bfc07f9c(queue_node);
        free(queue_node, 0xc, *(int32_t *)(puVar2 + 0x18), *(int32_t *)(puVar2 + 0x1c));
        puVar2 = puVar2 + 8;
        queue_node = pqVar1;
    }
    param_1[1] = 0;
    param_1[2] = 0;
    *param_1 = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function u32_unaligned failed, args may be inaccurate.

uint32_t u32_unaligned(uint32_t param_1)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t in_v0;
    
    uVar1 = param_1 + 3 & 3;
    uVar2 = param_1 & 3;
    return (*(int32_t *)((param_1 + 3) - uVar1) << (3 - uVar1) * 8 | in_v0 & 0xffffffffU >> (uVar1 + 1) * 8) &
           -1 << (4 - uVar2) * 8 | *(uint32_t *)(param_1 - uVar2) >> uVar2 * 8;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function update_time_passed failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function time_passed failed, args may be inaccurate.

void update_time_passed(int32_t param_1)
{
    undefined4 uVar1;
    
    uVar1 = time_passed(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x2c) = uVar1;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function check_queue_size failed, args may be inaccurate.

bool check_queue_size(int32_t param_1)
{
    return *(int32_t *)(param_1 + 0x10) != 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function pop_from_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0802c failed, args may be inaccurate.

undefined4 pop_from_queue(queue_struct *queue_struct)
{
    undefined4 uVar1;
    
    if (queue_struct->entry_count != 0) {
        uVar1 = fcn.bfc0802c();
        queue_struct->entry_count = queue_struct->entry_count - 1;
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0802c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f08 failed, args may be inaccurate.

undefined4 fcn.bfc0802c(int32_t param_1)
{
    undefined4 uVar1;
    
    uVar1 = *(undefined4 *)(param_1 + 4);
    fcn.bfc07f08(param_1, uVar1);
    return uVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.

undefined4 fcn.bfc07f9c(int32_t *param_1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if ((int32_t *)param_1[2] != (int32_t *)0x0) {
        uVar1 = 0;
        if ((param_1 != (int32_t *)0x0) && (piVar3 = (int32_t *)param_1[2], piVar3 == (int32_t *)param_1[2])) {
            iVar4 = *param_1;
            if (iVar4 != 0) {
                *(int32_t *)(iVar4 + 4) = param_1[1];
            }
            piVar2 = (int32_t *)param_1[1];
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (param_1 == (int32_t *)piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (param_1 == (int32_t *)piVar3[1]) {
                piVar3[1] = *param_1;
            }
            iVar4 = *piVar3;
            param_1[2] = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function decode_macrll_packet failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u32_unaligned failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function empty_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function decrypt_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc042dc failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04364 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04414 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04278 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04214 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

uint32_t decode_macrll_packet(rll_struct *rll_struct, queue_data_chunk *data_chunk, uint32_t data_chunk_len)
{
    bool bVar1;
    uint8_t uVar2;
    undefined *puVar3;
    queue_node *pqVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int32_t *piVar7;
    uint32_t uVar8;
    void *pvVar9;
    undefined uVar10;
    char *data_block;
    uint32_t uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    queue_node *queue_node;
    int32_t unaff_s1;
    int32_t unaff_s2;
    int32_t unaff_s3;
    int32_t unaff_s4;
    int32_t unaff_s5;
    int32_t *piVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    int32_t *piVar21;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t iStackX4;
    undefined auStackX8 [8];
    int32_t in_stack_fffffac8;
    int32_t in_stack_fffffacc;
    undefined auStack1304 [1268];
    undefined auStack36 [4];
    undefined auStack32 [16];
    
    if (data_chunk_len < 5 != 0) {
        return (uint32_t)(data_chunk_len < 5);
    }
    uVar2 = data_chunk->type;
    if (uVar2 == 0x31) {
        if (data_chunk_len == 5) {
            return 5;
        }
        uVar6 = u32_unaligned(&data_chunk->field_0x1);
        if (rll_struct->last_packet_time < uVar6) {
            rll_struct->last_packet_time = uVar6;
        }
        uVar2 = *(uint8_t *)((int32_t)&data_chunk->timestamp + 1);
        uVar6 = (uint32_t)uVar2;
        rll_struct->unk10 = uVar2;
        rll_struct->unk22 = 0;
        empty_queue(&rll_struct->unk4);
        if ((uVar2 & 3) != 0) {
            uVar6 = (uVar6 & 0xfc) + 4 & 0xff;
        }
        rll_struct->unk1 = 0;
        rll_struct->unk2 = 0;
        uVar8 = 0;
        while (uVar11 = rll_struct->unk2, uVar8 <= 0x10000 - (uVar6 + 0x10)) {
            pvVar9 = rll_struct->malloced_chunk;
            uVar13 = rll_struct->unk1;
            piVar7 = (int32_t *)((int32_t)pvVar9 + uVar8);
            if (uVar13 == 0) {
                piVar7[3] = 0;
                piVar7[2] = 0;
            } else {
                piVar7[2] = uVar13;
                piVar7[3] = 0;
                *(int32_t **)(uVar13 + 0xc) = piVar7;
            }
            rll_struct->unk2 = uVar11 + 1;
            iVar12 = uVar8 + 0x10;
            rll_struct->unk1 = (uint32_t)piVar7;
            uVar8 = uVar8 + uVar6 + 0x10;
            *piVar7 = (int32_t)pvVar9 + iVar12;
        }
    // esilref: 'PDUPOOL::Init (size=&d) (items=&d) (&x,&x)'
        uVar6 = debug_print(4, 0xa0180a2c, 0x10000);
        rll_struct->unk3 = 0;
        return uVar6;
    }
    if (uVar2 == 0x4a) {
        uVar6 = u32_unaligned(&data_chunk->field_0x1);
        if (uVar6 <= rll_struct->last_packet_time) {
            return uVar6;
        }
        rll_struct->last_packet_time = uVar6;
        return uVar6;
    }
    uVar6 = (uint32_t)(data_chunk_len < 8);
    if (uVar2 != 0x37) {
        return uVar6;
    }
    if (uVar6 != 0) {
        return uVar6;
    }
    // PDU TYPE 0x37
    uVar6 = u32_unaligned(&data_chunk->field_0x1);
    if (rll_struct->last_packet_time < uVar6) {
        rll_struct->last_packet_time = uVar6;
    }
    uVar6 = (uint32_t)*(uint8_t *)((int32_t)&data_chunk->timestamp + 1);
    data_chunk_len = data_chunk_len - 6;
    if (uVar6 == 0x73) {
        data_block = (char *)((int32_t)&data_chunk->timestamp + 2);
        puVar19 = auStack36;
        uVar6 = (uint32_t)rll_struct->unk10;
        uVar8 = uVar6 - 1;
        if (uVar8 == data_chunk_len) {
            uVar11 = uVar6;
            if (rll_struct->encryption_enabled != 0) {
                uVar11 = uVar8;
                iVar12 = decrypt_block(rll_struct, data_block, uVar8);
                puVar19 = auStack32;
                data_chunk_len = uVar8;
                if (iVar12 != 0) {
                    uVar8 = u16(data_block);
                    uVar13 = (int32_t)uVar8 >> 4 & 0x7ff;
                    uVar11 = fcn.bfc07cd8(in_stack_fffffac8);
                    puVar15 = &stack0xfffffac8;
                    if (0x10 < uVar11) {
                        uVar11 = fcn.bfc07cd8(in_stack_fffffacc);
                        puVar15 = &stack0xfffffacc;
                        if (0x10 < uVar11) {
    // esilref: 'RLL::UL DEDICATED_MESSAGE SN SEQUENCE WINDOW[&d] out of range PDU SN[&d], PDU discarded.
    // '
                            uVar6 = debug_print(4, 0xa0180090, rll_struct->unk22, uVar13);
                            return uVar6;
                        }
                    }
                    uVar11 = rll_struct->unk5;
                    do {
                        if (uVar11 == 0) {
                            uVar11 = malloc2(*(int32_t *)(puVar15 + 0x14));
                            fcn.bfc04214(uVar11, uVar13, rll_struct);
                            *(uint32_t *)(puVar15 + 0x18) = uVar6 - 3 & 0xffff;
                            fcn.bfc042dc(uVar11, uVar8 >> 0xf & 1, uVar8 & 0xf, data_chunk->data);
                            add_data_block_to_linked_list(&rll_struct->unk4, uVar11);
                            puVar18 = puVar15 + 0x10;
code_r0xbfc00724:
                            iVar12 = fcn.bfc04364(uVar11);
                            puVar16 = puVar18 + 4;
                            if (iVar12 != 0) {
                                iVar12 = fcn.bfc04414(uVar11, puVar18 + 0x1c, 0x500, puVar18 + 0x51c);
                                puVar16 = puVar18 + 8;
                                if (iVar12 != 0) {
                                    puVar3 = (undefined *)malloc(*(int32_t *)(puVar18 + 0x1c));
                                    *puVar3 = 0x73;
                                    memcpy(*(int32_t *)(puVar18 + 0x18), *(int32_t *)(puVar18 + 0x1c), 
                                           *(int32_t *)(puVar18 + 0x20));
                                    pqVar4 = (queue_node *)malloc2(*(int32_t *)(puVar18 + 0x24));
                                    init_queue_node(pqVar4, puVar3, *(uint16_t *)(puVar18 + 0x52c) + 1, 0xbfc0184c);
                                    iVar12 = add_to_queue(rll_struct->rllrrl_queue, pqVar4);
                                    puVar16 = puVar18 + 0x1c;
                                    if (iVar12 == 0) {
                                        destruct_queue_node(pqVar4, puVar18[0x1c]);
                                        free(pqVar4, 0x18, *(int32_t *)(puVar18 + 0x34), *(int32_t *)(puVar18 + 0x38));
                                        puVar16 = puVar18 + 0x24;
                                    }
                                }
                            }
                            uVar6 = (uint32_t)(rll_struct->unk22 < 0x7f0);
                            if ((rll_struct->unk22 < uVar13) ||
                               ((bVar1 = uVar6 == 0, uVar6 = (uint32_t)(uVar13 < 0x11), bVar1 && (uVar6 != 0)))) {
                                rll_struct->unk22 = uVar13;
                                pqVar4 = (queue_node *)rll_struct->unk5;
                                puVar3 = puVar16;
                                while (puVar17 = puVar3, queue_node = pqVar4, queue_node != (queue_node *)0x0) {
                                    pqVar4 = (queue_node *)fcn.bfc07d50(&rll_struct->unk4, queue_node);
                                    uVar6 = fcn.bfc07cd8(*(int32_t *)(puVar17 + 8));
                                    uVar6 = (uint32_t)(uVar6 < 0x11);
                                    puVar3 = puVar17 + 8;
                                    if (uVar6 == 0) {
                                        uVar6 = fcn.bfc07cd8(*(int32_t *)(puVar17 + 0xc));
                                        uVar6 = (uint32_t)(uVar6 < 0x11);
                                        puVar3 = puVar17 + 0xc;
                                        if (uVar6 == 0) {
                                            fcn.bfc04278(queue_node);
                                            uVar6 = free(queue_node, 0x54, *(int32_t *)(puVar17 + 0x24), 
                                                         *(int32_t *)(puVar17 + 0x28));
                                            puVar3 = puVar17 + 0x14;
                                        }
                                    }
                                }
                            }
                            return uVar6;
                        }
                        if (*(uint16_t *)(uVar11 + 0x50) == uVar13) {
                            *(uint32_t *)(puVar15 + 0x10) = uVar6 - 3 & 0xffff;
                            fcn.bfc042dc(uVar11, uVar8 >> 0xf & 1, uVar8 & 0xf, data_chunk->data);
                            puVar18 = puVar15 + 4;
                            goto code_r0xbfc00724;
                        }
                        uVar11 = fcn.bfc07d50(&rll_struct->unk4, uVar11);
                        puVar15 = puVar15 + 4;
                    } while( true );
                }
            }
            uVar6 = uVar11;
            in_stack_00000000 = *(int32_t *)(puVar19 + 0x24);
            unaff_s1 = *(int32_t *)(puVar19 + 0x14);
            piVar21 = (int32_t *)(puVar19 + 0x28);
        } else {
            piVar21 = &iStackX4;
    // esilref: 'RLL::UL DEDICATED_MESSAGE MAC Grant Size[&d] != PDU length=&d'
        }
    } else {
        if (uVar6 == 0xc3) {
            puVar20 = auStack36;
            uVar6 = (uint32_t)rll_struct->unk10;
            uVar8 = uVar6 - 1;
            if (uVar8 == data_chunk_len) {
                if (rll_struct->encryption_enabled != 0) {
                    uVar6 = uVar8;
                    iVar12 = unaff_retaddr;
                    unaff_retaddr = unaff_s3;
                    iVar5 = decrypt_block(rll_struct, (char *)((int32_t)&data_chunk->timestamp + 2), uVar8);
                    unaff_s3 = in_stack_00000000;
                    puVar20 = auStack32;
                    data_chunk_len = uVar8;
                    if (iVar5 != 0) {
                        uVar10 = 0xc3;
                        piVar14 = (int32_t *)auStackX8;
                        in_stack_00000000 = iStackX4;
                        unaff_s1 = unaff_s2;
                        unaff_s2 = iVar12;
                        goto code_r0xbfc00520;
                    }
                }
                in_stack_00000000 = *(int32_t *)(puVar20 + 0x24);
                unaff_s1 = *(int32_t *)(puVar20 + 0x14);
                piVar21 = (int32_t *)(puVar20 + 0x28);
            } else {
                piVar21 = &iStackX4;
    // esilref: 'RLL::UL FAST_MESSAGE MAC Grant Size[&d] != PDU length=&d'
            }
        } else {
            uVar10 = 0x17;
            if (uVar6 != 0x17) {
                return uVar6;
            }
            piVar14 = &iStackX4;
            piVar21 = &iStackX4;
            uVar6 = (uint32_t)rll_struct->unk10;
            if (uVar6 - 1 == data_chunk_len) {
code_r0xbfc00520:
                piVar14[-5] = unaff_retaddr;
                piVar14[-4] = unaff_s3;
                piVar14[-1] = in_stack_00000000;
                piVar14[-2] = unaff_s5;
                piVar14[-3] = unaff_s4;
                piVar14[-6] = unaff_s2;
                piVar14[-7] = unaff_s1;
                puVar3 = (undefined *)malloc(piVar14[-7]);
                *puVar3 = uVar10;
                memcpy(piVar14[-8], piVar14[-7], piVar14[-6]);
                iVar12 = malloc2(piVar14[-5]);
                init_queue_node(iVar12, puVar3, data_chunk_len + 1, 0xbfc0184c);
                uVar6 = add_to_queue(rll_struct->rllrrl_queue, iVar12);
                if (uVar6 == 0) {
                    destruct_queue_node(iVar12, *(undefined *)(piVar14 + -7));
                    piVar14[5] = piVar14[5];
                    piVar14[4] = unaff_s8;
                    piVar14[6] = iVar12;
                    piVar14[7] = 0x18;
                    uVar6 = fcn.bfc06d40((queue_node *)piVar14[6], 0x18, *piVar14, piVar14[1], piVar14[2], piVar14[3], 
                                         piVar14[4], piVar14[7]);
                    return uVar6;
                }
                return uVar6;
            }
        }
    }
    *(uint32_t *)((int32_t)piVar21 + 8) = uVar6;
    *(int32_t *)((int32_t)piVar21 + -8) = unaff_s1;
    *(int32_t *)((int32_t)piVar21 + -4) = in_stack_00000000;
    *(uint32_t *)((int32_t)piVar21 + 0xc) = data_chunk_len;
    *(undefined **)((int32_t)piVar21 + -0x10) = (undefined *)((int32_t)piVar21 + 8);
    uVar6 = fcn.bfc05988(*(int32_t *)((int32_t)piVar21 + -0x414), *(int32_t *)((int32_t)piVar21 + -0x410), 
                         *(int32_t *)((int32_t)piVar21 + -0x40c), *(int32_t *)((int32_t)piVar21 + -0x408), 
                         *(int32_t *)((int32_t)piVar21 + -0x404), *(int32_t *)((int32_t)piVar21 + -0x400), 
                         *(int32_t *)((int32_t)piVar21 + -0x3fc), *(int32_t *)((int32_t)piVar21 + -0x3f8), 
                         *(int32_t *)((int32_t)piVar21 + -0x3f4), *(int32_t *)((int32_t)piVar21 + -0x3f0), 
                         *(int32_t *)((int32_t)piVar21 + -0x3ec), *(int32_t *)((int32_t)piVar21 + -1000), 
                         *(int32_t *)((int32_t)piVar21 + -0x3e4), *(int32_t *)((int32_t)piVar21 + -0x3e0), 
                         *(int32_t *)((int32_t)piVar21 + -0x3dc), *(int32_t *)((int32_t)piVar21 + -0x3d8), 
                         *(int32_t *)((int32_t)piVar21 + -0x3d4), *(int32_t *)((int32_t)piVar21 + -900), 
                         *(int32_t *)((int32_t)piVar21 + -0x380), *(int32_t *)((int32_t)piVar21 + -0x37c));
    fcn.bfc065f8(*(int32_t *)((int32_t)piVar21 + -0x410), *(int32_t *)((int32_t)piVar21 + -0x40c), 
                 *(int32_t *)((int32_t)piVar21 + 0xc00), *(int32_t *)((int32_t)piVar21 + 0xc04), 
                 *(int32_t *)((int32_t)piVar21 + 0xc08), *(int32_t *)((int32_t)piVar21 + 0xc0c));
    return uVar6;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01370 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00a30 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function p16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

uint32_t fcn.bfc01370(rll_struct *rll_struct, char *data_block, uint32_t len)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    queue_node *pqVar3;
    int32_t iVar4;
    uint32_t uVar5;
    queue_node *pqVar6;
    uint32_t uVar7;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t unaff_s2;
    uint32_t uVar8;
    int32_t unaff_s3;
    int32_t unaff_s4;
    undefined *puVar9;
    undefined *puVar10;
    queue_node **ppqVar11;
    queue_node *unaff_s8;
    int32_t unaff_retaddr;
    uint32_t uVar12;
    queue_node *in_stack_0000001c;
    int32_t in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    int32_t in_stack_ffffffdc;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    
    if (len < 2 != 0) {
        return (uint32_t)(len < 2);
    }
    uVar5 = (uint32_t)(uint8_t)*data_block;
    if (uVar5 == 0x73) {
        len = len - 1;
        if (len == 0) {
            return 0x73;
        }
        if (rll_struct->encryption_enabled == 0) {
code_r0xbfc017e0:
            uVar5 = fcn.bfc05988(in_stack_fffffbec, in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, 
                                 in_stack_fffffbfc, in_stack_fffffc00, in_stack_fffffc04, in_stack_fffffc08, 
                                 in_stack_fffffc0c, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc18, 
                                 in_stack_fffffc1c, in_stack_fffffc20, in_stack_fffffc24, in_stack_fffffc28, 
                                 in_stack_fffffc2c, in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84);
            fcn.bfc065f8(in_stack_fffffbf0, in_stack_fffffbf4, in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, 
                         in_stack_00000c0c);
            return uVar5;
        }
        uVar5 = rll_struct->unk10 - 3;
        uVar12 = len / uVar5;
        if (uVar5 == 0) {
            trap(0x1c00);
        }
        rll_struct->unk23 = rll_struct->unk23 + 1;
        if (uVar12 < 0x10) {
            if (len % uVar5 != 0) {
                uVar12 = uVar12 + 1;
            }
        } else {
            uVar12 = 0x10;
        }
        uVar5 = 0;
        iVar4 = 0;
        puVar1 = &stack0xffffffb8;
        while( true ) {
            if (uVar12 <= uVar5) {
                return 0;
            }
            uVar8 = rll_struct->unk10 - 3;
            if ((uint32_t)(*(int32_t *)(puVar1 + 0x14) - iVar4) < uVar8) {
                uVar8 = *(int32_t *)(puVar1 + 0x14) - iVar4;
            }
            queue_node = (queue_node *)malloc(*(int32_t *)(puVar1 + 0x14));
            uVar7 = rll_struct->time_passed;
            *(undefined *)&queue_node->next = 0x9c;
            p32((int32_t)&queue_node->next + 1, uVar7);
            *(undefined *)((int32_t)&queue_node->prev + 1) = 0x73;
            iVar2 = (int32_t)&queue_node->prev + 2;
            *(int32_t *)(puVar1 + 0x20) = iVar2;
            p16(iVar2, (uint32_t)(uVar5 + 1 == uVar12) << 0xf | *(uint32_t *)(puVar1 + 0x18) | uVar5 & 0xf);
            memcpy(*(int32_t *)(puVar1 + 0x18), *(int32_t *)(puVar1 + 0x1c), *(int32_t *)(puVar1 + 0x20));
            iVar4 = iVar4 + uVar8;
            iVar2 = fcn.bfc00a30(rll_struct, *(undefined4 *)(puVar1 + 0x28), rll_struct->unk10 - 1);
            if (iVar2 == 0) break;
            pqVar6 = (queue_node *)malloc2(*(int32_t *)(puVar1 + 0x28));
            init_queue_node(pqVar6, queue_node, rll_struct->unk10 + 5, 0xbfc0184c);
            iVar2 = add_to_queue(rll_struct->rllmac_queue, pqVar6);
            puVar9 = puVar1 + 0x20;
            if (iVar2 == 0) {
                destruct_queue_node(pqVar6, puVar1[0x20]);
                free(pqVar6, 0x18, *(int32_t *)(puVar1 + 0x38), *(int32_t *)(puVar1 + 0x3c));
                puVar9 = puVar1 + 0x28;
            }
            uVar5 = uVar5 + 1 & 0xff;
            puVar1 = puVar9;
        }
    // esilref: 'RLL::DL DEDICATED MESSAGE PDU Encryptioned failed, discarding.
    // '
        debug_print(4, 0xa01802dc);
        in_stack_0000001c = *(queue_node **)(puVar1 + 0x5c);
        unaff_s8 = *(queue_node **)(puVar1 + 0x58);
        pqVar6 = (queue_node *)0x1;
        ppqVar11 = (queue_node **)(puVar1 + 0x60);
    } else {
        if (uVar5 < 0x74) {
            if (uVar5 != 0x17) {
                return uVar5;
            }
            if ((len == 1) || (uVar5 = (uint32_t)(rll_struct->unk10 - 1 < len - 1), uVar5 != 0)) {
                return uVar5;
            }
            puVar1 = (undefined *)malloc(unaff_s0);
            fcn.bfc079a8(in_stack_ffffffdc, in_stack_ffffffe8, unaff_s0, unaff_s1);
            uVar5 = rll_struct->time_passed;
            *puVar1 = 0x9c;
            p32(puVar1 + 1, uVar5);
            puVar1[5] = 0x17;
            memcpy(unaff_s1, unaff_s2, unaff_s3);
            queue_node = (queue_node *)malloc2(unaff_retaddr);
            init_queue_node(queue_node, puVar1, rll_struct->unk10 + 5, 0xbfc0184c);
            uVar5 = add_to_queue(rll_struct->rllmac_queue, queue_node);
            if (uVar5 != 0) {
                return uVar5;
            }
            destruct_queue_node(queue_node);
            pqVar6 = (queue_node *)0x18;
            ppqVar11 = (queue_node **)&stack0x00000020;
        } else {
            if (uVar5 != 0xc3) {
                if (uVar5 != 0xd2) {
                    return uVar5;
                }
                if (len != 0x21) {
                    return 0x20;
                }
                memcpy(in_stack_ffffffec, in_stack_fffffff0, unaff_s0);
                memcpy(in_stack_fffffff0, unaff_s0, unaff_s1);
                memcpy(unaff_s0, unaff_s1, unaff_retaddr);
                rll_struct->encryption_enabled = 1;
                return 1;
            }
            if (len == 1) {
                return 0xc3;
            }
            if (rll_struct->encryption_enabled == 0) goto code_r0xbfc017e0;
            pqVar3 = (queue_node *)malloc(unaff_s0);
            uVar5 = rll_struct->time_passed;
            *(undefined *)&pqVar3->next = 0x9c;
            p32((int32_t)&pqVar3->next + 1, uVar5);
            *(undefined *)((int32_t)&pqVar3->prev + 1) = 0xc3;
            memcpy(unaff_s0, unaff_s1, unaff_s2);
            iVar4 = fcn.bfc00a30(rll_struct, (int32_t)&pqVar3->prev + 2, rll_struct->unk10 - 1);
            if (iVar4 == 0) {
    // esilref: 'RLL::DL FAST MESSAGE PDU Encryptioned failed, discarding.
    // '
                debug_print(4, 0xa0180358);
                puVar10 = &stack0xffffffe4;
                pqVar6 = (queue_node *)0x1;
                queue_node = pqVar3;
            } else {
                queue_node = (queue_node *)malloc2(unaff_s4);
                init_queue_node(queue_node, pqVar3, rll_struct->unk10 + 5, 0xbfc0184c);
                uVar5 = add_to_queue(rll_struct->rllmac_queue, queue_node);
                if (uVar5 != 0) {
                    return uVar5;
                }
                destruct_queue_node(queue_node);
                puVar10 = &stack0xfffffff0;
                pqVar6 = (queue_node *)0x18;
            }
            in_stack_0000001c = *(queue_node **)(puVar10 + 0x2c);
            ppqVar11 = (queue_node **)(puVar10 + 0x30);
        }
    }
    ppqVar11[-1] = in_stack_0000001c;
    ppqVar11[-2] = unaff_s8;
    *ppqVar11 = queue_node;
    ppqVar11[1] = pqVar6;
    uVar5 = fcn.bfc06d40(*ppqVar11, (uint32_t)pqVar6, (int32_t)ppqVar11[-6], (int32_t)ppqVar11[-5], 
                         (int32_t)ppqVar11[-4], (int32_t)ppqVar11[-3], (int32_t)ppqVar11[-2], (int32_t)ppqVar11[1]);
    return uVar5;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01250 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc01250(int32_t param_1)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t unaff_s1;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    
    puVar1 = (undefined *)malloc(unaff_s1);
    uVar3 = *(undefined4 *)(param_1 + 0x2c);
    *puVar1 = 0x4d;
    p32(puVar1 + 1, uVar3);
    queue_node = (queue_node *)malloc2(unaff_retaddr);
    init_queue_node(queue_node, puVar1, 5, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(param_1 + 0x6c), queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        fcn.bfc06d40(queue_node, 0x18, in_stack_00000000, in_stack_00000004, in_stack_00000008, in_stack_0000000c, 
                     unaff_s8, 0x18);
        return;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.

undefined8 fcn.bfc04678(int32_t arg_4h, int32_t arg_8h, int32_t arg_ch)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t arg_0h;
    
    iVar5 = *(int32_t *)0xa0180d8c * 8;
    uVar6 = *(uint32_t *)(iVar5 + -0x5fe7f23c);
    *(uint32_t *)0xa0180d8c = *(int32_t *)0xa0180d8c + 1 & 0x8000000f;
    if ((int32_t)*(uint32_t *)0xa0180d8c < 0) {
        *(uint32_t *)0xa0180d8c = (*(uint32_t *)0xa0180d8c - 1 | 0xfffffff0) + 1;
    }
    uVar7 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f23c);
    uVar3 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f240);
    uVar4 = uVar3 ^ uVar3 << 0x1b;
    uVar7 = uVar7 ^ (uVar3 >> 5 | uVar7 << 0x1b);
    iVar2 = *(uint32_t *)0xa0180d8c * 8;
    *(uint32_t *)(iVar2 + -0x5fe7f240) =
         *(uint32_t *)(iVar5 + -0x5fe7f240) ^ uVar6 >> 0xe ^ uVar4 ^ (uVar7 << 0x13 | uVar4 >> 0xd);
    *(uint32_t *)(iVar2 + -0x5fe7f23c) = uVar6 ^ uVar7 ^ uVar7 >> 0xd;
    uVar6 = *(uint32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f240);
    iVar1 = (uint64_t)uVar6 * 0xcf637165;
    return CONCAT44((int32_t)iVar1, 
                    *(int32_t *)(*(uint32_t *)0xa0180d8c * 8 + -0x5fe7f23c) * -0x309c8e9b + uVar6 * 0x19e4b16e +
                    (int32_t)((uint64_t)iVar1 >> 0x20));
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.

int32_t strlen(int32_t arg_10h)
{
    int32_t in_a0;
    int32_t iStack16;
    int32_t arg_0h;
    
    iStack16 = 0;
    while (*(char *)(in_a0 + iStack16) != '\0') {
        iStack16 = iStack16 + 1;
    }
    return iStack16;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06658 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.

int32_t fcn.bfc06658(int32_t arg_10h, int32_t arg_14h, int32_t arg_20h, int32_t arg_24h, int32_t arg_28h,
                    int32_t arg_2ch)
{
    int32_t iVar1;
    int32_t in_a0;
    int32_t in_a1;
    int32_t in_a2;
    int32_t in_a3;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000014;
    int32_t in_stack_00000018;
    int32_t in_stack_0000002c;
    int32_t in_stack_0000007c;
    int32_t in_stack_00000080;
    int32_t in_stack_00000084;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    
    iVar1 = fcn.bfc05988(in_stack_ffffffec, in_stack_fffffff0, (int32_t)&stack0x00000008, unaff_s8, unaff_retaddr, in_a0
                         , in_a1, in_a2, in_a3, arg_14h, in_stack_00000014, in_stack_00000018, arg_20h, arg_24h, arg_28h
                         , arg_2ch, in_stack_0000002c, in_stack_0000007c, in_stack_00000080, in_stack_00000084);
    *(undefined *)(in_a0 + iVar1) = 0;
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc03f3c(int32_t arg_18h)
{
    queue_node *in_a0;
    uint32_t in_a1;
    int32_t unaff_s8;
    int32_t in_stack_00000004;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    int32_t in_stack_fffffff4;
    
    fcn.bfc06d40(in_a0, in_a1, in_stack_ffffffe8, in_stack_ffffffec, in_stack_fffffff0, in_stack_fffffff4, unaff_s8, 
                 in_stack_00000004);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01d90 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

int32_t fcn.bfc01d90(int32_t param_1, int32_t param_2, int32_t param_3)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t iVar4;
    int32_t in_stack_ffffffe8;
    
    iVar3 = param_3 + 1;
    puVar1 = (undefined *)malloc(param_2);
    *puVar1 = 0x73;
    memcpy(param_3, param_2, in_stack_ffffffe8);
    iVar4 = *(int32_t *)(param_1 + 4);
    iVar2 = malloc2(unaff_s0);
    init_queue_node(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(iVar4 + 0x10) < 0x20) && (iVar2 = add_data_block_to_linked_list(), iVar2 != 0)) {
        *(int32_t *)(iVar4 + 0x10) = *(int32_t *)(iVar4 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc070c0 failed, args may be inaccurate.

undefined4 fcn.bfc070c0(int32_t arg_4h, int32_t arg_8h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_20h)
{
    undefined4 uVar1;
    int32_t in_a0;
    int32_t in_a1;
    uint32_t in_a2;
    uint32_t uStack24;
    int32_t arg_0h;
    
    if (in_a2 == 0) {
        uVar1 = 0;
    } else {
        uStack24 = 0;
        while ((uStack24 < in_a2 && (*(char *)(in_a0 + uStack24) == *(char *)(in_a1 + uStack24)))) {
            uStack24 = uStack24 + 1;
        }
        if (uStack24 == in_a2) {
            uVar1 = 0;
        } else {
            if (*(uint8_t *)(in_a1 + uStack24) < *(uint8_t *)(in_a0 + uStack24)) {
                uVar1 = 1;
            } else {
                uVar1 = 0xffffffff;
            }
        }
    }
    return uVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

void fcn.bfc020b4(int32_t param_1, int32_t param_2)
{
    int32_t iVar1;
    
    iVar1 = *(int32_t *)(param_1 + 0x10);
    while ((iVar1 != 0 && (param_2 != *(int32_t *)(iVar1 + 0x90)))) {
        iVar1 = fcn.bfc07d50(param_1 + 0xc, iVar1);
    }
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

int32_t fcn.bfc01e28(int32_t param_1, int32_t param_2, int32_t param_3)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t iVar4;
    int32_t in_stack_ffffffe8;
    
    iVar3 = param_3 + 1;
    puVar1 = (undefined *)malloc(param_2);
    *puVar1 = 0xc3;
    memcpy(param_3, param_2, in_stack_ffffffe8);
    iVar4 = *(int32_t *)(param_1 + 4);
    iVar2 = malloc2(unaff_s0);
    init_queue_node(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(iVar4 + 0x10) < 0x20) && (iVar2 = add_data_block_to_linked_list(), iVar2 != 0)) {
        *(int32_t *)(iVar4 + 0x10) = *(int32_t *)(iVar4 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0210c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u32_unaligned failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.

void fcn.bfc0210c(undefined4 param_1, char *param_2, int32_t param_3)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined *puVar4;
    undefined *puVar5;
    int32_t in_stack_fffffbdc;
    int32_t in_stack_fffffbe0;
    int32_t in_stack_fffffbe4;
    undefined auStack1046 [1018];
    
    uVar1 = u32_unaligned(param_2 + 1);
    iVar2 = fcn.bfc020b4(param_1, uVar1);
    puVar5 = &stack0xfffffbd0;
    if (iVar2 != 0) {
        if (*param_2 == '\x01') {
            uVar3 = (uint32_t)(uint8_t)param_2[5];
            if (uVar3 <= param_3 - 6U) {
                if (0x200 < uVar3 + *(int32_t *)(iVar2 + 0xa4)) {
                    uVar3 = 0x200 - *(int32_t *)(iVar2 + 0xa4);
                }
                puVar4 = &stack0xfffffbd0;
                if (uVar3 != 0) {
                    memcpy(in_stack_fffffbdc, in_stack_fffffbe0, in_stack_fffffbe4);
                    *(uint32_t *)(iVar2 + 0xa4) = *(int32_t *)(iVar2 + 0xa4) + uVar3;
                    puVar4 = &stack0xfffffbd4;
                    if (*(code **)(iVar2 + 0x98) != (code *)0x0) {
                        (**(code **)(iVar2 + 0x98))(param_2 + 6, uVar3);
                        puVar4 = &stack0xfffffbd4;
                    }
                }
                puVar4[0x10] = 1;
                p32(puVar4 + 0x11, uVar1);
                puVar5 = puVar4 + 4;
                puVar4[0x19] = (char)uVar3;
                iVar2 = 6;
                goto code_r0xbfc0220c;
            }
        } else {
            if (*param_2 == '\x02') {
                uVar3 = *(int32_t *)(iVar2 + 0xa4) - *(int32_t *)(iVar2 + 0xa0);
                if ((uint8_t)param_2[5] < uVar3) {
                    uVar3 = (uint32_t)(uint8_t)param_2[5];
                }
                puVar4 = &stack0xfffffbd0;
                if (uVar3 != 0) {
                    memcpy(in_stack_fffffbdc, in_stack_fffffbe0, in_stack_fffffbe4);
                    *(uint32_t *)(iVar2 + 0xa0) = *(int32_t *)(iVar2 + 0xa0) + uVar3;
                    puVar4 = &stack0xfffffbd4;
                    if (*(code **)(iVar2 + 0x9c) != (code *)0x0) {
                        (**(code **)(iVar2 + 0x9c))(auStack1046, uVar3);
                        puVar4 = &stack0xfffffbd4;
                    }
                }
                puVar4[0x10] = 2;
                p32(puVar4 + 0x11, uVar1);
                puVar5 = puVar4 + 4;
                puVar4[0x19] = (char)uVar3;
                iVar2 = uVar3 + 6;
                goto code_r0xbfc0220c;
            }
        }
    }
    iVar2 = 2;
code_r0xbfc0220c:
    fcn.bfc01e28(param_1, puVar5 + 0x10, iVar2);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ba0 failed, args may be inaccurate.

uint32_t fcn.bfc01ba0(int32_t param_1, uint32_t param_2, uint32_t param_3)
{
    uint32_t uVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    
    if ((param_2 <= *(uint32_t *)(param_1 + 0xc)) && (param_3 <= *(uint32_t *)(param_1 + 0xc))) {
        puVar3 = (uint8_t *)(*(int32_t *)(param_1 + 0x10) + param_2);
        uVar1 = 0x512078cd;
        puVar2 = puVar3;
        while (puVar2 != puVar3 + param_3) {
            uVar1 = *(uint32_t *)(((*puVar2 ^ uVar1) & 0xff) * 4 + -0x5fe7fbd0) ^ uVar1 >> 8;
            puVar2 = puVar2 + 1;
        }
        return ~uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fbc failed, args may be inaccurate.

undefined4 fcn.bfc07fbc(int32_t *param_1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if ((int32_t *)param_1[2] != (int32_t *)0x0) {
        uVar1 = 0;
        if ((param_1 != (int32_t *)0x0) && (piVar3 = (int32_t *)param_1[2], piVar3 == (int32_t *)param_1[2])) {
            iVar4 = *param_1;
            if (iVar4 != 0) {
                *(int32_t *)(iVar4 + 4) = param_1[1];
            }
            piVar2 = (int32_t *)param_1[1];
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (param_1 == (int32_t *)piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (param_1 == (int32_t *)piVar3[1]) {
                piVar3[1] = *param_1;
            }
            iVar4 = *piVar3;
            param_1[2] = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01bdc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06658 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.

int32_t fcn.bfc01bdc(int32_t param_1)
{
    int32_t iVar1;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t unaff_s2;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    iVar1 = malloc(in_stack_ffffffe4);
    memcpy(in_stack_ffffffe0, in_stack_ffffffe4, in_stack_ffffffe8);
    *(undefined *)(iVar1 + (uint32_t)*(uint8_t *)(param_1 + 0x8c)) = 0;
    fcn.bfc06658(in_stack_ffffffe4, (uint32_t)*(uint8_t *)(param_1 + 0x94), unaff_s1, unaff_s2, unaff_retaddr, 
                 in_stack_00000000);
    // esilref: '&s: &d &d &d'
    fcn.bfc03f3c(unaff_s0);
    return unaff_s2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02008 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc070c0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

undefined4 fcn.bfc02008(int32_t param_1, undefined4 param_2, uint32_t param_3, undefined4 *param_4)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t *piVar3;
    undefined auStack40 [16];
    
    piVar3 = (int32_t *)auStack40;
    iVar2 = *(int32_t *)(param_1 + 0x10);
    do {
        if (iVar2 == 0) {
            *param_4 = 0;
            return 0;
        }
        if (*(uint8_t *)(iVar2 + 0x8c) == param_3) {
            iVar1 = fcn.bfc070c0(*piVar3, piVar3[1], piVar3[5], piVar3[6], piVar3[7]);
            piVar3 = piVar3 + 1;
            if (iVar1 == 0) {
                *param_4 = *(undefined4 *)(iVar2 + 0x90);
                return 1;
            }
        }
        iVar2 = fcn.bfc07d50(param_1 + 0xc, iVar2);
        piVar3 = (int32_t *)((int32_t)piVar3 + 4);
    } while( true );
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc025d4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07d50 failed, args may be inaccurate.

int32_t fcn.bfc025d4(int32_t param_1)
{
    int32_t iVar1;
    int32_t iVar2;
    
    iVar1 = *(int32_t *)(param_1 + 0x10);
    iVar2 = 0;
    while (iVar1 != 0) {
        iVar2 = iVar2 + 1;
        iVar1 = fcn.bfc07d50(param_1 + 0xc, iVar1);
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01884 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.

void fcn.bfc01884(undefined *param_1, uint32_t param_2)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    undefined auStack32 [20];
    
    if (0x1f < param_2) {
        piVar2 = (int32_t *)auStack32;
        do {
            uVar1 = fcn.bfc04678(*piVar2, piVar2[1], piVar2[2]);
            piVar3 = piVar2 + 1;
            if (param_2 < 4) {
                *param_1 = (char)uVar1;
            } else {
                p32(param_1, uVar1);
                piVar3 = piVar2 + 2;
            }
            param_2 = param_2 - 1;
            param_1 = param_1 + 1;
            piVar2 = piVar3;
        } while (param_2 != 0);
        return;
    }
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01cf8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

int32_t fcn.bfc01cf8(int32_t param_1, int32_t param_2, int32_t param_3)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t iVar4;
    int32_t in_stack_ffffffe8;
    
    iVar3 = param_3 + 1;
    puVar1 = (undefined *)malloc(param_2);
    *puVar1 = 0x17;
    memcpy(param_3, param_2, in_stack_ffffffe8);
    iVar4 = *(int32_t *)(param_1 + 4);
    iVar2 = malloc2(unaff_s0);
    init_queue_node(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(iVar4 + 0x10) < 0x20) && (iVar2 = add_data_block_to_linked_list(), iVar2 != 0)) {
        *(int32_t *)(iVar4 + 0x10) = *(int32_t *)(iVar4 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc028d0 failed, args may be inaccurate.

void fcn.bfc028d0(undefined4 param_1, uint32_t *param_2, int32_t param_3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    
    uVar3 = *param_2;
    uVar2 = param_2[1];
    uVar1 = 0x3e778b90;
    do {
        uVar4 = uVar1 + *(int32_t *)(param_3 + (uVar1 & 3) * 4);
        uVar1 = uVar1 + 0x83e778b9;
        uVar3 = uVar3 + (uVar4 ^ (uVar2 << 4 ^ uVar2 >> 5) + uVar2);
        uVar2 = uVar2 + (uVar1 + *(int32_t *)(param_3 + (uVar1 >> 9 & 0xc)) ^ (uVar3 * 0x10 ^ uVar3 >> 5) + uVar3);
    } while (uVar1 != 0x7cef1720);
    *param_2 = uVar3;
    param_2[1] = uVar2;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b14 failed, args may be inaccurate.

void fcn.bfc03b14(undefined4 *param_1)
{
    param_1[2] = 0x67452301;
    param_1[3] = 0xefcdab89;
    param_1[4] = 0x98badcfe;
    param_1[5] = 0x10325476;
    *param_1 = 0;
    param_1[1] = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

undefined4 fcn.bfc03b50(uint32_t *param_1, int32_t param_2, uint32_t param_3)
{
    undefined *puVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t *puVar4;
    int32_t unaff_s0;
    undefined *puVar5;
    undefined4 unaff_s8;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    puVar5 = &stack0xffffffd8;
    uVar3 = *param_1;
    uVar2 = uVar3 + param_3 & 0x1fffffff;
    *param_1 = uVar2;
    if (uVar2 < uVar3) {
        param_1[1] = param_1[1] + 1;
    }
    uVar3 = uVar3 & 0x3f;
    param_1[1] = param_1[1] + (param_3 >> 0x1d);
    puVar1 = &stack0xffffffd8;
    if (uVar3 != 0) {
        uVar2 = 0x40 - uVar3;
        puVar4 = (uint32_t *)((int32_t)param_1 + uVar3 + 0x18);
        if (param_3 < uVar2) goto code_r0xbfc03bdc;
        memcpy(in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0);
        param_2 = param_2 + uVar2;
        param_3 = param_3 - uVar2;
        fcn.bfc02d20(param_1, param_1 + 6, 0x40);
        puVar1 = &stack0xffffffe0;
    }
    puVar5 = puVar1;
    if (0x3f < param_3) {
        param_2 = fcn.bfc02d20(param_1, param_2, param_3 & 0xffffffc0);
        puVar5 = puVar5 + 4;
        param_3 = param_3 & 0x3f;
    }
    puVar4 = param_1 + 6;
code_r0xbfc03bdc:
    *(undefined4 *)(puVar5 + 0x24) = unaff_s8;
    *(uint32_t **)(puVar5 + 0x28) = puVar4;
    *(int32_t *)(puVar5 + 0x2c) = param_2;
    *(uint32_t *)(puVar5 + 0x30) = param_3;
    *(undefined4 *)(puVar5 + 0x18) = 0;
    while (*(uint32_t *)(puVar5 + 0x18) < *(uint32_t *)(puVar5 + 0x30)) {
        *(undefined *)(*(int32_t *)(puVar5 + 0x28) + *(int32_t *)(puVar5 + 0x18)) =
             *(undefined *)(*(int32_t *)(puVar5 + 0x2c) + *(int32_t *)(puVar5 + 0x18));
        *(int32_t *)(puVar5 + 0x18) = *(int32_t *)(puVar5 + 0x18) + 1;
    }
    return *(undefined4 *)(puVar5 + 0x28);
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03c54 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

int32_t fcn.bfc03c54(uint32_t *param_1, undefined *param_2, uint32_t param_3)
{
    int32_t in_v0;
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t *piVar3;
    int32_t unaff_s8;
    int32_t in_stack_ffffffe0;
    int32_t in_stack_ffffffec;
    
    if (0xf < param_3) {
        piVar3 = (int32_t *)&stack0xffffffe0;
        uVar1 = *param_1;
        *(undefined *)((int32_t)param_1 + (uVar1 & 0x3f) + 0x18) = 0x80;
        if (0x40 - ((uVar1 & 0x3f) + 1) < 8) {
            fcn.bfc079a8(in_stack_ffffffe0, in_stack_ffffffec, unaff_s0, unaff_s1);
            fcn.bfc02d20(param_1, param_1 + 6, 0x40);
            piVar3 = (int32_t *)&stack0xffffffe8;
        }
        fcn.bfc079a8(*piVar3, piVar3[3], piVar3[4], piVar3[5]);
        uVar1 = *param_1 << 3;
        *param_1 = uVar1;
        *(char *)(param_1 + 0x14) = (char)uVar1;
        *(char *)((int32_t)param_1 + 0x51) = (char)(uVar1 >> 8);
        *(char *)((int32_t)param_1 + 0x53) = (char)(uVar1 >> 0x18);
        uVar2 = param_1[1];
        *(char *)((int32_t)param_1 + 0x52) = (char)(uVar1 >> 0x10);
        *(char *)(param_1 + 0x15) = (char)uVar2;
        *(char *)((int32_t)param_1 + 0x55) = (char)(uVar2 >> 8);
        *(char *)((int32_t)param_1 + 0x56) = (char)(uVar2 >> 0x10);
        *(char *)((int32_t)param_1 + 0x57) = (char)(uVar2 >> 0x18);
        fcn.bfc02d20(param_1, param_1 + 6, 0x40);
        *param_2 = (char)param_1[2];
        param_2[1] = (char)(param_1[2] >> 8);
        param_2[2] = (char)*(undefined2 *)((int32_t)param_1 + 10);
        param_2[3] = *(undefined *)((int32_t)param_1 + 0xb);
        param_2[4] = (char)param_1[3];
        param_2[5] = (char)(param_1[3] >> 8);
        param_2[6] = (char)*(undefined2 *)((int32_t)param_1 + 0xe);
        param_2[7] = *(undefined *)((int32_t)param_1 + 0xf);
        param_2[8] = (char)param_1[4];
        param_2[9] = (char)(param_1[4] >> 8);
        param_2[10] = (char)*(undefined2 *)((int32_t)param_1 + 0x12);
        param_2[0xb] = *(undefined *)((int32_t)param_1 + 0x13);
        param_2[0xc] = (char)param_1[5];
        param_2[0xd] = (char)(param_1[5] >> 8);
        param_2[0xe] = (char)*(undefined2 *)((int32_t)param_1 + 0x16);
        param_2[0xf] = *(undefined *)((int32_t)param_1 + 0x17);
        param_1[1] = 0;
        *param_1 = 0;
        param_1[5] = 0;
        param_1[4] = 0;
        param_1[3] = 0;
        param_1[2] = 0;
        fcn.bfc079a8(piVar3[2], piVar3[5], piVar3[6], piVar3[7]);
        piVar3[10] = unaff_s8;
        piVar3[0xb] = (int32_t)(param_1 + 0x16);
        piVar3[0xc] = 0;
        piVar3[0xd] = 0x40;
        piVar3[7] = 0;
        *(char *)(piVar3 + 8) = (char)piVar3[0xc];
        while ((uint32_t)piVar3[7] < (uint32_t)piVar3[0xd]) {
            *(undefined *)(piVar3[0xb] + piVar3[7]) = *(undefined *)(piVar3 + 8);
            piVar3[7] = piVar3[7] + 1;
        }
        return piVar3[0xb];
    }
    return in_v0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ec0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.

int32_t fcn.bfc01ec0(int32_t param_1, int32_t param_2, int32_t param_3)
{
    undefined *puVar1;
    int32_t iVar2;
    int32_t unaff_s0;
    int32_t iVar3;
    int32_t iVar4;
    int32_t in_stack_ffffffe8;
    
    iVar3 = param_3 + 1;
    puVar1 = (undefined *)malloc(param_2);
    *puVar1 = 0xd2;
    memcpy(param_3, param_2, in_stack_ffffffe8);
    iVar4 = *(int32_t *)(param_1 + 4);
    iVar2 = malloc2(unaff_s0);
    init_queue_node(iVar2, puVar1, iVar3, 0xbfc0184c);
    if (iVar2 == 0) {
        return 0;
    }
    if ((*(uint32_t *)(iVar4 + 0x10) < 0x20) && (iVar2 = add_data_block_to_linked_list(), iVar2 != 0)) {
        *(int32_t *)(iVar4 + 0x10) = *(int32_t *)(iVar4 + 0x10) + 1;
    } else {
        iVar2 = 0;
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01884 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01cf8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc028d0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b14 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03b50 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03c54 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ec0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01e28 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0210c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01d90 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u32_unaligned failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc020b4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01ba0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02008 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc025d4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04678 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_data_block_to_linked_list failed, args may be
// inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc03f3c failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07fbc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01bdc failed, args may be inaccurate.

void fcn.bfc02b48(int32_t param_1, char *param_2, uint32_t param_3)
{
    char cVar1;
    uint8_t uVar2;
    char cVar3;
    int32_t iVar4;
    int32_t *piVar5;
    undefined2 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    queue_node *pqVar10;
    undefined *puVar11;
    uint32_t uVar12;
    undefined *puVar13;
    undefined4 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    char cVar18;
    int32_t unaff_s0;
    int32_t unaff_s2;
    int32_t unaff_s3;
    int32_t unaff_s4;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    undefined *puVar22;
    int32_t *piVar23;
    int32_t *piVar24;
    undefined *puVar25;
    undefined *puVar26;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_fffffd9c;
    int32_t in_stack_fffffda0;
    int32_t in_stack_fffffda4;
    int32_t in_stack_fffffda8;
    int32_t in_stack_fffffdac;
    int32_t in_stack_ffffffd4;
    int32_t in_stack_ffffffe0;
    
    if (param_3 < 4) {
        return;
    }
    cVar3 = *param_2;
    if (cVar3 != 's') {
        if (cVar3 == -0x3d) {
            if (param_3 - 1 < 6) {
                fcn.bfc01e28(param_1, &stack0xfffffff0, 2);
            } else {
                fcn.bfc0210c(param_1, param_2 + 1);
            }
            return;
        }
        if (cVar3 != '\x17') {
            return;
        }
        if (((param_2[1] & 0xf0U) == 0x70) && (0x60 < param_3 - 1)) {
            memcpy(in_stack_fffffd9c, in_stack_fffffda0, in_stack_fffffda4);
            fcn.bfc01884(&stack0xffffff18, 0x60);
            memcpy(in_stack_fffffda4, in_stack_fffffda8, in_stack_fffffdac);
            fcn.bfc01cf8(param_1, &stack0xfffffe5c, 0x61);
            iVar15 = 0;
            iVar16 = param_1 + 0x18;
            iVar17 = 0x60;
            puVar11 = &stack0xffffff84;
            puVar13 = &stack0xfffffda0;
            do {
                puVar25 = puVar13;
                fcn.bfc028d0(param_1, puVar11 + iVar15, iVar16);
                iVar15 = iVar15 + 8;
                puVar11 = puVar25 + 0x1e8;
                puVar13 = puVar25 + 4;
            } while (iVar15 != iVar17);
            iVar15 = 0;
            iVar17 = 0x60;
            puVar13 = puVar25 + 4;
            puVar11 = puVar25;
            do {
                puVar26 = puVar13;
                fcn.bfc028d0(param_1, puVar11 + iVar15 + 0x188, iVar16);
                iVar15 = iVar15 + 8;
                puVar13 = puVar26 + 4;
                puVar11 = puVar26;
            } while (iVar15 != iVar17);
            iVar15 = 0;
            do {
                iVar16 = iVar15 + 0x128;
                iVar4 = iVar15 + 0x1e8;
                iVar17 = iVar15 + 0x188;
                iVar15 = iVar15 + 4;
                *(uint32_t *)(puVar26 + iVar16) = *(uint32_t *)(puVar26 + iVar4) ^ *(uint32_t *)(puVar26 + iVar17);
            } while (iVar15 != 0x60);
            *(undefined4 *)(puVar26 + 0x18) = *(undefined4 *)(puVar26 + 0x134);
    // esilref: 'RRL::UL SHARED SECRET[&x&x&x&x)'
            *(undefined4 *)(puVar26 + 0x14) = *(undefined4 *)(puVar26 + 0x130);
            debug_print(4, 0xa0180924, *(undefined4 *)(puVar26 + 0x128), *(undefined4 *)(puVar26 + 300));
            fcn.bfc03b14(puVar26 + 0x30);
            fcn.bfc03b50(puVar26 + 0x34, puVar26 + 0x130, 0x30);
            fcn.bfc03c54(puVar26 + 0x38, puVar26 + 0x254, 0x10);
            fcn.bfc03b14(puVar26 + 0x3c);
            fcn.bfc03b50(puVar26 + 0x40, puVar26 + 0x16c, 0x30);
            fcn.bfc03c54(puVar26 + 0x44, puVar26 + 0x270, 0x10);
            *(undefined4 *)(puVar26 + 0x44) = *(undefined4 *)(puVar26 + 0x280);
            *(undefined4 *)(puVar26 + 0x40) = *(undefined4 *)(puVar26 + 0x27c);
            *(undefined4 *)(puVar26 + 0x3c) = *(undefined4 *)(puVar26 + 0x278);
    // esilref: 'RRL::UL Negotiated security parameters MASTER KEY[&x&x&x&x] UL IV(&x&x) DL IV(&x&x)'
            *(undefined4 *)(puVar26 + 0x38) = *(undefined4 *)(puVar26 + 0x274);
            *(undefined4 *)(puVar26 + 0x34) = *(undefined4 *)(puVar26 + 0x270);
            *(undefined4 *)(puVar26 + 0x30) = *(undefined4 *)(puVar26 + 0x26c);
            debug_print(4, 0xa0180944, *(undefined4 *)(puVar26 + 0x264), *(undefined4 *)(puVar26 + 0x268));
            fcn.bfc01ec0(param_1, puVar26 + 0x268, 0x20);
            return;
        }
        return;
    }
    if (param_3 == 1) {
        return;
    }
    uVar2 = param_2[1];
    if (uVar2 == 0x52) {
        if (param_3 - 2 < 4) {
            puVar13 = &stack0xffffffc8;
        } else {
            uVar14 = u32_unaligned(param_2 + 2);
            iVar15 = fcn.bfc020b4(param_1, uVar14);
            if (iVar15 != 0) {
                puVar13 = (undefined *)malloc(in_stack_ffffffd4);
                iVar15 = fcn.bfc01bdc(iVar15, puVar13 + 3, 0x100);
                *puVar13 = 0x28;
                puVar13[1] = 0;
                puVar13[2] = (char)iVar15;
                fcn.bfc01d90(param_1, puVar13, iVar15 + 3);
                fcn.bfc03f3c(in_stack_ffffffe0);
                return;
            }
            puVar13 = &stack0xffffffd0;
        }
        fcn.bfc01d90(param_1, puVar13, 2);
        return;
    }
    if (0x52 < uVar2) {
        if (uVar2 == 0x71) {
            if (1 < param_3 - 2) {
                iVar15 = u16(param_2 + 2);
                pqVar10 = (queue_node *)malloc(unaff_s2);
                *(undefined *)&pqVar10->next = 0xe2;
                p16((int32_t)&pqVar10->next + 1, iVar15);
                memcpy(unaff_s2, unaff_s3, unaff_s4);
                fcn.bfc01d90(param_1, pqVar10, iVar15 + 3);
                fcn.bfc06d40(pqVar10, 1, unaff_retaddr, in_stack_00000000, in_stack_00000004, in_stack_00000008, 
                             unaff_s8, 1);
                return;
            }
            return;
        }
        if (uVar2 != 0x87) {
            return;
        }
        if (param_3 - 2 < 4) {
            puVar13 = &stack0xffffffe8;
        } else {
            uVar14 = u32_unaligned(param_2 + 2);
            pqVar10 = (queue_node *)fcn.bfc020b4(param_1, uVar14);
            puVar22 = &stack0xffffffe0;
            puVar21 = &stack0xffffffe0;
            uVar6 = 0x294;
            if (pqVar10 != (queue_node *)0x0) {
                if (pqVar10[7].next != 0) {
                    fcn.bfc03f3c(unaff_s0);
                    puVar21 = &stack0xffffffe4;
                }
                fcn.bfc07fbc(pqVar10);
                free(pqVar10, 0xac, *(int32_t *)(puVar21 + 0x18), *(int32_t *)(puVar21 + 0x1c));
                puVar22 = puVar21 + 8;
                uVar6 = 0x94;
            }
            *(undefined2 *)(puVar22 + 0x10) = uVar6;
            puVar13 = puVar22 + 0x10;
        }
        fcn.bfc01d90(param_1, puVar13, 2);
        return;
    }
    if (uVar2 != 0x23) {
        if (uVar2 != 0x3f) {
            return;
        }
        if (param_3 - 2 < 8) {
            uVar14 = 2;
            puVar13 = &stack0xffffffd8;
            goto code_r0xbfc02340;
        }
        uVar7 = u16(param_2 + 2);
        uVar14 = u32_unaligned(param_2 + 4);
        uVar8 = u16(param_2 + 8);
        iVar15 = fcn.bfc020b4(param_1, uVar14);
        puVar19 = &stack0xffffffd8;
        if (iVar15 == 0) {
code_r0xbfc023c4:
            p32(&stack0xffffffea, uVar14);
            puVar20 = &stack0xffffffdc;
            uVar14 = 6;
        } else {
            uVar12 = *(uint32_t *)(iVar15 + 0xa4);
            if ((uVar12 < uVar7) || (uVar12 < uVar8)) goto code_r0xbfc023c4;
            if (uVar12 < uVar8 + uVar7) {
                p32(&stack0xffffffea, uVar14);
                fcn.bfc01d90(param_1, &stack0xffffffec, 6);
                puVar19 = &stack0xffffffe0;
            }
            uVar9 = fcn.bfc01ba0(iVar15 + 0x98, uVar8, uVar7);
            *(undefined2 *)(puVar19 + 0x14) = 0x8faa;
            p32(puVar19 + 0x16, uVar14);
            p32(puVar19 + 0x1e, uVar9);
            puVar20 = puVar19 + 0xc;
            uVar14 = 10;
        }
        puVar13 = puVar20 + 0x10;
code_r0xbfc02340:
        fcn.bfc01d90(param_1, puVar13, uVar14);
        return;
    }
    param_3 = param_3 - 2;
    if (param_3 < 4) {
code_r0xbfc02654:
    // esilref: 'RRL:: AP SETUP REQUEST INVALID LENGTH, length=&d'
        debug_print(4, 0xa0180860, param_3);
        piVar23 = (int32_t *)&stack0xffffffc4;
    } else {
        uVar2 = param_2[4];
        uVar7 = (uint32_t)uVar2;
        if ((param_3 < uVar7 + 3) || ((char)uVar2 < '\0')) goto code_r0xbfc02654;
        cVar3 = param_2[2];
        cVar1 = param_2[3];
        iVar15 = fcn.bfc02008(param_1, param_2 + 5, uVar7, &stack0xffffffd8);
        if (iVar15 != 0) {
    // esilref: 'RRL:: AP SETUP REQUEST AP NAME ALREADY EXISTS'
            debug_print(4, 0xa0180894);
            piVar23 = &stack0xffffffc8;
code_r0xbfc026d8:
            p32(piVar23 + 0x12, unaff_s0);
            piVar23 = (int32_t *)(piVar23 + 4);
            uVar14 = 6;
            goto code_r0xbfc026e4;
        }
        uVar8 = fcn.bfc025d4(param_1, 0xa0180000);
        cVar18 = 'd';
        piVar5 = (int32_t *)&stack0xffffffc8;
        if (7 < uVar8) {
    // esilref: 'RRL:: AP SETUP REQUEST MAX ACCESS POINTS REACHED'
            debug_print(4, 0xa01808c4);
            piVar23 = &stack0xffffffcc;
            unaff_s0 = 8;
            goto code_r0xbfc026d8;
        }
        do {
            piVar24 = piVar5;
            uVar14 = fcn.bfc04678(*piVar24, piVar24[1], piVar24[2]);
            iVar15 = fcn.bfc020b4(param_1, uVar14);
            piVar23 = piVar24 + 2;
            cVar18 = cVar18 + -1;
            if (iVar15 == 0) {
                iVar15 = malloc2(piVar24[7]);
                zero_12bytes2(iVar15);
                *(undefined4 *)(iVar15 + 0xa0) = 0;
                *(undefined4 *)(iVar15 + 0xa4) = 0;
                uVar9 = malloc(piVar24[9]);
                *(undefined4 *)(iVar15 + 0xa8) = uVar9;
                *(undefined4 *)(iVar15 + 0x9c) = 0xbfc01b58;
                *(undefined4 *)(iVar15 + 0x98) = 0xbfc01b10;
                uVar8 = 0;
                while ((uVar8 & 0xff) < uVar7) {
                    *(char *)(iVar15 + uVar8 + 0xc) = (param_2 + 2)[uVar8 + 3];
                    uVar8 = uVar8 + 1;
                }
                *(uint8_t *)(iVar15 + 0x8c) = uVar2;
                *(undefined4 *)(iVar15 + 0x90) = uVar14;
                *(char *)(iVar15 + 0x94) = cVar3;
                *(char *)(iVar15 + 0x95) = cVar1;
                add_data_block_to_linked_list(param_1 + 0xc, iVar15);
                *(undefined2 *)(piVar24 + 10) = 0x5e;
                p32((int32_t)piVar24 + 0x2a, uVar14);
                fcn.bfc01d90(param_1, piVar24 + 0xb, 6);
    // esilref: 'RRL:: AP SETUP REQUEST CREATED NEW AP[&u]'
                debug_print(4, 0xa01808f8, uVar14);
                return;
            }
            piVar5 = piVar24 + 2;
        } while (cVar18 != '\0');
        *(undefined2 *)(piVar24 + 6) = 0x15e;
    }
    uVar14 = 2;
code_r0xbfc026e4:
    fcn.bfc01d90(param_1, (undefined *)((int32_t)piVar23 + 0x10), uVar14);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02d20 failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_4h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.

void fcn.bfc02d20(int32_t param_1, uint32_t param_2, int32_t param_3)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t in_t2;
    uint32_t uVar12;
    uint32_t uVar13;
    uint32_t in_t4;
    uint32_t uVar14;
    uint32_t uVar15;
    uint32_t in_t6;
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    uint32_t in_t8;
    uint32_t uVar24;
    uint32_t in_t9;
    uint32_t uVar25;
    uint32_t uVar26;
    int32_t iStack132;
    
    iStack132 = *(int32_t *)(param_1 + 8);
    uVar21 = *(uint32_t *)(param_1 + 0xc);
    uVar22 = *(uint32_t *)(param_1 + 0x10);
    uVar23 = *(uint32_t *)(param_1 + 0x14);
    uVar1 = param_2;
    do {
        uVar3 = uVar1 + 3 & 3;
        uVar4 = uVar1 & 3;
        uVar25 = (*(int32_t *)((uVar1 + 3) - uVar3) << (3 - uVar3) * 8 | in_t9 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)(uVar1 - uVar4) >> uVar4 * 8;
        uVar3 = ((uVar22 ^ uVar23) & uVar21 ^ uVar23) + iStack132 + -0x28955b88 + uVar25;
        *(uint32_t *)(param_1 + 0x58) = uVar25;
        uVar2 = (uVar3 * 0x80 | uVar3 >> 0x19) + uVar21;
        uVar3 = uVar1 + 7 & 3;
        uVar4 = uVar1 + 4 & 3;
        uVar12 = (*(int32_t *)((uVar1 + 7) - uVar3) << (3 - uVar3) * 8 | in_t2 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 4) - uVar4) >> uVar4 * 8;
        uVar4 = ((uVar21 ^ uVar22) & uVar2 ^ uVar22) + uVar23 + 0xe8c7b756 + uVar12;
        *(uint32_t *)(param_1 + 0x5c) = uVar12;
        uVar5 = uVar4 >> 0x14;
        uVar3 = uVar1 + 0xb & 3;
        uVar8 = (uVar4 * 0x1000 | uVar5) + uVar2;
        uVar4 = uVar1 + 8 & 3;
        uVar5 = (*(int32_t *)((uVar1 + 0xb) - uVar3) << (3 - uVar3) * 8 | uVar5 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 8) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(param_1 + 0x60) = uVar5;
        uVar3 = ((uVar2 ^ uVar21) & uVar8 ^ uVar21) + uVar22 + 0x242070db + uVar5;
        uVar6 = (uVar3 >> 0xf | uVar3 * 0x20000) + uVar8;
        uVar3 = uVar1 + 0xf & 3;
        uVar4 = uVar1 + 0xc & 3;
        uVar14 = (*(int32_t *)((uVar1 + 0xf) - uVar3) << (3 - uVar3) * 8 | in_t4 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0xc) - uVar4) >> uVar4 * 8;
        uVar4 = ((uVar2 ^ uVar8) & uVar6 ^ uVar2) + uVar21 + 0xc1bdceee + uVar14;
        *(uint32_t *)(param_1 + 100) = uVar14;
        uVar9 = uVar4 * 0x400000;
        uVar3 = uVar1 + 0x13 & 3;
        uVar7 = (uVar4 >> 10 | uVar9) + uVar6;
        uVar4 = uVar1 + 0x10 & 3;
        uVar9 = (*(int32_t *)((uVar1 + 0x13) - uVar3) << (3 - uVar3) * 8 | uVar9 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x10) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(param_1 + 0x68) = uVar9;
        uVar3 = uVar1 + 0x17 & 3;
        uVar2 = ((uVar8 ^ uVar6) & uVar7 ^ uVar8) + uVar9 + 0xf57c0faf + uVar2;
        uVar4 = uVar1 + 0x14 & 3;
        uVar16 = (*(int32_t *)((uVar1 + 0x17) - uVar3) << (3 - uVar3) * 8 | in_t6 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x14) - uVar4) >> uVar4 * 8;
        uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar7;
        uVar8 = uVar16 + 0x4787c62a + uVar8;
        *(uint32_t *)(param_1 + 0x6c) = uVar16;
        uVar10 = ((uVar6 ^ uVar7) & uVar2 ^ uVar6) + uVar8;
        uVar3 = uVar1 + 0x1b & 3;
        uVar4 = uVar1 + 0x18 & 3;
        uVar8 = (*(int32_t *)((uVar1 + 0x1b) - uVar3) << (3 - uVar3) * 8 | uVar8 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x18) - uVar4) >> uVar4 * 8;
        uVar10 = (uVar10 * 0x1000 | uVar10 >> 0x14) + uVar2;
        *(uint32_t *)(param_1 + 0x70) = uVar8;
        uVar3 = uVar1 + 0x1f & 3;
        uVar6 = ((uVar7 ^ uVar2) & uVar10 ^ uVar7) + uVar8 + 0xa8304613 + uVar6;
        uVar4 = uVar1 + 0x1c & 3;
        uVar24 = (*(int32_t *)((uVar1 + 0x1f) - uVar3) << (3 - uVar3) * 8 | in_t8 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x1c) - uVar4) >> uVar4 * 8;
        uVar6 = (uVar6 >> 0xf | uVar6 * 0x20000) + uVar10;
        *(uint32_t *)(param_1 + 0x74) = uVar24;
        uVar3 = uVar1 + 0x23 & 3;
        uVar7 = ((uVar2 ^ uVar10) & uVar6 ^ uVar2) + uVar24 + 0xfd469501 + uVar7;
        uVar4 = uVar1 + 0x20 & 3;
        uVar11 = (*(int32_t *)((uVar1 + 0x23) - uVar3) << (3 - uVar3) * 8 |
                 uVar24 + 0xfd469501 & 0xffffffffU >> (uVar3 + 1) * 8) & -1 << (4 - uVar4) * 8 |
                 *(uint32_t *)((uVar1 + 0x20) - uVar4) >> uVar4 * 8;
        uVar15 = (uVar7 >> 10 | uVar7 * 0x400000) + uVar6;
        uVar2 = uVar11 + 0x698098d8 + uVar2;
        *(uint32_t *)(param_1 + 0x78) = uVar11;
        uVar4 = ((uVar10 ^ uVar6) & uVar15 ^ uVar10) + uVar2;
        uVar3 = uVar1 + 0x27 & 3;
        uVar7 = (uVar4 * 0x80 | uVar4 >> 0x19) + uVar15;
        uVar4 = uVar1 + 0x24 & 3;
        uVar2 = (*(int32_t *)((uVar1 + 0x27) - uVar3) << (3 - uVar3) * 8 | uVar2 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x24) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(param_1 + 0x7c) = uVar2;
        uVar10 = ((uVar6 ^ uVar15) & uVar7 ^ uVar6) + uVar2 + 0x8b44f7af + uVar10;
        uVar3 = uVar1 + 0x2b & 3;
        uVar4 = uVar1 + 0x28 & 3;
        uVar13 = (*(int32_t *)((uVar1 + 0x2b) - uVar3) << (3 - uVar3) * 8 |
                 uVar2 + 0x8b44f7af & 0xffffffffU >> (uVar3 + 1) * 8) & -1 << (4 - uVar4) * 8 |
                 *(uint32_t *)((uVar1 + 0x28) - uVar4) >> uVar4 * 8;
        uVar17 = (uVar10 * 0x1000 | uVar10 >> 0x14) + uVar7;
        uVar6 = (uVar13 - 0xa44f) + uVar6;
        *(uint32_t *)(param_1 + 0x80) = uVar13;
        uVar10 = ((uVar15 ^ uVar7) & uVar17 ^ uVar15) + uVar6;
        uVar3 = uVar1 + 0x2f & 3;
        uVar4 = uVar1 + 0x2c & 3;
        uVar6 = (*(int32_t *)((uVar1 + 0x2f) - uVar3) << (3 - uVar3) * 8 | uVar6 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x2c) - uVar4) >> uVar4 * 8;
        uVar10 = (uVar10 >> 0xf | uVar10 * 0x20000) + uVar17;
        *(uint32_t *)(param_1 + 0x84) = uVar6;
        uVar15 = uVar6 + 0x895cd7be + uVar15;
        uVar18 = ((uVar7 ^ uVar17) & uVar10 ^ uVar7) + uVar15;
        uVar3 = uVar1 + 0x33 & 3;
        uVar4 = uVar1 + 0x30 & 3;
        uVar15 = (*(int32_t *)((uVar1 + 0x33) - uVar3) << (3 - uVar3) * 8 | uVar15 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x30) - uVar4) >> uVar4 * 8;
        uVar19 = (uVar18 >> 10 | uVar18 * 0x400000) + uVar10;
        uVar7 = uVar15 + 0x6b901122 + uVar7;
        *(uint32_t *)(param_1 + 0x88) = uVar15;
        uVar4 = ((uVar17 ^ uVar10) & uVar19 ^ uVar17) + uVar7;
        uVar3 = uVar1 + 0x37 & 3;
        uVar18 = (uVar4 * 0x80 | uVar4 >> 0x19) + uVar19;
        uVar4 = uVar1 + 0x34 & 3;
        uVar7 = (*(int32_t *)((uVar1 + 0x37) - uVar3) << (3 - uVar3) * 8 | uVar7 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x34) - uVar4) >> uVar4 * 8;
        *(uint32_t *)(param_1 + 0x8c) = uVar7;
        uVar17 = uVar7 + 0xfd987193 + uVar17;
        uVar20 = ((uVar10 ^ uVar19) & uVar18 ^ uVar10) + uVar17;
        uVar3 = uVar1 + 0x3b & 3;
        uVar4 = uVar1 + 0x38 & 3;
        uVar17 = (*(int32_t *)((uVar1 + 0x3b) - uVar3) << (3 - uVar3) * 8 | uVar17 & 0xffffffffU >> (uVar3 + 1) * 8) &
                 -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x38) - uVar4) >> uVar4 * 8;
        uVar26 = (uVar20 * 0x1000 | uVar20 >> 0x14) + uVar18;
        *(uint32_t *)(param_1 + 0x90) = uVar17;
        uVar10 = uVar17 + 0xa679438e + uVar10;
        uVar20 = ((uVar19 ^ uVar18) & uVar26 ^ uVar19) + uVar10;
        uVar3 = uVar1 + 0x3f & 3;
        uVar4 = uVar1 + 0x3c & 3;
        uVar3 = (*(int32_t *)((uVar1 + 0x3f) - uVar3) << (3 - uVar3) * 8 | uVar10 & 0xffffffffU >> (uVar3 + 1) * 8) &
                -1 << (4 - uVar4) * 8 | *(uint32_t *)((uVar1 + 0x3c) - uVar4) >> uVar4 * 8;
        uVar20 = (uVar20 >> 0xf | uVar20 * 0x20000) + uVar26;
        uVar4 = ((uVar18 ^ uVar26) & uVar20 ^ uVar18) + uVar3 + 0x49b40821 + uVar19;
        uVar19 = (uVar4 >> 10 | uVar4 * 0x400000) + uVar20;
        uVar4 = ((uVar20 ^ uVar19) & uVar26 ^ uVar20) + uVar12 + 0xf61e2562 + uVar18;
        uVar10 = (uVar4 * 0x20 | uVar4 >> 0x1b) + uVar19;
        uVar4 = ((uVar19 ^ uVar10) & uVar20 ^ uVar19) + uVar8 + 0xc040b340 + uVar26;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar18 = ((uVar10 ^ uVar4) & uVar19 ^ uVar10) + uVar6 + 0x265e5a51 + uVar20;
        uVar20 = (uVar18 * 0x4000 | uVar18 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar20) & uVar10 ^ uVar4) + uVar25 + 0xe9b6c7aa + uVar19;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar20;
        uVar10 = ((uVar20 ^ uVar18) & uVar4 ^ uVar20) + uVar16 + 0xd62f105d + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar20 ^ uVar18) + uVar13 + 0x2441453 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar3 + 0xd8a1e681 + uVar20;
        uVar19 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar19) & uVar10 ^ uVar4) + uVar9 + 0xe7d3fbc8 + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar19;
        uVar10 = ((uVar19 ^ uVar18) & uVar4 ^ uVar19) + uVar2 + 0x21e1cde6 + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar19 ^ uVar18) + uVar17 + 0xc33707d6 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar14 + 0xf4d50d87 + uVar19;
        uVar19 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar19) & uVar10 ^ uVar4) + uVar11 + 0x455a14ed + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar19;
        uVar10 = ((uVar19 ^ uVar18) & uVar4 ^ uVar19) + uVar7 + 0xa9e3e905 + uVar10;
        uVar10 = (uVar10 * 0x20 | uVar10 >> 0x1b) + uVar18;
        uVar4 = ((uVar18 ^ uVar10) & uVar19 ^ uVar18) + uVar5 + 0xfcefa3f8 + uVar4;
        uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar10;
        uVar19 = ((uVar10 ^ uVar4) & uVar18 ^ uVar10) + uVar24 + 0x676f02d9 + uVar19;
        uVar20 = (uVar19 * 0x4000 | uVar19 >> 0x12) + uVar4;
        uVar18 = ((uVar4 ^ uVar20) & uVar10 ^ uVar4) + uVar15 + 0x8d2a4c8a + uVar18;
        uVar18 = (uVar18 >> 0xc | uVar18 * 0x100000) + uVar20;
        uVar10 = (uVar16 - 0x5c6be) + uVar10 + (uVar4 ^ uVar20 ^ uVar18);
        uVar19 = (uVar10 * 0x10 | uVar10 >> 0x1c) + uVar18;
        uVar4 = uVar11 + 0x8771f681 + uVar4 + (uVar20 ^ uVar18 ^ uVar19);
        uVar10 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar19;
        uVar4 = uVar6 + 0x6d9d6122 + uVar20 + (uVar18 ^ uVar19 ^ uVar10);
        uVar4 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar18 = uVar17 + 0xfde5380c + uVar18 + (uVar19 ^ uVar10 ^ uVar4);
        uVar18 = (uVar18 >> 9 | uVar18 * 0x800000) + uVar4;
        uVar19 = uVar12 + 0xa4beea44 + uVar19 + (uVar10 ^ uVar4 ^ uVar18);
        uVar19 = (uVar19 * 0x10 | uVar19 >> 0x1c) + uVar18;
        uVar10 = uVar9 + 0x4bdecfa9 + uVar10 + (uVar4 ^ uVar18 ^ uVar19);
        uVar10 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar19;
        uVar4 = uVar24 + 0xf6bb4b60 + uVar4 + (uVar18 ^ uVar19 ^ uVar10);
        uVar4 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar18 = uVar13 + 0xbebfbc70 + uVar18 + (uVar19 ^ uVar10 ^ uVar4);
        uVar20 = (uVar18 >> 9 | uVar18 * 0x800000) + uVar4;
        uVar18 = uVar7 + 0x289b7ec6 + uVar19 + (uVar10 ^ uVar4 ^ uVar20);
        uVar18 = (uVar18 * 0x10 | uVar18 >> 0x1c) + uVar20;
        uVar10 = uVar25 + 0xeaa127fa + uVar10 + (uVar4 ^ uVar20 ^ uVar18);
        uVar10 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar18;
        uVar4 = uVar14 + 0xd4ef3085 + uVar4 + (uVar20 ^ uVar18 ^ uVar10);
        uVar19 = (uVar4 * 0x10000 | uVar4 >> 0x10) + uVar10;
        uVar4 = uVar8 + 0x4881d05 + uVar20 + (uVar18 ^ uVar10 ^ uVar19);
        uVar4 = (uVar4 >> 9 | uVar4 * 0x800000) + uVar19;
        uVar18 = uVar2 + 0xd9d4d039 + uVar18 + (uVar10 ^ uVar19 ^ uVar4);
        uVar18 = (uVar18 * 0x10 | uVar18 >> 0x1c) + uVar4;
        uVar10 = uVar15 + 0xe6db99e5 + uVar10 + (uVar19 ^ uVar4 ^ uVar18);
        uVar20 = (uVar10 * 0x800 | uVar10 >> 0x15) + uVar18;
        uVar10 = uVar3 + 0x1fa27cf8 + uVar19 + (uVar4 ^ uVar18 ^ uVar20);
        uVar10 = (uVar10 * 0x10000 | uVar10 >> 0x10) + uVar20;
        uVar4 = uVar5 + 0xc4ac5665 + uVar4 + (uVar18 ^ uVar20 ^ uVar10);
        uVar4 = (uVar4 >> 9 | uVar4 * 0x800000) + uVar10;
        uVar18 = ((~uVar20 | uVar4) ^ uVar10) + uVar25 + 0xf4292244 + uVar18;
        uVar18 = (uVar18 * 0x40 | uVar18 >> 0x1a) + uVar4;
        uVar19 = ((~uVar10 | uVar18) ^ uVar4) + uVar24 + 0x432aff97 + uVar20;
        uVar19 = (uVar19 * 0x400 | uVar19 >> 0x16) + uVar18;
        uVar10 = ((~uVar4 | uVar19) ^ uVar18) + uVar17 + 0xab9423a7 + uVar10;
        uVar17 = (uVar10 * 0x8000 | uVar10 >> 0x11) + uVar19;
        uVar4 = ((~uVar18 | uVar17) ^ uVar19) + uVar16 + 0xfc93a039 + uVar4;
        uVar16 = (uVar4 >> 0xb | uVar4 * 0x200000) + uVar17;
        uVar4 = ((~uVar19 | uVar16) ^ uVar17) + uVar15 + 0x655b59c3 + uVar18;
        uVar15 = (uVar4 * 0x40 | uVar4 >> 0x1a) + uVar16;
        uVar4 = ((~uVar17 | uVar15) ^ uVar16) + uVar14 + 0x8f0ccc92 + uVar19;
        uVar10 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar15;
        uVar4 = ((~uVar16 | uVar10) ^ uVar15) + (uVar13 - 0x100b83) + uVar17;
        uVar13 = (uVar4 * 0x8000 | uVar4 >> 0x11) + uVar10;
        uVar4 = ((~uVar15 | uVar13) ^ uVar10) + uVar12 + 0x85845dd1 + uVar16;
        in_t9 = uVar4 >> 0xb;
        uVar12 = (in_t9 | uVar4 * 0x200000) + uVar13;
        uVar4 = ((~uVar10 | uVar12) ^ uVar13) + uVar11 + 0x6fa87e4f + uVar15;
        in_t8 = uVar4 * 0x40;
        uVar4 = (in_t8 | uVar4 >> 0x1a) + uVar12;
        *(uint32_t *)(param_1 + 0x94) = uVar3;
        uVar3 = ((~uVar13 | uVar4) ^ uVar12) + uVar3 + 0xfe2ce6e0 + uVar10;
        uVar10 = (uVar3 * 0x400 | uVar3 >> 0x16) + uVar4;
        uVar3 = ((~uVar12 | uVar10) ^ uVar4) + uVar8 + 0xa3014314 + uVar13;
        in_t6 = uVar3 * 0x8000;
        uVar8 = (in_t6 | uVar3 >> 0x11) + uVar10;
        uVar3 = ((~uVar4 | uVar8) ^ uVar10) + uVar7 + 0x4e0811a1 + uVar12;
        uVar7 = (uVar3 >> 0xb | uVar3 * 0x200000) + uVar8;
        uVar3 = ((~uVar10 | uVar7) ^ uVar8) + uVar9 + 0xf7537e82 + uVar4;
        uVar4 = (uVar3 * 0x40 | uVar3 >> 0x1a) + uVar7;
        uVar3 = ((~uVar8 | uVar4) ^ uVar7) + uVar6 + 0xbd3af235 + uVar10;
        in_t4 = uVar3 * 0x400;
        in_t2 = (in_t4 | uVar3 >> 0x16) + uVar4;
        uVar3 = ((~uVar7 | in_t2) ^ uVar4) + uVar5 + 0x2ad7d2bb + uVar8;
        iStack132 = iStack132 + uVar4;
        uVar3 = (uVar3 * 0x8000 | uVar3 >> 0x11) + in_t2;
        uVar4 = ((~uVar4 | uVar3) ^ in_t2) + uVar2 + 0xeb86d391 + uVar7;
        uVar22 = uVar22 + uVar3;
        uVar1 = uVar1 + 0x40;
        uVar21 = uVar21 + (uVar4 >> 0xb | uVar4 * 0x200000) + uVar3;
        uVar23 = uVar23 + in_t2;
    } while (uVar1 != param_2 + param_3);
    *(uint32_t *)(param_1 + 0xc) = uVar21;
    *(uint32_t *)(param_1 + 0x10) = uVar22;
    *(uint32_t *)(param_1 + 0x14) = uVar23;
    *(int32_t *)(param_1 + 8) = iStack132;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc041a0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.

uint32_t fcn.bfc041a0(uint32_t *param_1, uint32_t param_2)
{
    uint32_t uVar1;
    uint32_t in_v0;
    int32_t in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    
    if (param_2 != 0) {
        if ((param_2 < *param_1) || (*param_1 + 0x10000 < param_2)) {
            uVar1 = fcn.bfc05988(in_stack_fffffbec, in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, 
                                 in_stack_fffffbfc, in_stack_fffffc00, in_stack_fffffc04, in_stack_fffffc08, 
                                 in_stack_fffffc0c, in_stack_fffffc10, in_stack_fffffc14, in_stack_fffffc18, 
                                 in_stack_fffffc1c, in_stack_fffffc20, in_stack_fffffc24, in_stack_fffffc28, 
                                 in_stack_fffffc2c, in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84);
            fcn.bfc065f8(in_stack_fffffbf0, in_stack_fffffbf4, in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, 
                         in_stack_00000c0c);
            return uVar1;
        }
        uVar1 = param_1[1];
        *(uint32_t *)(param_2 + 8) = uVar1;
        *(uint32_t *)(uVar1 + 0xc) = param_2;
        uVar1 = param_1[2];
        *(undefined4 *)(param_2 + 0xc) = 0;
        param_1[2] = uVar1 + 1;
        param_1[1] = param_2;
        in_v0 = param_1[3] - 1;
        param_1[3] = in_v0;
    }
    return in_v0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc040f4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.

int32_t fcn.bfc040f4(int32_t param_1, undefined param_2, undefined4 param_3, undefined param_4)
{
    int32_t iVar1;
    int32_t unaff_s0;
    int32_t iVar2;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    iVar2 = 0;
    if ((*(int32_t *)(param_1 + 8) != 0) && (iVar2 = *(int32_t *)(param_1 + 4), iVar2 != 0)) {
        iVar1 = *(int32_t *)(iVar2 + 8);
        *(int32_t *)(param_1 + 4) = iVar1;
        *(undefined4 *)(iVar1 + 0xc) = 0;
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0xc) = 0;
        memcpy(in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0);
        *(undefined *)(iVar2 + 4) = param_4;
        *(undefined *)(iVar2 + 5) = param_2;
        *(int32_t *)(param_1 + 8) = *(int32_t *)(param_1 + 8) + -1;
        *(int32_t *)(param_1 + 0xc) = *(int32_t *)(param_1 + 0xc) + 1;
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc043c0 failed, args may be inaccurate.

int16_t fcn.bfc043c0(int32_t param_1)
{
    int16_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    
    iVar1 = 0;
    uVar2 = 0;
    iVar3 = 4;
    do {
        iVar3 = *(int32_t *)(param_1 + iVar3 * 4);
        if (iVar3 != 0) {
            iVar1 = iVar1 + (uint16_t)*(uint8_t *)(iVar3 + 4);
        }
        uVar2 = uVar2 + 1 & 0xff;
        iVar3 = uVar2 + 4;
    } while (uVar2 <= *(uint8_t *)(param_1 + 0x52));
    return iVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04990 failed, args may be inaccurate.

undefined4 fcn.bfc04990(int32_t arg_8h)
{
    undefined4 in_a0;
    
    do {
    } while ((**(uint32_t **)0xa0180064 & 2) == 0);
    **(undefined4 **)0xa0180060 = in_a0;
    return in_a0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07284 failed, args may be inaccurate.

undefined4 fcn.bfc07284(int32_t arg_8h)
{
    undefined4 uVar1;
    int32_t in_a0;
    
    if ((in_a0 < 0x30) || (0x39 < in_a0)) {
        uVar1 = 0;
    } else {
        uVar1 = 1;
    }
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07a34 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc071f0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07284 failed, args may be inaccurate.

int32_t fcn.bfc07a34(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_1ch, int32_t arg_28h)
{
    int32_t iVar1;
    char *in_a0;
    undefined *puVar2;
    undefined *puVar3;
    char *pcStackX0;
    undefined auStack40 [4];
    int32_t aiStack36 [4];
    int32_t iStack20;
    int32_t iStack16;
    int32_t iStack12;
    
    if (in_a0 == (char *)0x0) {
        iStack20 = 0;
    } else {
        aiStack36[3] = 0;
        iStack20 = 1;
        iStack12 = 0;
        puVar2 = auStack40;
        pcStackX0 = in_a0;
        while( true ) {
            iVar1 = fcn.bfc071f0(*(int32_t *)(puVar2 + 4));
            puVar3 = puVar2 + 4;
            if (iVar1 == 0) break;
            pcStackX0 = pcStackX0 + 1;
            puVar2 = puVar2 + 4;
        }
        iStack16 = 0;
        while (*pcStackX0 != '\0') {
            if (*pcStackX0 == '-') {
                if (iStack16 != 0) {
                    return 0;
                }
                iStack20 = -1;
                iStack16 = 1;
            } else {
                if (*pcStackX0 == '+') {
                    if (iStack16 != 0) {
                        return 0;
                    }
                    iStack16 = 1;
                } else {
                    iVar1 = fcn.bfc07284(*(int32_t *)(puVar3 + 4));
                    puVar3 = puVar3 + 4;
                    if (iVar1 == 0) break;
                    if ((iStack16 != 0) && (iStack16 != 1)) {
                        return 0;
                    }
                    iStack16 = 1;
                    aiStack36[3] = aiStack36[3] * 10 + *pcStackX0 + -0x30;
                    iStack12 = iStack12 + 1;
                    if (iStack12 == 9) break;
                }
            }
            iStack16 = 1;
            pcStackX0 = pcStackX0 + 1;
        }
        iStack20 = iStack20 * aiStack36[3];
    }
    return iStack20;
}

// WARNING: Removing unreachable block (ram,0xbfc04a30)
// WARNING: Removing unreachable block (ram,0xbfc04a6c)
// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc049ec failed, args may be inaccurate.

void fcn.bfc049ec(int32_t arg_4h, int32_t arg_8h, int32_t arg_30h, int32_t arg_34h)
{
    int32_t in_a0;
    int32_t in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    int32_t arg_0h;
    
    pcStack48 = acStack40;
    iStack44 = 0;
    arg_4h = in_a0;
    if (in_a1 != 0) {
        do {
            *pcStack48 = (char)((uint32_t)arg_4h % 10) + '0';
            arg_4h = (uint32_t)arg_4h / 10;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
            arg_8h = in_a1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Removing unreachable block (ram,0xbfc04bb0)
// WARNING: Removing unreachable block (ram,0xbfc04bec)
// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04b30 failed, args may be inaccurate.

void fcn.bfc04b30(int32_t arg_4h, int32_t arg_8h, int32_t arg_30h, int32_t arg_34h)
{
    int32_t in_a0;
    undefined *in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    int32_t arg_0h;
    
    pcStack48 = acStack40;
    iStack44 = 0;
    if (in_a1 != (undefined *)0x0) {
        arg_4h = in_a0;
        arg_8h = (int32_t)in_a1;
        if (in_a0 < 0) {
            *in_a1 = 0x2d;
            arg_8h = (int32_t)(in_a1 + 1);
            arg_4h = -in_a0;
        }
        do {
            *pcStack48 = (char)(arg_4h % 10) + '0';
            arg_4h = arg_4h / 10;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc04cb0 failed, args may be inaccurate.

void fcn.bfc04cb0(int32_t arg_4h, int32_t arg_8h, int32_t arg_30h, int32_t arg_34h)
{
    int32_t in_a0;
    int32_t in_a1;
    char *pcStack48;
    int32_t iStack44;
    char acStack40 [36];
    int32_t arg_0h;
    
    pcStack48 = acStack40;
    iStack44 = 0;
    arg_4h = in_a0;
    if (in_a1 != 0) {
        do {
            *pcStack48 = ((uint8_t)arg_4h & 0xf) + 0x30;
            if ('9' < *pcStack48) {
                *pcStack48 = *pcStack48 + '\a';
            }
            arg_4h = (uint32_t)arg_4h >> 4;
            pcStack48 = pcStack48 + 1;
            iStack44 = iStack44 + 1;
            arg_8h = in_a1;
        } while (arg_4h != 0);
        while (0 < iStack44) {
            pcStack48 = pcStack48 + -1;
            *(char *)arg_8h = *pcStack48;
            arg_8h = arg_8h + 1;
            iStack44 = iStack44 + -1;
        }
        *(undefined *)arg_8h = 0;
    }
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06740 failed, args may be inaccurate.

int32_t * fcn.bfc06740(int32_t arg_4h, int32_t arg_8h, int32_t arg_ch, int32_t arg_18h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    int32_t in_a0;
    uint32_t uStack24;
    int32_t arg_0h;
    
    piVar1 = *(int32_t **)0xa0180070;
    uStack24 = in_a0 + 4;
    if ((uStack24 & 0xfff) != 0) {
        uStack24 = ((uStack24 >> 0xc) + 1) * 0x1000;
    }
    puVar3 = (undefined4 *)((int32_t)*(int32_t **)0xa0180070 + (uStack24 - 8));
    iVar2 = (int32_t)*(int32_t **)0xa0180070 + uStack24;
    **(int32_t **)0xa0180070 = uStack24 - 4;
    *(int32_t *)0xa0180070 = (int32_t *)iVar2;
    puVar3[1] = 0;
    *puVar3 = *(undefined4 *)0xa0180d90;
    *(int32_t **)0xa0180d90 = piVar1;
    return piVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07830 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07770 failed, args may be inaccurate.

uint32_t fcn.bfc07830(int32_t arg_10h, int32_t arg_14h, int32_t arg_18h, int32_t arg_28h, int32_t arg_2ch,
                     int32_t arg_30h)
{
    int32_t in_a0;
    char in_a1;
    uint32_t in_a2;
    int32_t in_stack_ffffffdc;
    uint32_t uStack24;
    
    uStack24 = 0;
    while ((uStack24 < in_a2 && (*(undefined *)(in_a0 + uStack24) = 0, in_a1 != '\0'))) {
        *(undefined *)(in_a0 + uStack24) = 0;
        uStack24 = uStack24 + 1;
    }
    if (uStack24 == in_a2) {
        fcn.bfc07770(in_stack_ffffffdc);
    }
    return uStack24;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07770 failed, args may be inaccurate.

undefined4 fcn.bfc07770(int32_t arg_8h)
{
    return 0;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc071f0 failed, args may be inaccurate.

undefined4 fcn.bfc071f0(int32_t arg_8h)
{
    undefined4 uVar1;
    int32_t in_a0;
    
    if ((((in_a0 == 0x20) || (in_a0 == 9)) || (in_a0 == 10)) || (((in_a0 == 0xb || (in_a0 == 0xc)) || (in_a0 == 0xd))))
    {
        uVar1 = 1;
    } else {
        uVar1 = 0;
    }
    return uVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07f9c failed, args may be inaccurate.

undefined4 fcn.bfc07f9c(int32_t *param_1)
{
    undefined4 uVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    
    if ((int32_t *)param_1[2] != (int32_t *)0x0) {
        uVar1 = 0;
        if ((param_1 != (int32_t *)0x0) && (piVar3 = (int32_t *)param_1[2], piVar3 == (int32_t *)param_1[2])) {
            iVar4 = *param_1;
            if (iVar4 != 0) {
                *(int32_t *)(iVar4 + 4) = param_1[1];
            }
            piVar2 = (int32_t *)param_1[1];
            if (piVar2 != (int32_t *)0x0) {
                *piVar2 = iVar4;
            }
            if (param_1 == (int32_t *)piVar3[2]) {
                piVar3[2] = (int32_t)piVar2;
            }
            if (param_1 == (int32_t *)piVar3[1]) {
                piVar3[1] = *param_1;
            }
            iVar4 = *piVar3;
            param_1[2] = 0;
            *piVar3 = iVar4 + -1;
            uVar1 = 1;
        }
        return uVar1;
    }
    return 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function write_output failed, args may be inaccurate.

int32_t write_output(int32_t param_1, int32_t param_2, int32_t param_3)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 & 0xffffdfff, 0);
    iVar1 = 0;
    while( true ) {
        if (iVar1 == param_3) {
            if ((**(uint32_t **)0xa0180088 & 6) == 2) {
                **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 4;
            }
            setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x2001, 0);
            return iVar1;
        }
        uVar2 = *(uint32_t *)(param_1 + 0x100c);
        if (0x800 < uVar2) break;
        iVar4 = *(int32_t *)(param_1 + 0x1010);
        uVar3 = iVar4 + 1;
        *(uint32_t *)(param_1 + 0x1010) = uVar3;
        *(undefined *)(param_1 + iVar4 + 0x800) = *(undefined *)(param_2 + iVar1);
        if (0x7ff < uVar3) {
            *(undefined4 *)(param_1 + 0x1010) = 0;
        }
        iVar1 = iVar1 + 1;
        *(uint32_t *)(param_1 + 0x100c) = uVar2 + 1;
    }
    return -1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function crc16 failed, args may be inaccurate.

uint32_t crc16(undefined4 param_1, uint8_t *param_2, int32_t param_3)
{
    uint32_t uVar1;
    char cVar2;
    uint32_t uVar3;
    uint8_t *puVar4;
    uint32_t uVar5;
    
    uVar1 = 0;
    if (param_3 != 0) {
        uVar1 = 0xffff;
        puVar4 = param_2;
        do {
            puVar4 = puVar4 + 1;
            uVar3 = (uint32_t)*puVar4;
            cVar2 = '\b';
            do {
                uVar5 = uVar3 ^ uVar1;
                uVar1 = uVar1 >> 1;
                if ((uVar5 & 1) != 0) {
                    uVar1 = uVar1 ^ 0x8408;
                }
                cVar2 = cVar2 + -1;
                uVar3 = uVar3 >> 1;
            } while (cVar2 != '\0');
            puVar4 = puVar4;
        } while (puVar4 != param_2 + param_3);
        uVar1 = ~uVar1 >> 8 & 0xff | (~uVar1 & 0xff) << 8;
    }
    return uVar1;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function init_pdu_pool failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

int32_t init_pdu_pool(int32_t param_1, undefined4 param_2)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t unaff_s0;
    int32_t unaff_s2;
    int32_t in_stack_00000008;
    int32_t in_stack_0000000c;
    
    // esilref: 'CMac::SendRLLDataBlockSizeUpdate::newDataBlockSize=&u
    // '
    debug_print(4, 0xa0180ac0, param_2);
    puVar1 = (undefined *)malloc(unaff_s0);
    uVar3 = *(undefined4 *)(param_1 + 0x28);
    *puVar1 = 0x31;
    p32(puVar1 + 1, uVar3);
    puVar1[5] = (char)param_2;
    queue_node = (queue_node *)malloc2(unaff_s2);
    init_queue_node(queue_node, puVar1, 6, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(param_1 + 0x34), queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        iVar2 = in_stack_00000008;
        free(queue_node, 0x18, in_stack_00000008, in_stack_0000000c);
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function current_time_passed failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function time_passed failed, args may be inaccurate.

void current_time_passed(int32_t param_1)
{
    undefined4 uVar1;
    
    uVar1 = time_passed(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x28) = uVar1;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function check_for_input failed, args may be inaccurate.

bool check_for_input(int32_t param_1)
{
    return *(int32_t *)(param_1 + 0x1000) != 0;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function take_input failed, args may be inaccurate.

void take_input(int32_t param_1, int32_t param_2, int32_t param_3)
{
    int32_t iVar1;
    int32_t iVar2;
    
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 & 0xffffefff, 0);
    iVar1 = 0;
    while ((*(int32_t *)(param_1 + 0x1000) != 0 && (param_3 != iVar1))) {
        iVar2 = *(int32_t *)(param_1 + 0x1008);
        *(int32_t *)(param_1 + 0x1008) = iVar2 + 1;
        *(undefined *)(param_2 + iVar1) = *(undefined *)(param_1 + iVar2);
        if (0x7ff < *(uint32_t *)(param_1 + 0x1008)) {
            *(undefined4 *)(param_1 + 0x1008) = 0;
        }
        iVar1 = iVar1 + 1;
        *(int32_t *)(param_1 + 0x1000) = *(int32_t *)(param_1 + 0x1000) + -1;
    }
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x1001, 0);
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function enqueue_data_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

int32_t enqueue_data_block(int32_t param_1, undefined4 param_2, int32_t param_3)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t in_stack_00000000;
    int32_t in_stack_00000004;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffe8;
    
    puVar1 = (undefined *)malloc(in_stack_ffffffe4);
    uVar3 = *(undefined4 *)(param_1 + 0x28);
    *puVar1 = 0x37;
    p32(puVar1 + 1, uVar3);
    memcpy(in_stack_ffffffe4, in_stack_ffffffe8, unaff_s0);
    queue_node = (queue_node *)malloc2(unaff_s1);
    init_queue_node(queue_node, puVar1, param_3 + 5, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(param_1 + 0x34), queue_node);
    if (iVar2 == 0) {
    // new struct will be purged
        destruct_queue_node(queue_node);
        iVar2 = in_stack_00000000;
        free(queue_node, 0x18, in_stack_00000000, in_stack_00000004);
    }
    return iVar2;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function write_data_block? failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u32_unaligned failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function crc16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function write_output failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

uint32_t write_data_block?(mac_struct *mac_struct, queue_data_chunk *data_chunk, uint32_t chunk_len,
                          uint32_t default_len)
{
    uint32_t uVar1;
    undefined *puVar2;
    undefined4 uVar3;
    undefined *puVar4;
    int32_t unaff_s0;
    int32_t unaff_s1;
    int32_t unaff_s2;
    undefined *puVar5;
    undefined4 unaff_s8;
    char in_stack_00000010;
    int32_t in_stack_00000c00;
    int32_t in_stack_00000c04;
    int32_t in_stack_00000c08;
    int32_t in_stack_00000c0c;
    int32_t in_stack_fffffbec;
    int32_t in_stack_fffffbf0;
    int32_t in_stack_fffffbf4;
    int32_t in_stack_fffffbf8;
    int32_t in_stack_fffffbfc;
    int32_t in_stack_fffffc00;
    int32_t in_stack_fffffc04;
    int32_t in_stack_fffffc08;
    int32_t in_stack_fffffc0c;
    int32_t in_stack_fffffc10;
    int32_t in_stack_fffffc14;
    int32_t in_stack_fffffc18;
    int32_t in_stack_fffffc1c;
    int32_t in_stack_fffffc20;
    int32_t in_stack_fffffc24;
    int32_t in_stack_fffffc28;
    int32_t in_stack_fffffc2c;
    int32_t in_stack_fffffc7c;
    int32_t in_stack_fffffc80;
    int32_t in_stack_fffffc84;
    int32_t in_stack_ffffffd8;
    
    if (data_chunk->type != 0x9c) {
        uVar1 = 5;
        if (data_chunk->type == 0x4d) {
            if (chunk_len != 5) goto code_r0xbfc017e0;
            uVar1 = u32_unaligned(&data_chunk->field_0x1);
            if (mac_struct->unk4 < uVar1) {
                mac_struct->unk4 = uVar1;
            }
        }
        return uVar1;
    }
    uVar1 = default_len - 3;
    if (in_stack_00000010 == '\0') {
        uVar1 = default_len - 1;
    }
    if (chunk_len - 5 == (uVar1 & 0xff)) {
        uVar1 = u32_unaligned(&data_chunk->field_0x1, 0xa0180000);
        if (mac_struct->unk4 < uVar1) {
            mac_struct->unk4 = uVar1;
        }
        puVar2 = (undefined *)malloc(unaff_s1);
        fcn.bfc079a8(in_stack_ffffffd8, unaff_s0, unaff_s1, unaff_s2);
        puVar5 = &stack0xffffffdc;
        puVar4 = puVar2 + 1;
        *puVar2 = (char)mac_struct->MAC_PDU_DATA_BLOCK_TYPE;
        if (in_stack_00000010 != '\0') {
            uVar3 = crc16(mac_struct, (int32_t)&data_chunk->timestamp + 1, chunk_len - 5);
            p16(puVar4, uVar3);
            puVar5 = &stack0xffffffe4;
        }
        memcpy(*(int32_t *)(puVar5 + 0xc), *(int32_t *)(puVar5 + 0x10), *(int32_t *)(puVar5 + 0x14));
        write_output(mac_struct->uart_io, puVar2, default_len);
        *(undefined4 *)(puVar5 + 0x34) = *(undefined4 *)(puVar5 + 0x34);
        *(undefined4 *)(puVar5 + 0x30) = unaff_s8;
        *(undefined **)(puVar5 + 0x38) = puVar2;
        *(undefined4 *)(puVar5 + 0x3c) = 1;
        uVar1 = fcn.bfc06d40(*(queue_node **)(puVar5 + 0x38), 1, *(int32_t *)(puVar5 + 0x20), 
                             *(int32_t *)(puVar5 + 0x24), *(int32_t *)(puVar5 + 0x28), *(int32_t *)(puVar5 + 0x2c), 
                             *(int32_t *)(puVar5 + 0x30), *(int32_t *)(puVar5 + 0x3c));
        return uVar1;
    }
code_r0xbfc017e0:
    uVar1 = fcn.bfc05988(in_stack_fffffbec, in_stack_fffffbf0, in_stack_fffffbf4, in_stack_fffffbf8, in_stack_fffffbfc, 
                         in_stack_fffffc00, in_stack_fffffc04, in_stack_fffffc08, in_stack_fffffc0c, in_stack_fffffc10, 
                         in_stack_fffffc14, in_stack_fffffc18, in_stack_fffffc1c, in_stack_fffffc20, in_stack_fffffc24, 
                         in_stack_fffffc28, in_stack_fffffc2c, in_stack_fffffc7c, in_stack_fffffc80, in_stack_fffffc84);
    fcn.bfc065f8(in_stack_fffffbf0, in_stack_fffffbf4, in_stack_00000c00, in_stack_00000c04, in_stack_00000c08, 
                 in_stack_00000c0c);
    return uVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function write_reset_typex2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function write_output failed, args may be inaccurate.

void write_reset_typex2(mac_struct *mac_struct, uint32_t default_len)
{
    undefined uStack24;
    undefined uStack23;
    
    uStack24 = (undefined)mac_struct->MAC_PDU_RESET_TYPE;
    uStack23 = 0;
    write_output(mac_struct->uart_io, &uStack24, 2);
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function enqueue_time_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function p32 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.

int32_t enqueue_time_block(mac_struct *mac_struct)
{
    undefined *puVar1;
    queue_node *queue_node;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t unaff_s1;
    int32_t in_stack_00000004;
    int32_t in_stack_00000008;
    int32_t in_stack_ffffffec;
    
    puVar1 = (undefined *)malloc(in_stack_ffffffec);
    uVar3 = mac_struct->curr_time;
    *puVar1 = 0x4a;
    p32(puVar1 + 1, uVar3);
    queue_node = (queue_node *)malloc2(unaff_s1);
    init_queue_node(queue_node, puVar1, 5, 0xbfc0184c);
    iVar2 = add_to_queue(mac_struct->macrll_queue, queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        iVar2 = in_stack_00000004;
        free(queue_node, 0x18, in_stack_00000004, in_stack_00000008);
    }
    return iVar2;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08ba8 failed, args may be inaccurate.

void fcn.bfc08ba8(int32_t param_1)
{
    *(undefined4 *)(param_1 + 0x1000) = 0;
    *(undefined4 *)(param_1 + 0x1004) = 0;
    *(undefined4 *)(param_1 + 0x1008) = 0;
    *(undefined4 *)(param_1 + 0x100c) = 0;
    *(undefined4 *)(param_1 + 0x1010) = 0;
    *(undefined4 *)(param_1 + 0x1014) = 0;
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x1001, 0);
    setCopReg(0, *(uint32_t *)0x2030, *(uint32_t *)0x2030 | 0x2001, 0);
    **(uint32_t **)0xa0180088 = **(uint32_t **)0xa0180088 | 1;
    **(uint32_t **)0xa0180080 = **(uint32_t **)0xa0180080 | 1;
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dd4 failed, args may be inaccurate.

void fcn.bfc08dd4(int32_t arg_4h, int32_t arg_8h, int32_t arg_18h, int32_t arg_1ch)
{
    uint32_t uVar1;
    uint32_t uStack24;
    uint32_t uStack20;
    int32_t iStack16;
    int32_t arg_0h;
    
    uStack24 = 10;
    uStack20 = 0;
    iStack16 = 0;
    while (iStack16 < 0x10) {
        uStack24 = uStack24 ^ (uStack20 << 0x14 | uStack24 >> 0xc);
        uStack20 = uStack20 ^ uStack20 >> 0xc;
        uVar1 = uStack24 ^ uStack24 << 0x19;
        uStack20 = uStack20 ^ (uStack24 >> 7 | uStack20 << 0x19);
        uStack24 = uVar1 ^ (uStack20 << 5 | uVar1 >> 0x1b);
        uStack20 = uStack20 ^ uStack20 >> 0x1b;
        *(int32_t *)(iStack16 * 8 + -0x5fe7f240) = (int32_t)((uint64_t)uStack24 * 0xd81ecd35);
        *(uint32_t *)(iStack16 * 8 + -0x5fe7f23c) =
             uStack20 * -0x27e132cb + uStack24 * 0x19071d96 + (int32_t)((uint64_t)uStack24 * 0xd81ecd35 >> 0x20);
        iStack16 = iStack16 + 1;
    }
    *(undefined4 *)0xa0180d8c = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function lock_input? failed, args may be inaccurate.

void lock_input?(undefined4 param_1)
{
    *(undefined4 *)0xa0180050 = param_1;
    return;
}

// WARNING: Variable defined which should be unmapped: arg_0h
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function new_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function strlen failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.

char * new_queue(queue_struct *new_q, char *q_name, int32_t arg_10h, int32_t arg_14h)
{
    char *pcVar1;
    int32_t unaff_retaddr;
    int32_t in_stack_fffffff0;
    int32_t arg_0h;
    
    zero_12bytes();
    new_q->queue_name = (char *)0x0;
    new_q->entry_count = 0;
    strlen(in_stack_fffffff0);
    pcVar1 = (char *)malloc(unaff_retaddr);
    new_q->queue_name = pcVar1;
    arg_0h = 0;
    while (q_name[arg_0h] != '\0') {
        pcVar1[arg_0h] = q_name[arg_0h];
        arg_0h = arg_0h + 1;
    }
    pcVar1[arg_0h] = '\0';
    return pcVar1;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function init_mac failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function gettime failed, args may be inaccurate.

void init_mac(mac_struct *mac_struct)
{
    queue_struct *in_a1;
    queue_struct *in_a2;
    queue_struct *in_a3;
    uint32_t in_stack_00000014;
    
    mac_struct->max_pdu_size = 0xc0;
    mac_struct->min_pdu_size = 0x10;
    mac_struct->default_pdu_size = 0x20;
    mac_struct->MAC_PDU_DATA_BLOCK_TYPE = 0xe3;
    mac_struct->MAC_PDU_SET_DATA_BLOCK_SIZE_TYPE = 0x79;
    mac_struct->MAC_PDU_RESET_TYPE = 0x13;
    mac_struct->unk1 = 0x55;
    mac_struct->unk2 = 0x31;
    gettime(&mac_struct->init_time);
    mac_struct->uart_io = in_stack_00000014;
    mac_struct->macrll_queue = in_a1;
    mac_struct->curr_pdu_size = (uint8_t)mac_struct->default_pdu_size;
    mac_struct->rllmac_queue = in_a2;
    mac_struct->global_queue = in_a3;
    mac_struct->unk4 = 0;
    mac_struct->curr_time = 0;
    mac_struct->curr_pdu_buffer_size = 0;
    mac_struct->received_packet_count = 0;
    *(undefined *)&mac_struct->uninitialized_flag = 1;
    return;
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function init_rll failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_14h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_rll_subfcn failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function gettime failed, args may be inaccurate.

void init_rll(rll_struct *rll_struct)
{
    queue_struct *in_a1;
    queue_struct *in_a2;
    queue_struct *in_a3;
    queue_struct *in_stack_0000001c;
    queue_struct *in_stack_00000020;
    
    init_rll_subfcn();
    zero_12bytes(&rll_struct->unk4);
    gettime(&rll_struct->current_time);
    rll_struct->rrlrll_queue = in_stack_0000001c;
    rll_struct->macrll_queue = in_a1;
    rll_struct->rllrrl_queue = in_a2;
    rll_struct->rllmac_queue = in_a3;
    rll_struct->unk22 = 0;
    rll_struct->unk23 = 0;
    rll_struct->internal_queue = in_stack_00000020;
    rll_struct->last_packet_time = 0;
    rll_struct->time_passed = 0;
    rll_struct->received_packet_count = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function init_rrl failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function zero_12bytes failed, args may be inaccurate.

void init_rrl(undefined4 *param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    *param_1 = param_2;
    param_1[1] = param_3;
    param_1[2] = param_4;
    zero_12bytes(param_1 + 3);
    param_1[6] = 0xa5b5c5d5;
    param_1[7] = 0x12345678;
    param_1[8] = 0x41414141;
    param_1[9] = 0xcccccccc;
    param_1[10] = 0;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08148 failed, args may be inaccurate.

void fcn.bfc08148(int32_t param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    *(undefined4 *)(param_1 + 0x20) = param_3;
    *(undefined4 *)(param_1 + 0x24) = param_4;
    return;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc0096c failed, args may be inaccurate.

void fcn.bfc0096c(int32_t param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    *(undefined4 *)(param_1 + 0x20) = param_3;
    *(undefined4 *)(param_1 + 0x24) = param_4;
    return;
}

// WARNING: Removing unreachable block (ram,0xbfc08788)
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function mac_layer failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_pdu_pool failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function current_time_passed failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function check_for_input failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function take_input failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function u16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function crc16 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function enqueue_data_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function check_queue_size failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function pop_from_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function write_data_block? failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_10h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function enqueue_time_block failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function write_reset_typex2 failed, args may be inaccurate.

int32_t mac_layer(mac_struct *mac_struct)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    char *pcVar8;
    undefined *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 unaff_s8;
    undefined4 uVar12;
    int32_t aiStackX0 [4];
    int32_t aiStack1020 [36];
    int32_t aiStack876 [210];
    undefined auStack36 [4];
    undefined auStack32 [4];
    undefined auStack28 [4];
    undefined auStack24 [12];
    
    // esilref: 'MAC::Process
    // '
    debug_print(4, 0xa0180b70);
    puVar9 = auStack36;
    if (*(char *)&mac_struct->uninitialized_flag != '\0') {
    // set default block size
        init_pdu_pool(mac_struct, mac_struct->default_pdu_size - 3 & 0xff);
        puVar9 = auStack32;
        *(undefined *)&mac_struct->uninitialized_flag = 0;
    }
    current_time_passed(mac_struct);
    if (mac_struct->max_pdu_size < (uint32_t)mac_struct->curr_pdu_size) {
        mac_struct->curr_pdu_size = (uint8_t)mac_struct->max_pdu_size;
    }
    iVar2 = check_for_input(mac_struct->uart_io);
    puVar10 = puVar9 + 8;
    if (iVar2 == 0) {
code_r0xbfc086d8:
        uVar3 = (uint32_t)mac_struct->curr_pdu_buffer_size;
        uVar6 = (uint32_t)mac_struct->curr_pdu_size;
        if (uVar3 < uVar6) goto code_r0xbfc08774;
    } else {
        uVar3 = (uint32_t)mac_struct->curr_pdu_buffer_size;
        uVar6 = (uint32_t)mac_struct->curr_pdu_size;
        puVar10 = puVar9 + 8;
        if (uVar3 < uVar6) {
            iVar2 = take_input(mac_struct->uart_io, mac_struct->pdu_buffer + uVar3, uVar6 - uVar3);
            puVar10 = puVar9 + 0xc;
            if (iVar2 < 1) {
                return iVar2;
            }
            uVar3 = iVar2 + (uint32_t)mac_struct->curr_pdu_buffer_size & 0xffff;
            mac_struct->curr_pdu_buffer_size = (uint16_t)uVar3;
            if (mac_struct->curr_pdu_size < uVar3) {
    // esilref: 'MAC::UL RECEIVE ERROR READING GRANT ON MAC PDU.
    // '
                debug_print(1, 0xa0180b80);
                puVar10 = puVar9 + 0x10;
                mac_struct->curr_pdu_buffer_size = 0;
            }
            goto code_r0xbfc086d8;
        }
    }
    // esilref: 'MAC::UL RX GRANT[&d] GRANT SIZE[&d]
    // '
    uVar5 = 0xa0180bb4;
    debug_print(1, 0xa0180bb4, uVar3);
    uVar3 = (uint32_t)(uint8_t)mac_struct->pdu_buffer[0];
    // check PDU type for 0xe3
    mac_struct->curr_pdu_buffer_size = 0;
    if (uVar3 == mac_struct->MAC_PDU_DATA_BLOCK_TYPE) {
    // DATA_BLOCK
        iVar2 = u16(mac_struct->pdu_buffer + 1);
        pcVar8 = mac_struct->pdu_buffer + 3;
        uVar7 = mac_struct->curr_pdu_size - 3;
        uVar3 = uVar7;
        iVar4 = crc16(mac_struct, pcVar8);
        if (iVar4 != iVar2) {
            uVar12 = *(undefined4 *)(puVar10 + 0x30);
            uVar5 = *(undefined4 *)(puVar10 + 0x28);
    // esilref: 'MAC::UL DATA_BLOCK Invalid CRC-16
    // '
            goto code_r0xbfc017e0;
        }
        enqueue_data_block(mac_struct, pcVar8, uVar3, 1);
        puVar10 = puVar10 + 0x10;
        goto code_r0xbfc08774;
    }
    // check PDU type for 0x79
    if (uVar3 != mac_struct->MAC_PDU_SET_DATA_BLOCK_SIZE_TYPE) {
    // check PDU type for 0x13
        if (uVar3 != mac_struct->MAC_PDU_RESET_TYPE) {
    // esilref: 'MAC::UL UNKNOWN MAC PDU TYPE [&x].
    // '
            trap(0);
            debug_print(2, 0xa0180000);
            puVar10 = puVar10 + 8;
            goto code_r0xbfc08774;
        }
    // RESET
        mac_struct->curr_pdu_size = (uint8_t)mac_struct->default_pdu_size;
        write_reset_typex2(mac_struct, uVar5, puVar10[4]);
        puVar11 = puVar10 + 8;
        uVar3 = mac_struct->default_pdu_size;
code_r0xbfc088e4:
        init_pdu_pool(mac_struct, uVar3 - 3 & 0xff);
        puVar10 = puVar11 + 4;
code_r0xbfc08774:
        uVar3 = mac_struct->received_packet_count + 1;
        if (uVar3 % 0x14 == 0) {
            mac_struct->received_packet_count = 0;
            enqueue_time_block(mac_struct, *puVar10);
            puVar10 = puVar10 + 4;
        } else {
            mac_struct->received_packet_count = uVar3;
        }
    // check RLLMAC struct linked list length
        iVar2 = check_queue_size(mac_struct->rllmac_queue);
        if (iVar2 == 0) {
            return 0;
        }
    // esilref: 'MAC::DL RECEIVE RLL PDU for MAC.
    // ' RLL PDU
        debug_print(4, 0xa0180d18);
        iVar2 = pop_from_queue(mac_struct->rllmac_queue, puVar10[8]);
        uVar5 = *(undefined4 *)(iVar2 + 0xc);
        uVar12 = *(undefined4 *)(iVar2 + 0x10);
        uVar1 = mac_struct->curr_pdu_size;
        *(undefined4 *)(puVar10 + 0x1c) = 1;
        write_data_block?(mac_struct, uVar5, uVar12, (uint32_t)uVar1, puVar10[0xc]);
        destruct_queue_node(iVar2, puVar10[0x10]);
        *(undefined4 *)(puVar10 + 0x38) = *(undefined4 *)(puVar10 + 0x38);
        *(undefined4 *)(puVar10 + 0x34) = unaff_s8;
        *(int32_t *)(puVar10 + 0x3c) = iVar2;
        *(undefined4 *)(puVar10 + 0x40) = 0x18;
        iVar2 = fcn.bfc06d40(*(queue_node **)(puVar10 + 0x3c), 0x18, *(int32_t *)(puVar10 + 0x24), 
                             *(int32_t *)(puVar10 + 0x28), *(int32_t *)(puVar10 + 0x2c), *(int32_t *)(puVar10 + 0x30), 
                             *(int32_t *)(puVar10 + 0x34), *(int32_t *)(puVar10 + 0x40));
        return iVar2;
    }
    // DATA_BLOCK_SIZE_UPDATE
    uVar3 = u16(mac_struct->pdu_buffer + 1);
    uVar6 = crc16(mac_struct, mac_struct->pdu_buffer + 3, mac_struct->curr_pdu_size - 3);
    if (uVar6 == uVar3) {
        uVar1 = mac_struct->pdu_buffer[3];
        uVar7 = (uint32_t)uVar1;
        uVar6 = mac_struct->max_pdu_size;
        uVar3 = mac_struct->min_pdu_size;
        if ((uVar7 <= uVar6) && (uVar3 <= uVar7)) {
            if ((uVar1 & 3) != 0) {
                uVar12 = *(undefined4 *)(puVar10 + 0x30);
                uVar5 = *(undefined4 *)(puVar10 + 0x28);
    // esilref: 'MAC::UL UPDATE_BLOCK_SIZE Invalid size &u, must be multiple of 4 for Radio DMA
    // '
                goto code_r0xbfc017e0;
            }
            mac_struct->curr_pdu_size = uVar1;
            debug_print(4, 0xa0180cc0, uVar7 - 3);
            puVar11 = puVar10 + 0x10;
            uVar3 = (uint32_t)mac_struct->curr_pdu_size;
            goto code_r0xbfc088e4;
        }
    }
    uVar12 = *(undefined4 *)(puVar10 + 0x30);
    uVar5 = *(undefined4 *)(puVar10 + 0x28);
    uVar7 = uVar3;
code_r0xbfc017e0:
    *(uint32_t *)(puVar10 + 0x3c) = uVar7;
    *(undefined4 *)(puVar10 + 0x2c) = uVar5;
    *(undefined4 *)(puVar10 + 0x30) = uVar12;
    *(uint32_t *)(puVar10 + 0x40) = uVar6;
    *(undefined **)(puVar10 + 0x24) = puVar10 + 0x3c;
    iVar2 = fcn.bfc05988(*(int32_t *)(puVar10 + -0x3e0), *(int32_t *)(puVar10 + -0x3dc), *(int32_t *)(puVar10 + -0x3d8)
                         , *(int32_t *)(puVar10 + -0x3d4), *(int32_t *)(puVar10 + -0x3d0), 
                         *(int32_t *)(puVar10 + -0x3cc), *(int32_t *)(puVar10 + -0x3c8), *(int32_t *)(puVar10 + -0x3c4)
                         , *(int32_t *)(puVar10 + -0x3c0), *(int32_t *)(puVar10 + -0x3bc), 
                         *(int32_t *)(puVar10 + -0x3b8), *(int32_t *)(puVar10 + -0x3b4), *(int32_t *)(puVar10 + -0x3b0)
                         , *(int32_t *)(puVar10 + -0x3ac), *(int32_t *)(puVar10 + -0x3a8), 
                         *(int32_t *)(puVar10 + -0x3a4), *(int32_t *)(puVar10 + -0x3a0), *(int32_t *)(puVar10 + -0x350)
                         , *(int32_t *)(puVar10 + -0x34c), *(int32_t *)(puVar10 + -0x348));
    fcn.bfc065f8(*(int32_t *)(puVar10 + -0x3dc), *(int32_t *)(puVar10 + -0x3d8), *(int32_t *)(puVar10 + 0xc34), 
                 *(int32_t *)(puVar10 + 0xc38), *(int32_t *)(puVar10 + 0xc3c), *(int32_t *)(puVar10 + 0xc40));
    return iVar2;
}

// WARNING: Removing unreachable block (ram,0xbfc0170c)
// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function link_layer failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function update_time_passed failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function check_queue_size failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function pop_from_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function decode_macrll_packet failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01370 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function time_passed failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc07cd8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc01250 failed, args may be inaccurate.

uint32_t link_layer(rll_struct *rll_struct)
{
    int32_t iVar1;
    queue_node *pqVar2;
    uint32_t uVar3;
    uint32_t in_a2;
    undefined4 in_a3;
    undefined *puVar4;
    undefined *puVar5;
    undefined *puVar6;
    undefined auStackX0 [16];
    int32_t in_stack_00000010;
    int32_t in_stack_00000014;
    undefined auStack20 [8];
    
    // esilref: 'RLL::Radio Link Layer Process (UL/DL processing)
    // '
    debug_print(4, 0xa0180394);
    update_time_passed(rll_struct);
    iVar1 = check_queue_size(rll_struct->macrll_queue);
    puVar4 = auStack20;
    if (iVar1 != 0) {
    // esilref: 'RLL::UL MAC PDU
    // '
        debug_print(4, 0xa01803c8);
        pqVar2 = (queue_node *)pop_from_queue(rll_struct->macrll_queue);
        in_a2 = pqVar2->data_chunk_size;
        decode_macrll_packet(rll_struct, pqVar2->data_chunk, in_a2);
        destruct_queue_node(pqVar2);
        free(pqVar2, 0x18, in_stack_00000010, in_stack_00000014);
        puVar4 = (undefined *)*(BADSPACEBASE **)0x74;
    }
    iVar1 = check_queue_size(rll_struct->rrlrll_queue);
    puVar5 = puVar4 + 4;
    if (iVar1 != 0) {
    // esilref: 'RLL::DL RRL PDU
    // '
        debug_print(4, 0xa01803dc);
        pqVar2 = (queue_node *)pop_from_queue(rll_struct->rrlrll_queue, puVar4[8]);
        in_a2 = pqVar2->data_chunk_size;
        fcn.bfc01370(rll_struct, pqVar2->data_chunk, in_a2, puVar4[0xc]);
        destruct_queue_node(pqVar2, puVar4[0x10]);
        free(pqVar2, 0x18, *(int32_t *)(puVar4 + 0x28), *(int32_t *)(puVar4 + 0x2c));
        puVar5 = puVar4 + 0x18;
    }
    iVar1 = check_queue_size(rll_struct->internal_queue);
    puVar6 = puVar5 + 4;
    if (iVar1 != 0) {
    // esilref: 'RLL:: INTERNAL MESSAGE
    // '
        debug_print(4, 0xa01803f0);
        pqVar2 = (queue_node *)pop_from_queue(rll_struct->internal_queue, puVar5[8]);
        destruct_queue_node(pqVar2, puVar5[0xc]);
        free(pqVar2, 0x18, *(int32_t *)(puVar5 + 0x24), *(int32_t *)(puVar5 + 0x28));
        puVar6 = puVar5 + 0x14;
    }
    uVar3 = rll_struct->received_packet_count + 1;
    if (uVar3 % 0xf0 == 0) {
        rll_struct->received_packet_count = 0;
        fcn.bfc01250(rll_struct);
        puVar6 = puVar6 + 4;
    } else {
        rll_struct->received_packet_count = uVar3;
    }
    time_passed(&rll_struct->current_time);
    uVar3 = fcn.bfc07cd8(*(int32_t *)(puVar6 + 8));
    if (uVar3 < 0x1c9c381 != 0) {
        return (uint32_t)(uVar3 < 0x1c9c381);
    }
    *(uint32_t *)(puVar6 + 0x30) = in_a2;
    *(undefined4 *)(puVar6 + 0x20) = *(undefined4 *)(puVar6 + 0x1c);
    *(undefined4 *)(puVar6 + 0x24) = *(undefined4 *)(puVar6 + 0x24);
    *(undefined4 *)(puVar6 + 0x34) = in_a3;
    *(undefined **)(puVar6 + 0x18) = puVar6 + 0x30;
    uVar3 = fcn.bfc05988(*(int32_t *)(puVar6 + -0x3ec), *(int32_t *)(puVar6 + -1000), *(int32_t *)(puVar6 + -0x3e4), 
                         *(int32_t *)(puVar6 + -0x3e0), *(int32_t *)(puVar6 + -0x3dc), *(int32_t *)(puVar6 + -0x3d8), 
                         *(int32_t *)(puVar6 + -0x3d4), *(int32_t *)(puVar6 + -0x3d0), *(int32_t *)(puVar6 + -0x3cc), 
                         *(int32_t *)(puVar6 + -0x3c8), *(int32_t *)(puVar6 + -0x3c4), *(int32_t *)(puVar6 + -0x3c0), 
                         *(int32_t *)(puVar6 + -0x3bc), *(int32_t *)(puVar6 + -0x3b8), *(int32_t *)(puVar6 + -0x3b4), 
                         *(int32_t *)(puVar6 + -0x3b0), *(int32_t *)(puVar6 + -0x3ac), *(int32_t *)(puVar6 + -0x35c), 
                         *(int32_t *)(puVar6 + -0x358), *(int32_t *)(puVar6 + -0x354));
    fcn.bfc065f8(*(int32_t *)(puVar6 + -1000), *(int32_t *)(puVar6 + -0x3e4), *(int32_t *)(puVar6 + 0xc28), 
                 *(int32_t *)(puVar6 + 0xc2c), *(int32_t *)(puVar6 + 0xc30), *(int32_t *)(puVar6 + 0xc34));
    return uVar3;
    // esilref: 'RLL timeout!
    // '
}

// WARNING: Removing unreachable block (ram,0xbfc02c6c)
// WARNING: [r2ghidra] Matching calling convention n32 of function resource_layer failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function debug_print failed, args may be inaccurate.
// WARNING: [r2ghidra] Var arg_8h is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Var arg_ch is stack pointer based, which is not supported for decompilation.
// WARNING: [r2ghidra] Matching calling convention n32 of function check_queue_size failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function pop_from_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc02b48 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function free failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc05988 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc065f8 failed, args may be inaccurate.

undefined4 resource_layer(queue_struct **param_1)
{
    undefined4 uVar1;
    int32_t iVar2;
    queue_node *pqVar3;
    queue_struct *pqVar4;
    undefined *puVar5;
    undefined *puVar6;
    int32_t in_stack_0000000c;
    int32_t in_stack_00000010;
    undefined auStack24 [8];
    undefined auStack16 [4];
    
    // esilref: 'RLL::Radio Resource Layer Process (UL/DL processing)
    // '
    debug_print(4, 0xa0180998);
    iVar2 = check_queue_size(*param_1);
    puVar5 = auStack24;
    if (iVar2 != 0) {
    // esilref: 'RRL::UL RLL PDU
    // '
        debug_print(4, 0xa01809d0);
        pqVar3 = (queue_node *)pop_from_queue(*param_1);
        fcn.bfc02b48(param_1, pqVar3->data_chunk, pqVar3->data_chunk_size);
        destruct_queue_node(pqVar3);
        free(pqVar3, 0x18, in_stack_0000000c, in_stack_00000010);
        puVar5 = &stack0xfffffffc;
    }
    iVar2 = check_queue_size(param_1[2]);
    puVar6 = puVar5 + 4;
    if (iVar2 != 0) {
    // esilref: 'RRL:: INTERNAL MESSAGE
    // '
        debug_print(4, 0xa01809e4);
        pqVar3 = (queue_node *)pop_from_queue(param_1[2], puVar5[8]);
        destruct_queue_node(pqVar3, puVar5[0xc]);
        free(pqVar3, 0x18, *(int32_t *)(puVar5 + 0x24), *(int32_t *)(puVar5 + 0x28));
        puVar6 = puVar5 + 0x14;
    }
    pqVar4 = (queue_struct *)((int32_t)&param_1[10]->queue_size + 1);
    param_1[10] = pqVar4;
    if ((uint32_t)pqVar4 % 200 != 0) {
        return 0xa0180000;
    }
    *(undefined4 *)(puVar6 + 0x28) = *(undefined4 *)0xa0180da4;
    *(undefined4 *)(puVar6 + 0x18) = *(undefined4 *)(puVar6 + 0x14);
    *(undefined4 *)(puVar6 + 0x1c) = *(undefined4 *)(puVar6 + 0x1c);
    *(undefined4 *)(puVar6 + 0x2c) = *(undefined4 *)0xa0180da0;
    *(undefined **)(puVar6 + 0x10) = puVar6 + 0x28;
    uVar1 = fcn.bfc05988(*(int32_t *)(puVar6 + -0x3f4), *(int32_t *)(puVar6 + -0x3f0), *(int32_t *)(puVar6 + -0x3ec), 
                         *(int32_t *)(puVar6 + -1000), *(int32_t *)(puVar6 + -0x3e4), *(int32_t *)(puVar6 + -0x3e0), 
                         *(int32_t *)(puVar6 + -0x3dc), *(int32_t *)(puVar6 + -0x3d8), *(int32_t *)(puVar6 + -0x3d4), 
                         *(int32_t *)(puVar6 + -0x3d0), *(int32_t *)(puVar6 + -0x3cc), *(int32_t *)(puVar6 + -0x3c8), 
                         *(int32_t *)(puVar6 + -0x3c4), *(int32_t *)(puVar6 + -0x3c0), *(int32_t *)(puVar6 + -0x3bc), 
                         *(int32_t *)(puVar6 + -0x3b8), *(int32_t *)(puVar6 + -0x3b4), *(int32_t *)(puVar6 + -0x364), 
                         *(int32_t *)(puVar6 + -0x360), *(int32_t *)(puVar6 + -0x35c));
    fcn.bfc065f8(*(int32_t *)(puVar6 + -0x3f0), *(int32_t *)(puVar6 + -0x3ec), *(int32_t *)(puVar6 + 0xc20), 
                 *(int32_t *)(puVar6 + 0xc24), *(int32_t *)(puVar6 + 0xc28), *(int32_t *)(puVar6 + 0xc2c));
    return uVar1;
    // esilref: 'RRL:: Data Statistics: DATA RX[&d] TX[&d] bytes'
}

// WARNING: Unknown calling convention yet parameter storage is locked
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc066d0 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc? failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc079a8 failed, args may be inaccurate.

int32_t fcn.bfc066d0(int32_t arg_10h, int32_t arg_14h, int32_t arg_20h, int32_t arg_24h)
{
    int32_t arg_14h_00;
    int32_t in_a0;
    int32_t in_a1;
    int32_t unaff_s8;
    int32_t unaff_retaddr;
    int32_t arg_14h_01;
    int32_t in_stack_00000008;
    int32_t in_stack_00000014;
    int32_t in_stack_ffffffe4;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff4;
    
    arg_14h_01 = in_a0 * in_a1;
    arg_14h_00 = malloc?(in_stack_ffffffec, arg_14h_01, in_stack_fffffff4, unaff_s8, unaff_retaddr, in_a0, in_a1, 
                         in_stack_00000008, in_stack_00000014);
    fcn.bfc079a8(in_stack_ffffffe4, arg_14h_01, arg_14h_00, unaff_s8);
    return arg_14h_00;
}

// WARNING: [r2ghidra] Matching calling convention n32 of function jump_to_some_fcn_if_nonzero failed, args may be
// inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void jump_to_some_fcn_if_nonzero(queue_node *param_1, uint32_t param_2)
{
    int32_t unaff_s8;
    int32_t in_stack_00000004;
    int32_t in_stack_ffffffe8;
    int32_t in_stack_ffffffec;
    int32_t in_stack_fffffff0;
    int32_t in_stack_fffffff4;
    
    if (param_1 != (queue_node *)0x0) {
        fcn.bfc06d40(param_1, param_2, in_stack_ffffffe8, in_stack_ffffffec, in_stack_fffffff0, in_stack_fffffff4, 
                     unaff_s8, in_stack_00000004);
        return;
    }
    return;
}

// WARNING: Control flow encountered bad instruction data
// WARNING: This function may have set the stack pointer
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc00180 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08a98 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08960 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc08dc4 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function main failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function memcpy failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function malloc2 failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function init_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function add_to_queue failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function destruct_queue_node failed, args may be inaccurate.
// WARNING: [r2ghidra] Matching calling convention n32 of function fcn.bfc06d40 failed, args may be inaccurate.

void fcn.bfc00180(undefined4 param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    undefined4 in_at;
    undefined4 in_v0;
    undefined *puVar1;
    queue_node *queue_node;
    undefined4 in_v1;
    int32_t iVar2;
    undefined uVar3;
    int32_t iVar4;
    undefined4 in_t0;
    undefined4 in_t1;
    undefined4 *puVar5;
    undefined4 in_t2;
    int32_t iVar6;
    undefined4 in_t3;
    int32_t iVar7;
    code *pcVar8;
    undefined4 in_t4;
    int32_t iVar9;
    undefined4 in_t5;
    undefined4 in_t6;
    undefined4 in_t7;
    undefined4 in_t8;
    undefined4 in_t9;
    undefined4 unaff_retaddr;
    undefined4 uVar10;
    
    _gp = in_at;
    *(undefined4 *)0xa0180004 = unaff_retaddr;
    *(undefined4 *)0xa0180008 = in_v0;
    *(undefined4 *)0xa018000c = in_v1;
    *(undefined4 *)0xa0180010 = param_1;
    *(undefined4 *)0xa0180014 = param_2;
    *(undefined4 *)0xa0180018 = param_3;
    *(undefined4 *)0xa018001c = param_4;
    *(undefined4 *)0xa0180020 = in_t0;
    *(undefined4 *)0xa0180024 = in_t1;
    *(undefined4 *)0xa0180028 = in_t2;
    *(undefined4 *)0xa018002c = in_t3;
    *(undefined4 *)0xa0180030 = in_t4;
    *(undefined4 *)0xa0180034 = in_t5;
    *(undefined4 *)0xa0180038 = in_t6;
    *(undefined4 *)0xa018003c = in_t7;
    *(undefined4 *)0xa0180040 = in_t8;
    *(undefined4 *)0xa0180044 = in_t9;
    while ((*(uint32_t *)0x2034 >> 2 & 0x1f) == 0) {
        if (*(uint32_t *)0x2034 == 0) {
    // WARNING: Bad instruction - Truncating control flow here
            halt_baddata();
        }
        if ((*(uint32_t *)0x2034 & 0x8000) == 0) {
            if ((*(uint32_t *)0x2034 & 0x1000) == 0) {
                if ((*(uint32_t *)0x2034 & 0x2000) == 0) {
                    return;
                }
                fcn.bfc08a98();
            } else {
                fcn.bfc08960();
            }
        } else {
            fcn.bfc08dc4();
        }
    }
    trap(0);
    iVar2 = 0;
    uVar3 = 0;
    iVar4 = 0;
    setCopReg(0, *(undefined4 *)0x2010, 0, 0);
    setCopReg(0, *(undefined4 *)0x2020, 0, 0);
    setCopReg(0, *(undefined4 *)0x2038, 0, 0);
    iVar6 = 0x40;
    iVar7 = 0;
    iVar9 = 0x700;
    do {
        iVar6 = iVar6 + -1;
        setCopReg(0, *(undefined4 *)0x2000, iVar6 * 0x100, 0);
        setCopReg(0, *(undefined4 *)0x2008, iVar9, 0);
        setCopReg(0, *(undefined4 *)0x2028, iVar7, 0);
        TLB_write_indexed_entry
                  (*(undefined4 *)0x2000, *(undefined4 *)0x2028, *(undefined4 *)0x2008, *(undefined4 *)0x200c, 
                   *(undefined4 *)0x2014);
        iVar7 = iVar7 + 0x1000;
        iVar9 = iVar9 + 0x1000;
    } while (iVar6 != 0);
    setCopReg(0, *(undefined4 *)0x2028, 0, 0);
    puVar5 = (undefined4 *)0xbfc08ef8;
    pcVar8 = gp;
    do {
        *(undefined4 *)pcVar8 = *puVar5;
        puVar5 = puVar5 + 1;
        pcVar8 = (code *)((int32_t)pcVar8 + 4);
    } while (puVar5 != (undefined4 *)0xbfc09c8c);
    uVar10 = 0xbfc00510;
    main(0, 0, 0, 0);
    trap(0);
    *(int32_t *)0xa00fffec = 0;
    *(undefined4 *)0xa00ffff0 = 0;
    *(undefined4 *)0xa00ffff8 = 0;
    *(undefined4 *)0xa00ffff4 = 0;
    *(int32_t *)0xa00fffe8 = 0;
    *(int32_t *)0xa00fffe4 = 0;
    *(undefined4 *)0xa00ffffc = uVar10;
    puVar1 = (undefined *)malloc(0);
    *puVar1 = uVar3;
    memcpy(*(int32_t *)0xa00fffe0, *(int32_t *)0xa00fffe4, *(int32_t *)0xa00fffe8);
    queue_node = (queue_node *)malloc2(*(int32_t *)0xa00fffec);
    init_queue_node(queue_node, puVar1, iVar4 + 1, 0xbfc0184c);
    iVar2 = add_to_queue(*(undefined4 *)(iVar2 + 0x68), queue_node);
    if (iVar2 == 0) {
        destruct_queue_node(queue_node);
        *(undefined4 *)0xa0100010 = 0;
        *(undefined4 *)0xa010001c = 0x18;
        *(queue_node **)0xa0100018 = queue_node;
        fcn.bfc06d40(queue_node, 0x18, *(int32_t *)0xa0100000, "UL: MACRLL"._0_4_, "UL: MACRLL"._4_4_, 
                     *(int32_t *)0xa010000c, 0, 0x18);
        return;
    }
    return;
}
